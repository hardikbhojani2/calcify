import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import MortgageCalculator from "@/pages/mortgage-calculator";
import LoanCalculator from "@/pages/loan-calculator";
import AgeCalculator from "@/pages/age-calculator";
import DateCalculator from "@/pages/date-calculator";
import TimeCalculator from "@/pages/time-calculator";
import HoursCalculator from "@/pages/hours-calculator";
import GradeCalculator from "@/pages/grade-calculator";
import PasswordGenerator from "@/pages/password-generator";
import PercentageCalculator from "@/pages/percentage-calculator";
import RandomNumberGenerator from "@/pages/random-number-generator";
import BMICalculator from "@/pages/bmi-calculator";
import CalorieCalculator from "@/pages/calorie-calculator";
import BodyFatCalculator from "@/pages/body-fat-calculator";
import ScientificCalculator from "@/pages/scientific-calculator";
import TriangleCalculator from "@/pages/triangle-calculator";
import PregnancyCalculator from "@/pages/pregnancy-calculator";
import DueDateCalculator from "@/pages/due-date-calculator";
import PregnancyConceptionCalculator from "@/pages/pregnancy-conception-calculator";
import FractionCalculator from "@/pages/fraction-calculator";
import StandardDeviationCalculator from "@/pages/standard-deviation-calculator";
import InterestRateCalculator from "@/pages/interest-rate-calculator";
import AutoLoanCalculator from "@/pages/auto-loan-calculator";
import InterestCalculator from "@/pages/interest-calculator";
import InvestmentCalculator from "@/pages/investment-calculator";
import InflationCalculator from "@/pages/inflation-calculator";
import FinanceCalculator from "@/pages/finance-calculator";
import PaymentCalculator from "@/pages/payment-calculator";
import SalaryCalculator from "@/pages/salary-calculator";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import Sitemap from "@/pages/sitemap";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      
      {/* Calculator pages */}
      <Route path="/mortgage-calculator" component={MortgageCalculator} />
      
      <Route path="/loan-calculator" component={LoanCalculator} />
      <Route path="/auto-loan-calculator" component={AutoLoanCalculator} />
      <Route path="/interest-calculator" component={InterestCalculator} />
      <Route path="/payment-calculator" component={PaymentCalculator} />
      <Route path="/investment-calculator" component={InvestmentCalculator} />
      <Route path="/inflation-calculator" component={InflationCalculator} />
      <Route path="/finance-calculator" component={FinanceCalculator} />
      <Route path="/salary-calculator" component={SalaryCalculator} />
      <Route path="/interest-rate-calculator" component={InterestRateCalculator} />
      
      {/* Fitness Calculators */}
      <Route path="/bmi-calculator" component={BMICalculator} />
      <Route path="/calorie-calculator" component={CalorieCalculator} />
      <Route path="/body-fat-calculator" component={BodyFatCalculator} />
      <Route path="/pregnancy-calculator" component={PregnancyCalculator} />
      <Route path="/pregnancy-conception-calculator" component={PregnancyConceptionCalculator} />
      <Route path="/due-date-calculator" component={DueDateCalculator} />
      
      {/* Math Calculators */}
      <Route path="/scientific-calculator" component={ScientificCalculator} />
      <Route path="/fraction-calculator" component={FractionCalculator} />
      <Route path="/percentage-calculator" component={PercentageCalculator} />
      <Route path="/random-number-generator" component={RandomNumberGenerator} />
      <Route path="/triangle-calculator" component={TriangleCalculator} />
      <Route path="/standard-deviation-calculator" component={StandardDeviationCalculator} />
      
      {/* Other Calculators */}
      <Route path="/age-calculator" component={AgeCalculator} />
      <Route path="/date-calculator" component={DateCalculator} />
      <Route path="/time-calculator" component={TimeCalculator} />
      <Route path="/hours-calculator" component={HoursCalculator} />
      <Route path="/grade-calculator" component={GradeCalculator} />
      <Route path="/password-generator" component={PasswordGenerator} />
      
      {/* Footer Routes */}
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/sitemap" component={Sitemap} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
