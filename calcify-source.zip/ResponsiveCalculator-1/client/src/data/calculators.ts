// Financial Calculators
export const financialCalculators = [
  {
    title: "Mortgage Calculator",
    description: "Calculate monthly mortgage payments",
    url: "/mortgage-calculator",
    icon: "fas fa-home"
  },
  {
    title: "Loan Calculator",
    description: "Calculate loan payments and interest",
    url: "/loan-calculator",
    icon: "fas fa-money-bill-wave"
  },
  {
    title: "Auto Loan Calculator",
    description: "Calculate auto loan payments",
    url: "/auto-loan-calculator",
    icon: "fas fa-car"
  },
  {
    title: "Interest Calculator",
    description: "Calculate interest earnings",
    url: "/interest-calculator",
    icon: "fas fa-percentage"
  },
  {
    title: "Payment Calculator",
    description: "Calculate payment schedules",
    url: "/payment-calculator",
    icon: "fas fa-credit-card"
  },
  {
    title: "Investment Calculator",
    description: "Calculate investment growth",
    url: "/investment-calculator",
    icon: "fas fa-chart-line"
  },
  {
    title: "Inflation Calculator",
    description: "Calculate inflation impact",
    url: "/inflation-calculator",
    icon: "fas fa-dollar-sign"
  },
  {
    title: "Finance Calculator",
    description: "General financial calculations",
    url: "/finance-calculator",
    icon: "fas fa-coins"
  },
  {
    title: "Salary Calculator",
    description: "Calculate take-home pay after taxes",
    url: "/salary-calculator",
    icon: "fas fa-file-invoice-dollar"
  },
  {
    title: "Interest Rate Calculator",
    description: "Calculate interest rates from payments",
    url: "/interest-rate-calculator",
    icon: "fas fa-percentage"
  }
];

// Fitness & Health Calculators
export const fitnessCalculators = [
  {
    title: "BMI Calculator",
    description: "Calculate body mass index",
    url: "/bmi-calculator",
    icon: "fas fa-weight"
  },
  {
    title: "Calorie Calculator",
    description: "Calculate daily calorie needs",
    url: "/calorie-calculator",
    icon: "fas fa-utensils"
  },
  {
    title: "Body Fat Calculator",
    description: "Estimate body fat percentage",
    url: "/body-fat-calculator",
    icon: "fas fa-tape"
  },
  {
    title: "Pregnancy Calculator",
    description: "Track pregnancy progress",
    url: "/pregnancy-calculator",
    icon: "fas fa-baby"
  },
  {
    title: "Pregnancy Conception Calculator",
    description: "Calculate conception date",
    url: "/pregnancy-conception-calculator",
    icon: "fas fa-calendar-day"
  },
  {
    title: "Due Date Calculator",
    description: "Calculate pregnancy due date",
    url: "/due-date-calculator",
    icon: "fas fa-calendar-check"
  }
];

// Math Calculators
export const mathCalculators = [
  {
    title: "Scientific Calculator",
    description: "Advanced math calculations",
    url: "/scientific-calculator",
    icon: "fas fa-calculator"
  },
  {
    title: "Fraction Calculator",
    description: "Calculate with fractions",
    url: "/fraction-calculator",
    icon: "fas fa-divide"
  },
  {
    title: "Percentage Calculator",
    description: "Calculate percentages",
    url: "/percentage-calculator",
    icon: "fas fa-percentage"
  },
  {
    title: "Random Number Generator",
    description: "Generate random numbers",
    url: "/random-number-generator",
    icon: "fas fa-random"
  },
  {
    title: "Triangle Calculator",
    description: "Calculate triangle properties",
    url: "/triangle-calculator",
    icon: "fas fa-draw-polygon"
  },
  {
    title: "Standard Deviation Calculator",
    description: "Calculate statistical measures",
    url: "/standard-deviation-calculator",
    icon: "fas fa-chart-bar"
  }
];

// Other Calculators
export const otherCalculators = [
  {
    title: "Age Calculator",
    description: "Calculate age from birthdate",
    url: "/age-calculator",
    icon: "fas fa-birthday-cake"
  },
  {
    title: "Date Calculator",
    description: "Calculate days between dates",
    url: "/date-calculator",
    icon: "fas fa-calendar-alt"
  },
  {
    title: "Time Calculator",
    description: "Calculate time differences",
    url: "/time-calculator",
    icon: "fas fa-clock"
  },
  {
    title: "Hours Calculator",
    description: "Calculate work hours and pay",
    url: "/hours-calculator",
    icon: "fas fa-business-time"
  },
  {
    title: "Grade Calculator",
    description: "Calculate grade point average",
    url: "/grade-calculator",
    icon: "fas fa-graduation-cap"
  },
  {
    title: "Password Generator",
    description: "Generate secure passwords",
    url: "/password-generator",
    icon: "fas fa-key"
  }
];
