import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Function to smooth scroll to element
export function scrollToElement(elementId: string): void {
  const element = document.getElementById(elementId);
  if (element) {
    window.scrollTo({
      top: element.offsetTop - 80, // Adjust for fixed header
      behavior: 'smooth'
    });
  }
}

// Function to filter calculator cards based on search term
export function filterCalculators(searchTerm: string, calculators: any[]): any[] {
  if (!searchTerm.trim()) {
    return calculators;
  }
  
  const term = searchTerm.toLowerCase();
  return calculators.filter(calc => 
    calc.title.toLowerCase().includes(term) || 
    calc.description.toLowerCase().includes(term)
  );
}
