import React from 'react';
import { Link } from 'wouter';
import { useMobile } from '@/hooks/use-mobile';
import { scrollToElement } from '@/lib/utils';
import { 
  financialCalculators, 
  fitnessCalculators, 
  mathCalculators, 
  otherCalculators 
} from '@/data/calculators';

const NavBar: React.FC = () => {
  const isMobile = useMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  // Close mobile menu when selecting a category or on viewport resize
  React.useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [isMobile]);
  
  const handleCategoryClick = (categoryId: string) => {
    scrollToElement(categoryId);
    setIsMobileMenuOpen(false);
  };
  
  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo - Left aligned */}
          <div className="flex-shrink-0 flex items-center">
            <Link href="/" className="text-xl font-bold text-primary flex items-center">
              <i className="fas fa-calculator mr-2"></i>
              Calcify
            </Link>
          </div>
          
          {/* Desktop menu - Centered */}
          <div className="hidden sm:flex flex-1 justify-center items-center sm:space-x-8">
            {/* Financial dropdown */}
            <div className="relative group">
              <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Financial
                <svg className="ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
              <div className="hidden group-hover:block absolute z-10 -ml-4 mt-3 transform px-2 w-screen max-w-md sm:px-0 lg:ml-0 lg:left-1/2 lg:-translate-x-1/2">
                <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                  <div className="relative grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8">
                    {financialCalculators.slice(0, 6).map((calc) => (
                      <Link 
                        key={calc.url} 
                        href={calc.url} 
                        className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50"
                      >
                        <i className={`${calc.icon} flex-shrink-0 h-6 w-6 text-primary`}></i>
                        <div className="ml-4">
                          <p className="text-base font-medium text-gray-900">{calc.title}</p>
                        </div>
                      </Link>
                    ))}
                    {financialCalculators.length > 6 && (
                      <button 
                        onClick={() => handleCategoryClick('financial')}
                        className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50 w-full text-left"
                      >
                        <i className="fas fa-list flex-shrink-0 h-6 w-6 text-primary"></i>
                        <div className="ml-4">
                          <p className="text-base font-medium text-gray-900">View All Financial Calculators</p>
                        </div>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Fitness & Health dropdown */}
            <div className="relative group">
              <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Fitness & Health
                <svg className="ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
              <div className="hidden group-hover:block absolute z-10 -ml-4 mt-3 transform px-2 w-screen max-w-md sm:px-0 lg:ml-0 lg:left-1/2 lg:-translate-x-1/2">
                <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                  <div className="relative grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8">
                    {fitnessCalculators.map((calc) => (
                      <Link 
                        key={calc.url} 
                        href={calc.url} 
                        className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50"
                      >
                        <i className={`${calc.icon} flex-shrink-0 h-6 w-6 text-secondary`}></i>
                        <div className="ml-4">
                          <p className="text-base font-medium text-gray-900">{calc.title}</p>
                        </div>
                      </Link>
                    ))}
                    <button 
                      onClick={() => handleCategoryClick('fitness')}
                      className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50 w-full text-left"
                    >
                      <i className="fas fa-list flex-shrink-0 h-6 w-6 text-secondary"></i>
                      <div className="ml-4">
                        <p className="text-base font-medium text-gray-900">View All Fitness Calculators</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Math dropdown */}
            <div className="relative group">
              <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Math
                <svg className="ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
              <div className="hidden group-hover:block absolute z-10 -ml-4 mt-3 transform px-2 w-screen max-w-md sm:px-0 lg:ml-0 lg:left-1/2 lg:-translate-x-1/2">
                <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                  <div className="relative grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8">
                    {mathCalculators.map((calc) => (
                      <Link 
                        key={calc.url} 
                        href={calc.url} 
                        className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50"
                      >
                        <i className={`${calc.icon} flex-shrink-0 h-6 w-6 text-accent`}></i>
                        <div className="ml-4">
                          <p className="text-base font-medium text-gray-900">{calc.title}</p>
                        </div>
                      </Link>
                    ))}
                    <button 
                      onClick={() => handleCategoryClick('math')}
                      className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50 w-full text-left"
                    >
                      <i className="fas fa-list flex-shrink-0 h-6 w-6 text-accent"></i>
                      <div className="ml-4">
                        <p className="text-base font-medium text-gray-900">View All Math Calculators</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Other dropdown */}
            <div className="relative group">
              <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                Other
                <svg className="ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
              <div className="hidden group-hover:block absolute z-10 -ml-4 mt-3 transform px-2 w-screen max-w-md sm:px-0 lg:ml-0 lg:left-1/2 lg:-translate-x-1/2">
                <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                  <div className="relative grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8">
                    {otherCalculators.map((calc) => (
                      <Link 
                        key={calc.url} 
                        href={calc.url} 
                        className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50"
                      >
                        <i className={`${calc.icon} flex-shrink-0 h-6 w-6 text-gray-600`}></i>
                        <div className="ml-4">
                          <p className="text-base font-medium text-gray-900">{calc.title}</p>
                        </div>
                      </Link>
                    ))}
                    <button 
                      onClick={() => handleCategoryClick('other')}
                      className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50 w-full text-left"
                    >
                      <i className="fas fa-list flex-shrink-0 h-6 w-6 text-gray-600"></i>
                      <div className="ml-4">
                        <p className="text-base font-medium text-gray-900">View All Other Calculators</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Mobile menu button - Right aligned */}
          <div className="flex items-center sm:hidden">
            <button 
              onClick={toggleMobileMenu}
              type="button" 
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary" 
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={`sm:hidden ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="pt-2 pb-3 space-y-1">
          <button
            onClick={() => handleCategoryClick('financial')}
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 w-full text-left"
          >
            Financial
          </button>
          <button
            onClick={() => handleCategoryClick('fitness')}
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 w-full text-left"
          >
            Fitness & Health
          </button>
          <button
            onClick={() => handleCategoryClick('math')}
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 w-full text-left"
          >
            Math
          </button>
          <button
            onClick={() => handleCategoryClick('other')}
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 w-full text-left"
          >
            Other
          </button>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
