import React from 'react';
import { Link } from 'wouter';
import { scrollToElement } from '@/lib/utils';

const Footer: React.FC = () => {
  const handleCategoryClick = (categoryId: string) => {
    scrollToElement(categoryId);
  };
  
  return (
    <footer className="bg-gray-800 text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="text-xl font-bold flex items-center">
              <i className="fas fa-calculator mr-2"></i>
              Calcify
            </Link>
            <p className="mt-2 text-gray-300">All-in-one calculator suite for finance, fitness, math, and more. Fast, free, and accurate.</p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Categories</h3>
            <ul className="mt-4 space-y-4">
              <li>
                <button 
                  onClick={() => handleCategoryClick('financial')} 
                  className="text-base text-gray-300 hover:text-white"
                >
                  Financial
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleCategoryClick('fitness')} 
                  className="text-base text-gray-300 hover:text-white"
                >
                  Fitness & Health
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleCategoryClick('math')} 
                  className="text-base text-gray-300 hover:text-white"
                >
                  Math
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleCategoryClick('other')} 
                  className="text-base text-gray-300 hover:text-white"
                >
                  Other
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Company</h3>
            <ul className="mt-4 space-y-4">
              <li>
                <Link href="/about" className="text-base text-gray-300 hover:text-white">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-base text-gray-300 hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/sitemap" className="text-base text-gray-300 hover:text-white">
                  Sitemap
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-base text-gray-300 hover:text-white">
                  Terms
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-base text-gray-300 hover:text-white">
                  Privacy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between">
          <p className="text-base text-gray-400">&copy; {new Date().getFullYear()} Calcify. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-gray-300">
              <i className="fab fa-facebook"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-300">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-300">
              <i className="fab fa-instagram"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
