import React from 'react';
import CalculatorCard from './calculator-card';
import { cn } from '@/lib/utils';

interface Calculator {
  title: string;
  description: string;
  url: string;
  icon: string;
}

interface CategorySectionProps {
  id: string;
  title: string;
  icon: string;
  iconClass: string;
  calculators: Calculator[];
  category: 'financial' | 'fitness' | 'math' | 'other';
}

const CategorySection: React.FC<CategorySectionProps> = ({ 
  id, 
  title, 
  icon, 
  iconClass, 
  calculators, 
  category 
}) => {
  return (
    <section id={id} className={cn("calculator-category", id !== 'other' ? 'mb-16' : '')}>
      <div className="flex items-center mb-6">
        <i className={cn("text-2xl mr-3", icon, iconClass)}></i>
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {calculators.map((calculator) => (
          <CalculatorCard
            key={calculator.url}
            title={calculator.title}
            description={calculator.description}
            url={calculator.url}
            icon={calculator.icon}
            category={category}
          />
        ))}
      </div>
    </section>
  );
};

export default CategorySection;
