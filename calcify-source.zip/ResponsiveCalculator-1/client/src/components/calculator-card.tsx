import React from 'react';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

interface CalculatorCardProps {
  title: string;
  description: string;
  url: string;
  icon: string;
  category: 'financial' | 'fitness' | 'math' | 'other';
}

const CalculatorCard: React.FC<CalculatorCardProps> = ({ title, description, url, icon, category }) => {
  const categoryClassMap = {
    financial: {
      iconBg: 'bg-blue-100',
      iconColor: 'text-primary'
    },
    fitness: {
      iconBg: 'bg-green-100',
      iconColor: 'text-secondary'
    },
    math: {
      iconBg: 'bg-purple-100',
      iconColor: 'text-accent'
    },
    other: {
      iconBg: 'bg-gray-100',
      iconColor: 'text-gray-600'
    }
  };
  
  const { iconBg, iconColor } = categoryClassMap[category];
  
  return (
    <Link href={url} className="calculator-card group">
      <div className="p-6">
        <div className={cn("w-12 h-12 rounded-full flex items-center justify-center mb-4", iconBg)}>
          <i className={cn("text-lg", iconColor, icon)}></i>
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-1 group-hover:text-primary transition-colors duration-200">{title}</h3>
        <p className="text-sm text-gray-500">{description}</p>
      </div>
    </Link>
  );
};

export default CalculatorCard;
