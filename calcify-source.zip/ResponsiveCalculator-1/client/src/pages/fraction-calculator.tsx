import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calculator, Plus, Minus, X, Divide } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema
const fractionSchema = z.object({
  operation: z.enum(["add", "subtract", "multiply", "divide"]),
  numerator1: z.coerce.number().int(),
  denominator1: z.coerce.number().int().refine(val => val !== 0, {
    message: "Denominator cannot be zero"
  }),
  numerator2: z.coerce.number().int(),
  denominator2: z.coerce.number().int().refine(val => val !== 0, {
    message: "Denominator cannot be zero"
  }),
});

type FormValues = z.infer<typeof fractionSchema>;

const mixedNumberSchema = z.object({
  operation: z.enum(["add", "subtract", "multiply", "divide"]),
  whole1: z.coerce.number().int(),
  numerator1: z.coerce.number().int().min(0, "Numerator must be positive"),
  denominator1: z.coerce.number().int().min(1, "Denominator must be positive"),
  whole2: z.coerce.number().int(),
  numerator2: z.coerce.number().int().min(0, "Numerator must be positive"),
  denominator2: z.coerce.number().int().min(1, "Denominator must be positive"),
});

type MixedFormValues = z.infer<typeof mixedNumberSchema>;

const decimalSchema = z.object({
  decimal: z.coerce.number(),
  precision: z.coerce.number().int().min(1).max(10).default(5),
});

type DecimalFormValues = z.infer<typeof decimalSchema>;

const FractionCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("fraction");
  const [result, setResult] = useState<{
    numerator: number;
    denominator: number;
    decimal: number;
    simplified: { numerator: number; denominator: number; whole?: number };
    steps: string[];
  } | null>(null);
  
  const [decimalResult, setDecimalResult] = useState<{
    fraction: { numerator: number; denominator: number };
    mixed: { whole: number; numerator: number; denominator: number } | null;
    steps: string[];
  } | null>(null);
  
  // Initialize form for fractions
  const form = useForm<FormValues>({
    resolver: zodResolver(fractionSchema),
    defaultValues: {
      operation: "add",
      numerator1: 1,
      denominator1: 2,
      numerator2: 1,
      denominator2: 3,
    },
  });
  
  // Initialize form for mixed numbers
  const mixedForm = useForm<MixedFormValues>({
    resolver: zodResolver(mixedNumberSchema),
    defaultValues: {
      operation: "add",
      whole1: 2,
      numerator1: 1,
      denominator1: 4,
      whole2: 1,
      numerator2: 1,
      denominator2: 2,
    },
  });
  
  // Initialize form for decimals to fractions
  const decimalForm = useForm<DecimalFormValues>({
    resolver: zodResolver(decimalSchema),
    defaultValues: {
      decimal: 0.75,
      precision: 5,
    },
  });

  // Calculate the greatest common divisor
  const gcd = (a: number, b: number): number => {
    a = Math.abs(a);
    b = Math.abs(b);
    while (b) {
      const t = b;
      b = a % b;
      a = t;
    }
    return a;
  };

  // Calculate the least common multiple
  const lcm = (a: number, b: number): number => {
    return Math.abs(a * b) / gcd(a, b);
  };

  // Convert a fraction to its simplified form
  const simplifyFraction = (numerator: number, denominator: number): { numerator: number; denominator: number; whole?: number } => {
    if (numerator === 0) {
      return { numerator: 0, denominator: 1 };
    }
    
    const isNegative = (numerator < 0 && denominator > 0) || (numerator > 0 && denominator < 0);
    numerator = Math.abs(numerator);
    denominator = Math.abs(denominator);
    
    // Check if we can extract a whole number
    if (numerator >= denominator) {
      const whole = Math.floor(numerator / denominator);
      const remainder = numerator % denominator;
      
      if (remainder === 0) {
        return { numerator: isNegative ? -whole : whole, denominator: 1 };
      }
      
      return {
        numerator: remainder,
        denominator: denominator,
        whole: isNegative ? -whole : whole
      };
    }
    
    // Simplify the fraction
    const divisor = gcd(numerator, denominator);
    return {
      numerator: isNegative ? -Math.abs(numerator / divisor) : Math.abs(numerator / divisor),
      denominator: Math.abs(denominator / divisor)
    };
  };

  // Convert improper fraction to mixed number
  const toMixedNumber = (numerator: number, denominator: number): { whole: number; numerator: number; denominator: number } => {
    const isNegative = (numerator < 0 && denominator > 0) || (numerator > 0 && denominator < 0);
    numerator = Math.abs(numerator);
    denominator = Math.abs(denominator);
    
    const whole = Math.floor(numerator / denominator);
    const remainder = numerator % denominator;
    
    return {
      whole: isNegative ? -whole : whole,
      numerator: remainder,
      denominator: denominator
    };
  };

  // Convert mixed number to improper fraction
  const toImproperFraction = (whole: number, numerator: number, denominator: number): { numerator: number; denominator: number } => {
    const isNegative = whole < 0;
    whole = Math.abs(whole);
    
    const newNumerator = whole * denominator + numerator;
    
    return {
      numerator: isNegative ? -newNumerator : newNumerator,
      denominator: denominator
    };
  };

  // Calculate fraction operations
  const calculateFractions = (values: FormValues) => {
    const { operation, numerator1, denominator1, numerator2, denominator2 } = values;
    
    let resultNumerator = 0;
    let resultDenominator = 1;
    let steps = [];
    
    if (operation === "add" || operation === "subtract") {
      const lcmDenominator = lcm(denominator1, denominator2);
      const factor1 = lcmDenominator / denominator1;
      const factor2 = lcmDenominator / denominator2;
      
      steps.push(`Find the least common multiple (LCM) of ${denominator1} and ${denominator2}, which is ${lcmDenominator}`);
      steps.push(`Convert fractions to equivalent fractions with denominator ${lcmDenominator}:`);
      steps.push(`${numerator1}/${denominator1} = ${numerator1 * factor1}/${lcmDenominator}`);
      steps.push(`${numerator2}/${denominator2} = ${numerator2 * factor2}/${lcmDenominator}`);
      
      if (operation === "add") {
        resultNumerator = numerator1 * factor1 + numerator2 * factor2;
        steps.push(`Add numerators: ${numerator1 * factor1} + ${numerator2 * factor2} = ${resultNumerator}`);
      } else {
        resultNumerator = numerator1 * factor1 - numerator2 * factor2;
        steps.push(`Subtract numerators: ${numerator1 * factor1} - ${numerator2 * factor2} = ${resultNumerator}`);
      }
      
      resultDenominator = lcmDenominator;
    } else if (operation === "multiply") {
      resultNumerator = numerator1 * numerator2;
      resultDenominator = denominator1 * denominator2;
      
      steps.push(`Multiply numerators: ${numerator1} × ${numerator2} = ${resultNumerator}`);
      steps.push(`Multiply denominators: ${denominator1} × ${denominator2} = ${resultDenominator}`);
    } else if (operation === "divide") {
      resultNumerator = numerator1 * denominator2;
      resultDenominator = denominator1 * numerator2;
      
      if (resultDenominator === 0) {
        throw new Error("Division by zero is not allowed.");
      }
      
      steps.push(`To divide fractions, multiply by the reciprocal:`);
      steps.push(`${numerator1}/${denominator1} ÷ ${numerator2}/${denominator2} = ${numerator1}/${denominator1} × ${denominator2}/${numerator2}`);
      steps.push(`Multiply numerators: ${numerator1} × ${denominator2} = ${resultNumerator}`);
      steps.push(`Multiply denominators: ${denominator1} × ${numerator2} = ${resultDenominator}`);
    }
    
    // Simplify the result
    const simplified = simplifyFraction(resultNumerator, resultDenominator);
    
    // Add simplification steps
    const divisor = gcd(Math.abs(resultNumerator), Math.abs(resultDenominator));
    if (divisor > 1) {
      steps.push(`Simplify by dividing both numerator and denominator by the GCD ${divisor}:`);
      steps.push(`${resultNumerator}/${resultDenominator} = ${simplified.numerator}${simplified.whole ? ` or ${simplified.whole} ${simplified.numerator}/${simplified.denominator}` : ''}/${simplified.denominator}`);
    } else if (simplified.whole) {
      steps.push(`Convert to mixed number: ${resultNumerator}/${resultDenominator} = ${simplified.whole} ${simplified.numerator}/${simplified.denominator}`);
    }
    
    return {
      numerator: resultNumerator,
      denominator: resultDenominator,
      decimal: resultNumerator / resultDenominator,
      simplified,
      steps
    };
  };

  // Calculate mixed number operations
  const calculateMixedNumbers = (values: MixedFormValues) => {
    const { operation, whole1, numerator1, denominator1, whole2, numerator2, denominator2 } = values;
    
    // Convert mixed numbers to improper fractions
    const fraction1 = toImproperFraction(whole1, numerator1, denominator1);
    const fraction2 = toImproperFraction(whole2, numerator2, denominator2);
    
    let steps = [];
    steps.push(`Convert mixed numbers to improper fractions:`);
    steps.push(`${whole1} ${numerator1}/${denominator1} = ${fraction1.numerator}/${fraction1.denominator}`);
    steps.push(`${whole2} ${numerator2}/${denominator2} = ${fraction2.numerator}/${fraction2.denominator}`);
    
    // Perform the calculation as with regular fractions
    const fractionValues: FormValues = {
      operation,
      numerator1: fraction1.numerator,
      denominator1: fraction1.denominator,
      numerator2: fraction2.numerator,
      denominator2: fraction2.denominator
    };
    
    const fractionResult = calculateFractions(fractionValues);
    
    // Append the steps from the fraction calculation
    steps = steps.concat(fractionResult.steps);
    
    return {
      ...fractionResult,
      steps
    };
  };

  // Convert decimal to fraction
  const decimalToFraction = (decimal: number, precision: number): { fraction: { numerator: number; denominator: number }; mixed: { whole: number; numerator: number; denominator: number } | null; steps: string[] } => {
    const steps = [];
    
    // Handle negative numbers
    const isNegative = decimal < 0;
    decimal = Math.abs(decimal);
    
    // Extract the whole number part
    const whole = Math.floor(decimal);
    let fractionalPart = decimal - whole;
    
    steps.push(`Split ${isNegative ? '-' : ''}${decimal} into whole and fractional parts:`);
    steps.push(`Whole part: ${whole}`);
    steps.push(`Fractional part: ${fractionalPart}`);
    
    // Convert the fractional part to a fraction
    // To do this, we multiply by 10^precision and find the GCD
    const multiplier = Math.pow(10, precision);
    let numerator = Math.round(fractionalPart * multiplier);
    let denominator = multiplier;
    
    steps.push(`Multiply fractional part by 10^${precision} to get ${fractionalPart} × ${multiplier} = ${numerator}/${denominator}`);
    
    // Simplify the fraction
    const divisor = gcd(numerator, denominator);
    if (divisor > 1) {
      numerator = numerator / divisor;
      denominator = denominator / divisor;
      steps.push(`Simplify by dividing both by ${divisor}: ${numerator}/${denominator}`);
    }
    
    // Create improper fraction if there's a whole number
    let improperNumerator = whole * denominator + numerator;
    if (isNegative) {
      improperNumerator = -improperNumerator;
    }
    
    let mixedNumber = null;
    
    if (whole > 0) {
      steps.push(`To get the improper fraction: ${isNegative ? '-' : ''}${whole} × ${denominator} + ${numerator} = ${isNegative ? '-' : ''}${Math.abs(improperNumerator)}/${denominator}`);
      
      // Also provide mixed number form if there's a whole number
      if (numerator > 0) {
        mixedNumber = {
          whole: isNegative ? -whole : whole,
          numerator: numerator,
          denominator: denominator
        };
        steps.push(`As a mixed number: ${isNegative ? '-' : ''}${whole} ${numerator}/${denominator}`);
      }
    } else {
      if (isNegative) {
        steps.push(`As a negative fraction: -${numerator}/${denominator}`);
      }
    }
    
    return {
      fraction: { numerator: improperNumerator, denominator: denominator },
      mixed: mixedNumber,
      steps
    };
  };

  // Form submission handlers
  const onSubmit = (values: FormValues) => {
    try {
      const calculationResult = calculateFractions(values);
      setResult(calculationResult);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };
  
  const onMixedSubmit = (values: MixedFormValues) => {
    try {
      const calculationResult = calculateMixedNumbers(values);
      setResult(calculationResult);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };
  
  const onDecimalSubmit = (values: DecimalFormValues) => {
    try {
      const result = decimalToFraction(values.decimal, values.precision);
      setDecimalResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };

  // Gets the operation symbol
  const getOperationSymbol = (op: string) => {
    switch(op) {
      case "add": return "+";
      case "subtract": return "-";
      case "multiply": return "×";
      case "divide": return "÷";
      default: return "";
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Calculator className="mr-2 h-8 w-8" /> Fraction Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="fraction" onValueChange={setActiveTab} value={activeTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="fraction">Fractions</TabsTrigger>
            <TabsTrigger value="mixed">Mixed Numbers</TabsTrigger>
            <TabsTrigger value="decimal">Decimal to Fraction</TabsTrigger>
          </TabsList>
          
          {/* Fractions Tab */}
          <TabsContent value="fraction" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate with Fractions</CardTitle>
                <CardDescription>
                  Perform operations on simple fractions.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="operation"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Operation</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="add" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Plus className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="subtract" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Minus className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="multiply" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <X className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="divide" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Divide className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col space-y-4">
                        <FormField
                          control={form.control}
                          name="numerator1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Numerator</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="1" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="denominator1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Denominator</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="1" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="flex flex-col space-y-4">
                        <FormField
                          control={form.control}
                          name="numerator2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Second Numerator</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="1" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="denominator2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Second Denominator</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="1" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Results</CardTitle>
                <CardDescription>
                  Calculation results and step-by-step explanation.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {result && activeTab === "fraction" ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold mb-2">
                        <span className="inline-block text-center">
                          <span className="block">{form.getValues().numerator1}</span>
                          <span className="block border-t border-black mx-2 my-1"></span>
                          <span className="block">{form.getValues().denominator1}</span>
                        </span>
                        <span className="mx-2">{getOperationSymbol(form.getValues().operation)}</span>
                        <span className="inline-block text-center">
                          <span className="block">{form.getValues().numerator2}</span>
                          <span className="block border-t border-black mx-2 my-1"></span>
                          <span className="block">{form.getValues().denominator2}</span>
                        </span>
                        <span className="mx-2">=</span>
                        <span className="inline-block text-center">
                          <span className="block">{result.numerator}</span>
                          <span className="block border-t border-black mx-2 my-1"></span>
                          <span className="block">{result.denominator}</span>
                        </span>
                      </div>
                      
                      <div className="mt-4">
                        <h3 className="text-lg font-medium">Simplified Form</h3>
                        <div className="mt-2">
                          {result.simplified.whole !== undefined ? (
                            <div className="text-xl">
                              {result.simplified.numerator === 0 ? (
                                <span>{result.simplified.whole}</span>
                              ) : (
                                <span>
                                  {result.simplified.whole} 
                                  <span className="inline-block text-center ml-2">
                                    <span className="block">{result.simplified.numerator}</span>
                                    <span className="block border-t border-black mx-1 my-1"></span>
                                    <span className="block">{result.simplified.denominator}</span>
                                  </span>
                                </span>
                              )}
                            </div>
                          ) : (
                            <div className="text-xl">
                              <span className="inline-block text-center">
                                <span className="block">{result.simplified.numerator}</span>
                                <span className="block border-t border-black mx-1 my-1"></span>
                                <span className="block">{result.simplified.denominator}</span>
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <h3 className="text-lg font-medium">Decimal Form</h3>
                        <p className="text-xl">{result.decimal.toFixed(5)}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-2">Step-by-Step Solution</h3>
                      <ol className="list-decimal pl-5 space-y-1 text-sm">
                        {result.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <Calculator className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>Enter fraction values and click "Calculate" to see the results.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Mixed Numbers Tab */}
          <TabsContent value="mixed" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate with Mixed Numbers</CardTitle>
                <CardDescription>
                  Perform operations on mixed numbers (whole + fraction).
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...mixedForm}>
                  <form onSubmit={mixedForm.handleSubmit(onMixedSubmit)} className="space-y-6">
                    <FormField
                      control={mixedForm.control}
                      name="operation"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Operation</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="add" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Plus className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="subtract" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Minus className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="multiply" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <X className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="divide" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  <Divide className="h-4 w-4" />
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">First Mixed Number</h3>
                        <div className="grid grid-cols-3 gap-2">
                          <FormField
                            control={mixedForm.control}
                            name="whole1"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Whole</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={mixedForm.control}
                            name="numerator1"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Num</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={mixedForm.control}
                            name="denominator1"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Denom</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" min="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">Second Mixed Number</h3>
                        <div className="grid grid-cols-3 gap-2">
                          <FormField
                            control={mixedForm.control}
                            name="whole2"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Whole</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={mixedForm.control}
                            name="numerator2"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Num</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={mixedForm.control}
                            name="denominator2"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Denom</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" min="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Results</CardTitle>
                <CardDescription>
                  Calculation results and step-by-step explanation.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {result && activeTab === "mixed" ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold mb-2">
                        <span>
                          {mixedForm.getValues().whole1} 
                          <span className="inline-block text-center ml-1">
                            <span className="block">{mixedForm.getValues().numerator1}</span>
                            <span className="block border-t border-black mx-1 my-1"></span>
                            <span className="block">{mixedForm.getValues().denominator1}</span>
                          </span>
                        </span>
                        <span className="mx-2">{getOperationSymbol(mixedForm.getValues().operation)}</span>
                        <span>
                          {mixedForm.getValues().whole2} 
                          <span className="inline-block text-center ml-1">
                            <span className="block">{mixedForm.getValues().numerator2}</span>
                            <span className="block border-t border-black mx-1 my-1"></span>
                            <span className="block">{mixedForm.getValues().denominator2}</span>
                          </span>
                        </span>
                        <span className="mx-2">=</span>
                        <span className="inline-block text-center">
                          <span className="block">{result.numerator}</span>
                          <span className="block border-t border-black mx-2 my-1"></span>
                          <span className="block">{result.denominator}</span>
                        </span>
                      </div>
                      
                      <div className="mt-4">
                        <h3 className="text-lg font-medium">Simplified Form</h3>
                        <div className="mt-2">
                          {result.simplified.whole !== undefined ? (
                            <div className="text-xl">
                              {result.simplified.numerator === 0 ? (
                                <span>{result.simplified.whole}</span>
                              ) : (
                                <span>
                                  {result.simplified.whole} 
                                  <span className="inline-block text-center ml-2">
                                    <span className="block">{result.simplified.numerator}</span>
                                    <span className="block border-t border-black mx-1 my-1"></span>
                                    <span className="block">{result.simplified.denominator}</span>
                                  </span>
                                </span>
                              )}
                            </div>
                          ) : (
                            <div className="text-xl">
                              <span className="inline-block text-center">
                                <span className="block">{result.simplified.numerator}</span>
                                <span className="block border-t border-black mx-1 my-1"></span>
                                <span className="block">{result.simplified.denominator}</span>
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <h3 className="text-lg font-medium">Decimal Form</h3>
                        <p className="text-xl">{result.decimal.toFixed(5)}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-2">Step-by-Step Solution</h3>
                      <ol className="list-decimal pl-5 space-y-1 text-sm">
                        {result.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <Calculator className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>Enter mixed number values and click "Calculate" to see the results.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Decimal to Fraction Tab */}
          <TabsContent value="decimal" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Convert Decimal to Fraction</CardTitle>
                <CardDescription>
                  Convert a decimal number to an equivalent fraction.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...decimalForm}>
                  <form onSubmit={decimalForm.handleSubmit(onDecimalSubmit)} className="space-y-6">
                    <FormField
                      control={decimalForm.control}
                      name="decimal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Decimal Number</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormDescription>
                            Enter any decimal number (e.g., 0.75, 3.14, etc.)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={decimalForm.control}
                      name="precision"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Precision</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" min="1" max="10" />
                          </FormControl>
                          <FormDescription>
                            Higher precision values produce more accurate fractions for repeating decimals.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Convert to Fraction</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Results</CardTitle>
                <CardDescription>
                  Decimal to fraction conversion results.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {decimalResult && activeTab === "decimal" ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold mb-2">
                        <span>{decimalForm.getValues().decimal}</span>
                        <span className="mx-2">=</span>
                        <span className="inline-block text-center">
                          <span className="block">{decimalResult.fraction.numerator}</span>
                          <span className="block border-t border-black mx-2 my-1"></span>
                          <span className="block">{decimalResult.fraction.denominator}</span>
                        </span>
                      </div>
                      
                      {decimalResult.mixed && (
                        <div className="mt-4">
                          <h3 className="text-lg font-medium">Mixed Number Form</h3>
                          <div className="text-xl mt-2">
                            <span>
                              {decimalResult.mixed.whole} 
                              <span className="inline-block text-center ml-2">
                                <span className="block">{decimalResult.mixed.numerator}</span>
                                <span className="block border-t border-black mx-1 my-1"></span>
                                <span className="block">{decimalResult.mixed.denominator}</span>
                              </span>
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-2">Step-by-Step Solution</h3>
                      <ol className="list-decimal pl-5 space-y-1 text-sm">
                        {decimalResult.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <Calculator className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>Enter a decimal number and click "Convert to Fraction" to see the results.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Fractions and Calculations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This calculator helps you perform various operations with fractions, mixed numbers, and also convert between 
                decimal and fraction representations. Understanding fractions is essential for many areas of mathematics and 
                everyday applications.
              </p>
              
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Fraction Operations</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                    <li>
                      <strong>Addition/Subtraction:</strong> First find a common denominator, then add or subtract the numerators.
                    </li>
                    <li>
                      <strong>Multiplication:</strong> Multiply the numerators and multiply the denominators.
                    </li>
                    <li>
                      <strong>Division:</strong> Multiply by the reciprocal of the second fraction (flip the numerator and denominator).
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Mixed Numbers</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                    <li>
                      <strong>Mixed to Improper:</strong> Multiply the whole number by the denominator, add the numerator, and 
                      put over the original denominator.
                    </li>
                    <li>
                      <strong>Improper to Mixed:</strong> Divide the numerator by the denominator to get the whole number, and 
                      the remainder becomes the new numerator.
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Simplifying Fractions</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                    <li>
                      <strong>Greatest Common Divisor (GCD):</strong> Find the largest number that divides both numerator and denominator.
                    </li>
                    <li>
                      <strong>Simplify:</strong> Divide both numerator and denominator by their GCD to get the simplest form.
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4">
                <h3 className="text-lg font-medium text-gray-900">Decimal to Fraction Conversion</h3>
                <p className="text-sm mt-1">
                  To convert a decimal to a fraction, multiply by powers of 10 to remove the decimal places, then simplify. 
                  For repeating decimals, more advanced techniques are needed, which this calculator helps automate.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default FractionCalculator;
