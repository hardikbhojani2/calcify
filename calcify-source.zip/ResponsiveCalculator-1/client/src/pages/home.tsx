import React from 'react';
import NavBar from '@/components/nav-bar';
import HeroSection from '@/components/hero-section';
import SearchBar from '@/components/search-bar';
import CategorySection from '@/components/category-section';
import Footer from '@/components/footer';
import { 
  financialCalculators, 
  fitnessCalculators, 
  mathCalculators, 
  otherCalculators 
} from '@/data/calculators';
import { filterCalculators } from '@/lib/utils';

const Home: React.FC = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  
  // Filter calculators based on search term
  const filteredFinancial = filterCalculators(searchTerm, financialCalculators);
  const filteredFitness = filterCalculators(searchTerm, fitnessCalculators);
  const filteredMath = filterCalculators(searchTerm, mathCalculators);
  const filteredOther = filterCalculators(searchTerm, otherCalculators);
  
  // Check if any category has results
  const hasFinancialResults = filteredFinancial.length > 0;
  const hasFitnessResults = filteredFitness.length > 0;
  const hasMathResults = filteredMath.length > 0;
  const hasOtherResults = filteredOther.length > 0;
  
  // Check if any results exist
  const hasAnyResults = hasFinancialResults || hasFitnessResults || hasMathResults || hasOtherResults;
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      <HeroSection />
      
      <main>
        <SearchBar 
          searchTerm={searchTerm} 
          onSearchChange={setSearchTerm} 
        />
        
        <div id="categories" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {!hasAnyResults && searchTerm.trim() !== '' ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-medium text-gray-900">No calculators found</h3>
              <p className="mt-1 text-sm text-gray-500">
                Try a different search term or browse our categories below.
              </p>
            </div>
          ) : (
            <>
              {hasFinancialResults && (
                <CategorySection 
                  id="financial" 
                  title="Financial Calculators" 
                  icon="fas fa-landmark" 
                  iconClass="text-primary" 
                  calculators={filteredFinancial} 
                  category="financial" 
                />
              )}
              
              {hasFitnessResults && (
                <CategorySection 
                  id="fitness" 
                  title="Fitness & Health Calculators" 
                  icon="fas fa-heartbeat" 
                  iconClass="text-secondary" 
                  calculators={filteredFitness} 
                  category="fitness" 
                />
              )}
              
              {hasMathResults && (
                <CategorySection 
                  id="math" 
                  title="Math Calculators" 
                  icon="fas fa-square-root-alt" 
                  iconClass="text-accent" 
                  calculators={filteredMath} 
                  category="math" 
                />
              )}
              
              {hasOtherResults && (
                <CategorySection 
                  id="other" 
                  title="Other Calculators" 
                  icon="fas fa-tools" 
                  iconClass="text-gray-600" 
                  calculators={filteredOther} 
                  category="other" 
                />
              )}
            </>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
