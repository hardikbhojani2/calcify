import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Map, Calculator, DollarSign, Activity, Brain, Settings } from 'lucide-react';
import { Link } from 'wouter';
import { financialCalculators, fitnessCalculators, mathCalculators, otherCalculators } from "@/data/calculators";

const Sitemap: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Map className="mr-2 h-8 w-8" /> Sitemap
          </h1>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Website Navigation</CardTitle>
            <CardDescription>
              Browse all pages and calculators available on our website
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h2 className="text-xl font-semibold mb-3 flex items-center">
                  <Calculator className="mr-2 h-5 w-5" /> Main Pages
                </h2>
                <ul className="space-y-2">
                  <li>
                    <Link href="/" className="text-blue-600 hover:underline flex items-center">
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link href="/about" className="text-blue-600 hover:underline flex items-center">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-blue-600 hover:underline flex items-center">
                      Contact Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/terms" className="text-blue-600 hover:underline flex items-center">
                      Terms of Service
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-blue-600 hover:underline flex items-center">
                      Privacy Policy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="mr-2 h-5 w-5" /> Financial Calculators
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {financialCalculators.map((calc) => (
                  <li key={calc.url}>
                    <Link href={calc.url} className="text-blue-600 hover:underline">
                      {calc.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="mr-2 h-5 w-5" /> Fitness & Health Calculators
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {fitnessCalculators.map((calc) => (
                  <li key={calc.url}>
                    <Link href={calc.url} className="text-blue-600 hover:underline">
                      {calc.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="mr-2 h-5 w-5" /> Math Calculators
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {mathCalculators.map((calc) => (
                  <li key={calc.url}>
                    <Link href={calc.url} className="text-blue-600 hover:underline">
                      {calc.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2 h-5 w-5" /> Other Calculators
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {otherCalculators.map((calc) => (
                  <li key={calc.url}>
                    <Link href={calc.url} className="text-blue-600 hover:underline">
                      {calc.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Sitemap;
