import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Dices, Copy, RefreshCw } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema with zod
const singleNumberSchema = z.object({
  min: z.coerce.number(),
  max: z.coerce.number().refine(val => val > 0, {
    message: "Maximum value must be greater than 0",
  }),
  allowDecimals: z.boolean().default(false),
  decimalPlaces: z.coerce.number().min(0).max(10).default(2),
}).refine(data => data.max > data.min, {
  message: "Maximum value must be greater than minimum value",
  path: ["max"],
});

const multipleNumbersSchema = z.object({
  min: z.coerce.number(),
  max: z.coerce.number(),
  count: z.coerce.number().min(1).max(1000),
  allowDuplicates: z.boolean().default(true),
  sortResults: z.boolean().default(false),
}).refine(data => data.max > data.min, {
  message: "Maximum value must be greater than minimum value",
  path: ["max"],
}).refine(data => !(!data.allowDuplicates && (data.max - data.min + 1) < data.count), {
  message: "Cannot generate that many unique numbers in the given range",
  path: ["count"],
});

type SingleNumberFormValues = z.infer<typeof singleNumberSchema>;
type MultipleNumbersFormValues = z.infer<typeof multipleNumbersSchema>;

const RandomNumberGenerator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("single");
  const [singleResult, setSingleResult] = useState<number | null>(null);
  const [multipleResults, setMultipleResults] = useState<number[] | null>(null);

  // Initialize the form for single number generator
  const singleForm = useForm<SingleNumberFormValues>({
    resolver: zodResolver(singleNumberSchema),
    defaultValues: {
      min: 1,
      max: 100,
      allowDecimals: false,
      decimalPlaces: 2,
    },
  });
  
  // Initialize the form for multiple numbers generator
  const multipleForm = useForm<MultipleNumbersFormValues>({
    resolver: zodResolver(multipleNumbersSchema),
    defaultValues: {
      min: 1,
      max: 100,
      count: 6,
      allowDuplicates: true,
      sortResults: false,
    },
  });

  // Watch for form value changes
  const allowDecimals = singleForm.watch('allowDecimals');

  // Function to generate a single random number
  const generateSingleNumber = (values: SingleNumberFormValues): number => {
    const { min, max, allowDecimals, decimalPlaces } = values;
    
    let result: number;
    if (allowDecimals) {
      // Generate a random decimal number
      result = Math.random() * (max - min) + min;
      // Round to the specified number of decimal places
      const multiplier = Math.pow(10, decimalPlaces);
      result = Math.round(result * multiplier) / multiplier;
    } else {
      // Generate a random integer
      result = Math.floor(Math.random() * (max - min + 1)) + min;
    }
    
    return result;
  };
  
  // Function to generate multiple random numbers
  const generateMultipleNumbers = (values: MultipleNumbersFormValues): number[] => {
    const { min, max, count, allowDuplicates, sortResults } = values;
    
    // For unique numbers (no duplicates)
    if (!allowDuplicates) {
      // Create an array of all possible numbers in the range
      const allNumbers = Array.from(
        { length: max - min + 1 },
        (_, i) => min + i
      );
      
      // Shuffle the array using Fisher-Yates algorithm
      for (let i = allNumbers.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [allNumbers[i], allNumbers[j]] = [allNumbers[j], allNumbers[i]];
      }
      
      // Take the first 'count' elements
      const result = allNumbers.slice(0, count);
      
      // Sort if requested
      if (sortResults) {
        result.sort((a, b) => a - b);
      }
      
      return result;
    } 
    // For numbers with potential duplicates
    else {
      const result = [];
      
      for (let i = 0; i < count; i++) {
        result.push(Math.floor(Math.random() * (max - min + 1)) + min);
      }
      
      // Sort if requested
      if (sortResults) {
        result.sort((a, b) => a - b);
      }
      
      return result;
    }
  };

  // Function to copy results to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: 'Copied!',
        description: 'Results copied to clipboard.',
      });
    }).catch(err => {
      toast({
        title: 'Copy Failed',
        description: 'Could not copy to clipboard.',
        variant: 'destructive',
      });
    });
  };

  // Form submission handlers
  const onSingleSubmit = (values: SingleNumberFormValues) => {
    try {
      const result = generateSingleNumber(values);
      setSingleResult(result);
      toast({
        title: 'Number Generated',
        description: 'Your random number has been generated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error generating your random number.',
        variant: 'destructive',
      });
    }
  };
  
  const onMultipleSubmit = (values: MultipleNumbersFormValues) => {
    try {
      const results = generateMultipleNumbers(values);
      setMultipleResults(results);
      toast({
        title: 'Numbers Generated',
        description: `${results.length} random numbers have been generated successfully.`,
      });
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error generating your random numbers.',
        variant: 'destructive',
      });
    }
  };
  
  // Function to quickly regenerate without form submission
  const quickRegenerateSingle = () => {
    try {
      const result = generateSingleNumber(singleForm.getValues());
      setSingleResult(result);
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error generating your random number.',
        variant: 'destructive',
      });
    }
  };
  
  const quickRegenerateMultiple = () => {
    try {
      const results = generateMultipleNumbers(multipleForm.getValues());
      setMultipleResults(results);
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error generating your random numbers.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Dices className="mr-2 h-8 w-8" /> Random Number Generator
          </h1>
        </div>
        
        <Tabs defaultValue="single" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="single">Single Number</TabsTrigger>
            <TabsTrigger value="multiple">Multiple Numbers</TabsTrigger>
          </TabsList>
          
          {/* Single Number Tab */}
          <TabsContent value="single" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate a Random Number</CardTitle>
                <CardDescription>
                  Customize the range and type of number to generate.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...singleForm}>
                  <form onSubmit={singleForm.handleSubmit(onSingleSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={singleForm.control}
                        name="min"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimum Value</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step={allowDecimals ? "0.01" : "1"} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={singleForm.control}
                        name="max"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maximum Value</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step={allowDecimals ? "0.01" : "1"} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={singleForm.control}
                      name="allowDecimals"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Allow Decimal Numbers
                            </FormLabel>
                            <FormDescription>
                              Generate numbers with decimal places
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {allowDecimals && (
                      <FormField
                        control={singleForm.control}
                        name="decimalPlaces"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Decimal Places: {field.value}</FormLabel>
                            <FormControl>
                              <Slider
                                min={0}
                                max={10}
                                step={1}
                                defaultValue={[field.value]}
                                onValueChange={(value) => field.onChange(value[0])}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    
                    <Button type="submit" className="w-full">Generate Number</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Random Number Result</CardTitle>
                <CardDescription>
                  Your generated random number.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {singleResult !== null ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-4xl font-bold text-primary break-all">
                        {singleResult}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant="outline" 
                        className="flex items-center gap-2"
                        onClick={() => copyToClipboard(singleResult.toString())}
                      >
                        <Copy className="h-4 w-4" /> Copy to Clipboard
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="flex items-center gap-2"
                        onClick={quickRegenerateSingle}
                      >
                        <RefreshCw className="h-4 w-4" /> Generate Again
                      </Button>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Parameters Used</h3>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Minimum Value:</div>
                          <div className="col-span-7">{singleForm.getValues().min}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Maximum Value:</div>
                          <div className="col-span-7">{singleForm.getValues().max}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Number Type:</div>
                          <div className="col-span-7">
                            {singleForm.getValues().allowDecimals ? 
                              `Decimal (${singleForm.getValues().decimalPlaces} places)` : 
                              "Integer"}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Click "Generate Number" to create a random number.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Multiple Numbers Tab */}
          <TabsContent value="multiple" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate Multiple Random Numbers</CardTitle>
                <CardDescription>
                  Generate a set of random numbers with custom parameters.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...multipleForm}>
                  <form onSubmit={multipleForm.handleSubmit(onMultipleSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={multipleForm.control}
                        name="min"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimum Value</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={multipleForm.control}
                        name="max"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maximum Value</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={multipleForm.control}
                      name="count"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>How many numbers? ({field.value})</FormLabel>
                          <FormControl>
                            <Slider
                              min={1}
                              max={100}
                              step={1}
                              defaultValue={[field.value]}
                              onValueChange={(value) => field.onChange(value[0])}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 gap-4">
                      <FormField
                        control={multipleForm.control}
                        name="allowDuplicates"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Allow Duplicate Numbers
                              </FormLabel>
                              <FormDescription>
                                Allow the same number to appear multiple times in the results
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={multipleForm.control}
                        name="sortResults"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Sort Results
                              </FormLabel>
                              <FormDescription>
                                Sort the generated numbers in ascending order
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">Generate Numbers</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Random Numbers Results</CardTitle>
                <CardDescription>
                  Your set of generated random numbers.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {multipleResults !== null ? (
                  <div className="space-y-6">
                    <div className="overflow-y-auto max-h-64 p-4 bg-gray-50 rounded-lg">
                      <div className="flex flex-wrap gap-2">
                        {multipleResults.map((num, index) => (
                          <div key={index} className="inline-block px-3 py-1 bg-primary text-primary-foreground rounded-full text-sm font-medium">
                            {num}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant="outline" 
                        className="flex items-center gap-2"
                        onClick={() => copyToClipboard(multipleResults.join(', '))}
                      >
                        <Copy className="h-4 w-4" /> Copy to Clipboard
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="flex items-center gap-2"
                        onClick={quickRegenerateMultiple}
                      >
                        <RefreshCw className="h-4 w-4" /> Generate Again
                      </Button>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Settings Summary</h3>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-12">
                          <div className="col-span-6 font-medium">Number Range:</div>
                          <div className="col-span-6">
                            {multipleForm.getValues().min} to {multipleForm.getValues().max}
                          </div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-6 font-medium">Numbers Generated:</div>
                          <div className="col-span-6">{multipleResults.length}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-6 font-medium">Duplicates Allowed:</div>
                          <div className="col-span-6">
                            {multipleForm.getValues().allowDuplicates ? "Yes" : "No"}
                          </div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-6 font-medium">Sorted:</div>
                          <div className="col-span-6">
                            {multipleForm.getValues().sortResults ? "Yes" : "No"}
                          </div>
                        </div>
                      </div>
                    </div>

                    {!multipleForm.getValues().allowDuplicates && (
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h3 className="font-medium text-blue-800 mb-2">Note</h3>
                        <p className="text-sm text-gray-600">
                          Since duplicates are not allowed, the maximum number of unique values possible is 
                          {multipleForm.getValues().max - multipleForm.getValues().min + 1}.
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Click "Generate Numbers" to create a set of random numbers.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Random Number Generation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our random number generator uses JavaScript's built-in pseudo-random number generator to create random values. The generator offers two main functions:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Single Number Generation</strong>: Generate a random number within a specified range, with options for integers or decimal numbers.</li>
                  <li><strong>Multiple Number Generation</strong>: Create sets of random numbers with options for duplicates, sorting, and quantity.</li>
                </ul>
                <p>Common uses for random number generation include:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Selecting winners for contests or drawings</li>
                  <li>Creating random samples for statistical analysis</li>
                  <li>Generating lottery numbers or dice rolls for games</li>
                  <li>Simulation and modeling in scientific applications</li>
                  <li>Randomizing test cases in software development</li>
                </ul>
                <p className="text-gray-500">Note: While this generator is suitable for most everyday uses, it may not be appropriate for cryptographic applications or where high-quality randomness is critical.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RandomNumberGenerator;
