import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Baby, CalendarDays, Calendar as CalendarIcon, Check } from 'lucide-react';
import { Link } from 'wouter';
import { format } from 'date-fns';

// Define the form schema
const pregnancySchema = z.object({
  lastPeriodDate: z.date({
    required_error: "Please select a date",
  }),
  cycleLength: z.coerce.number().int().min(20, "Cycle length must be at least 20 days").max(45, "Cycle length must be at most 45 days").default(28),
});

type FormValues = z.infer<typeof pregnancySchema>;

interface PregnancyMilestone {
  week: number;
  title: string;
  description: string;
  babySize: string;
  babyWeight: string;
  babyLength: string;
  developmentHighlights: string[];
  maternalChanges: string[];
}

const pregnancyMilestones: PregnancyMilestone[] = [
  {
    week: 4,
    title: "First Month",
    description: "Implantation occurs as the blastocyst attaches to the uterine lining. The placenta begins to form.",
    babySize: "Poppy seed",
    babyWeight: "Less than 0.04 oz",
    babyLength: "0.014-0.04 inches",
    developmentHighlights: [
      "Neural tube begins to form (will become the brain and spinal cord)",
      "Heart and circulatory system begin to form",
      "Basic facial features begin to appear"
    ],
    maternalChanges: [
      "Possible implantation bleeding",
      "Missed period",
      "Fatigue and tiredness",
      "Breast tenderness"
    ]
  },
  {
    week: 8,
    title: "Second Month",
    description: "All essential organs begin to develop. Baby's heartbeat may be detectable by ultrasound.",
    babySize: "Kidney bean",
    babyWeight: "0.04-0.1 oz",
    babyLength: "0.6-0.7 inches",
    developmentHighlights: [
      "Heart beats at about 150-170 beats per minute",
      "Arms, legs, fingers and toes begin to form",
      "Brain development accelerates",
      "Digestive tract and sensory organs begin to develop"
    ],
    maternalChanges: [
      "Morning sickness may peak",
      "Frequent urination",
      "Food aversions and cravings",
      "Mood swings"
    ]
  },
  {
    week: 12,
    title: "First Trimester Complete",
    description: "Baby's systems are formed and now need to mature. Risk of miscarriage decreases significantly.",
    babySize: "Lime",
    babyWeight: "0.5-1 oz",
    babyLength: "2.1-2.9 inches",
    developmentHighlights: [
      "Reflexes develop",
      "External genitalia begin to differentiate",
      "Fingernails and toenails form",
      "Baby begins to make movements (though not felt yet)"
    ],
    maternalChanges: [
      "Uterus expands beyond the pelvis",
      "Some symptoms may improve (like nausea)",
      "Possible visible baby bump",
      "Increased vaginal discharge"
    ]
  },
  {
    week: 16,
    title: "Second Trimester Begins",
    description: "Baby's movements may become noticeable. Sex determination is usually possible by ultrasound.",
    babySize: "Avocado",
    babyWeight: "3-4 oz",
    babyLength: "4.3-4.6 inches",
    developmentHighlights: [
      "Baby can make facial expressions",
      "Hearing develops",
      "Skin is thin and transparent",
      "Skeleton begins to harden from cartilage to bone"
    ],
    maternalChanges: [
      "Energy levels may increase",
      "Morning sickness typically decreases",
      "Weight gain becomes more apparent",
      "May begin to feel baby's movements (quickening)"
    ]
  },
  {
    week: 20,
    title: "Halfway Point",
    description: "Detailed anatomy scan typically performed. Baby develops a regular sleep-wake cycle.",
    babySize: "Banana",
    babyWeight: "9-11 oz",
    babyLength: "6.5-7 inches",
    developmentHighlights: [
      "Baby can swallow",
      "Hair (including eyebrows and lashes) starts to grow",
      "Organs continue to mature",
      "Baby is more active with defined sleeping and waking periods"
    ],
    maternalChanges: [
      "Baby's movements become more noticeable",
      "Uterus reaches the navel",
      "Possible back pain",
      "Possible appearance of stretch marks"
    ]
  },
  {
    week: 24,
    title: "Viability",
    description: "Baby reaches viability—the point where survival outside the womb becomes possible, though still challenging.",
    babySize: "Corn",
    babyWeight: "1.3 pounds",
    babyLength: "11.8 inches",
    developmentHighlights: [
      "Lungs begin to produce surfactant",
      "Taste buds fully formed",
      "Brain develops rapidly",
      "Footprints and fingerprints are forming"
    ],
    maternalChanges: [
      "Braxton Hicks contractions may begin",
      "Belly button may protrude",
      "Balance may be affected",
      "Sleeping may become more difficult"
    ]
  },
  {
    week: 28,
    title: "Third Trimester Begins",
    description: "Baby's brain and nervous system are developing rapidly. Eyes open and close.",
    babySize: "Eggplant",
    babyWeight: "2.2-2.5 pounds",
    babyLength: "14-15 inches",
    developmentHighlights: [
      "Baby can blink and has eyelashes",
      "Rapid brain development continues",
      "Begins to regulate body temperature",
      "Can respond to sound and light"
    ],
    maternalChanges: [
      "Shortness of breath as baby pushes against diaphragm",
      "Possible leg cramps",
      "Hemorrhoids and varicose veins may develop",
      "Frequent urination returns"
    ]
  },
  {
    week: 32,
    title: "Development Continues",
    description: "Baby practises breathing movements and gains weight rapidly.",
    babySize: "Squash",
    babyWeight: "3.5-4 pounds",
    babyLength: "16-17 inches",
    developmentHighlights: [
      "Lungs are more developed but not fully mature",
      "Baby fat increases",
      "Bones are fully developed but still soft",
      "May settle into birth position"
    ],
    maternalChanges: [
      "Colostrum may leak from breasts",
      "Difficulty finding comfortable sleeping positions",
      "Swelling in ankles and feet",
      "Braxton Hicks contractions more frequent"
    ]
  },
  {
    week: 36,
    title: "Almost There",
    description: "Baby is considered early term. Lungs are almost fully mature.",
    babySize: "Honeydew melon",
    babyWeight: "5-6 pounds",
    babyLength: "18-19 inches",
    developmentHighlights: [
      "Baby gains about 1/2 pound each week",
      "Immune system developing",
      "Most babies turn head-down position",
      "Baby is running out of room to move"
    ],
    maternalChanges: [
      "Pelvis may feel loose as hormones relax joints",
      "Baby may 'drop' into pelvis (lightening)",
      "Stronger, more frequent Braxton Hicks",
      "Increased pressure on bladder"
    ]
  },
  {
    week: 40,
    title: "Due Date",
    description: "Full-term pregnancy. Baby is ready to be born.",
    babySize: "Small pumpkin",
    babyWeight: "7-8 pounds",
    babyLength: "19-21 inches",
    developmentHighlights: [
      "Lungs are fully mature",
      "Reflexes are coordinated",
      "Brain continues to develop rapidly",
      "Baby's skull bones are not yet fused to allow for passage through birth canal"
    ],
    maternalChanges: [
      "Cervix begins to efface and dilate",
      "Baby's head may engage deeper in pelvis",
      "Possible mucus plug discharge",
      "Possible bloody show as labor approaches"
    ]
  }
];

const PregnancyCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("progress");
  const [pregnancyResult, setPregnancyResult] = useState<{
    dueDate: Date;
    conceptionDate: Date;
    currentWeek: number;
    currentDay: number;
    trimester: number;
    progress: number;
  } | null>(null);

  // Initialize form for tracking progress
  const form = useForm<FormValues>({
    resolver: zodResolver(pregnancySchema),
    defaultValues: {
      lastPeriodDate: new Date(),
      cycleLength: 28,
    },
  });

  // Calculate pregnancy dates and progress
  const calculatePregnancyDates = (values: FormValues) => {
    const { lastPeriodDate, cycleLength } = values;
    
    // Calculate conception date (approximately 2 weeks after LMP for 28-day cycle)
    const ovulationDay = cycleLength - 14;
    const conceptionDate = new Date(lastPeriodDate);
    conceptionDate.setDate(conceptionDate.getDate() + ovulationDay);
    
    // Calculate due date (280 days or 40 weeks from LMP)
    const dueDate = new Date(lastPeriodDate);
    dueDate.setDate(dueDate.getDate() + 280);
    
    // Calculate current progress
    const today = new Date();
    
    // Calculate total days pregnant (from LMP)
    const daysSinceLMP = Math.floor((today.getTime() - lastPeriodDate.getTime()) / (1000 * 60 * 60 * 24));
    
    // Calculate current week and day
    const currentWeek = Math.floor(daysSinceLMP / 7);
    const currentDay = daysSinceLMP % 7;
    
    // Calculate trimester (1: weeks 0-13, 2: weeks 14-26, 3: weeks 27-40+)
    let trimester = 1;
    if (currentWeek >= 27) {
      trimester = 3;
    } else if (currentWeek >= 14) {
      trimester = 2;
    }
    
    // Calculate progress percentage (out of 40 weeks)
    const progress = Math.min(Math.round((daysSinceLMP / 280) * 100), 100);
    
    return {
      dueDate,
      conceptionDate,
      currentWeek,
      currentDay,
      trimester,
      progress
    };
  };

  // Get milestone information for current week
  const getCurrentMilestone = (week: number) => {
    // Find the closest milestone that's not ahead of current week
    let closestMilestone = pregnancyMilestones[0];
    
    for (const milestone of pregnancyMilestones) {
      if (milestone.week <= week && milestone.week > closestMilestone.week) {
        closestMilestone = milestone;
      }
    }
    
    return closestMilestone;
  };

  // Get next milestone
  const getNextMilestone = (week: number) => {
    for (const milestone of pregnancyMilestones) {
      if (milestone.week > week) {
        return milestone;
      }
    }
    
    // If at or beyond all milestones, return the last one
    return pregnancyMilestones[pregnancyMilestones.length - 1];
  };

  // Handler for form submission
  const onSubmit = (values: FormValues) => {
    const result = calculatePregnancyDates(values);
    setPregnancyResult(result);
    setActiveTab("progress");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Baby className="mr-2 h-8 w-8" /> Pregnancy Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Due Date</CardTitle>
                <CardDescription>
                  Estimate your due date and track pregnancy milestones.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="lastPeriodDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>First Day of Last Period</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={"w-full pl-3 text-left font-normal"}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormDescription>
                            The first day of your most recent menstrual period.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="cycleLength"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Average Cycle Length</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} min="20" max="45" />
                          </FormControl>
                          <FormDescription>
                            Average number of days from the first day of one period to the first day of the next.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Due Date</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {pregnancyResult && (
              <Card>
                <CardHeader>
                  <CardTitle>Your Pregnancy Dates</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Due Date:</p>
                    <p className="text-lg font-semibold">{format(pregnancyResult.dueDate, "PPPP")}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-gray-500">Estimated Conception:</p>
                    <p className="text-lg font-semibold">{format(pregnancyResult.conceptionDate, "PPPP")}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-gray-500">Current Progress:</p>
                    <div className="mt-1">
                      <Progress value={pregnancyResult.progress} className="h-2" />
                      <div className="flex justify-between text-xs mt-1">
                        <span>First Trimester</span>
                        <span>Second Trimester</span>
                        <span>Third Trimester</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div className="bg-primary/10 p-3 rounded-lg text-center">
                      <p className="text-sm text-gray-500">Current Week</p>
                      <p className="text-2xl font-bold text-primary">{pregnancyResult.currentWeek}</p>
                      <p className="text-xs">Day {pregnancyResult.currentDay}</p>
                    </div>
                    
                    <div className="bg-primary/10 p-3 rounded-lg text-center">
                      <p className="text-sm text-gray-500">Trimester</p>
                      <p className="text-2xl font-bold text-primary">{pregnancyResult.trimester}</p>
                      <p className="text-xs">of 3</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="md:col-span-2">
            {pregnancyResult ? (
              <Card className="h-full">
                <CardHeader>
                  <Tabs defaultValue="progress" onValueChange={setActiveTab} value={activeTab}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="progress">Weekly Progress</TabsTrigger>
                      <TabsTrigger value="current">Current Milestone</TabsTrigger>
                      <TabsTrigger value="next">Next Milestone</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </CardHeader>
                <CardContent>
                  {activeTab === "progress" && (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-semibold">Week {pregnancyResult.currentWeek}</h3>
                        <div className="text-sm text-gray-500">
                          {40 - pregnancyResult.currentWeek} weeks until due date
                        </div>
                      </div>
                      
                      <div className="relative">
                        <div className="absolute top-0 left-0 w-full h-2 bg-gray-200 rounded-full">
                          <div 
                            className="absolute top-0 left-0 h-2 bg-primary rounded-full" 
                            style={{ width: `${(pregnancyResult.currentWeek / 40) * 100}%` }}
                          ></div>
                        </div>
                        
                        <div className="flex justify-between mt-4 text-xs text-gray-500">
                          <span>Week 0</span>
                          <span>Week 13</span>
                          <span>Week 27</span>
                          <span>Week 40</span>
                        </div>
                        
                        <div className="flex justify-between mt-1 text-xs font-medium">
                          <span>First Trimester</span>
                          <span>Second Trimester</span>
                          <span>Third Trimester</span>
                        </div>
                      </div>
                      
                      {pregnancyResult.currentWeek <= 0 ? (
                        <div className="text-center py-10 border rounded-lg my-6">
                          <CalendarDays className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                          <h3 className="text-lg font-medium mb-2">Getting Started</h3>
                          <p className="text-gray-500 max-w-md mx-auto">
                            Your pregnancy is just beginning! Pregnancy is calculated from the first day of your last period,
                            even though conception typically occurs about 2 weeks later.
                          </p>
                        </div>
                      ) : pregnancyResult.currentWeek > 42 ? (
                        <div className="text-center py-10 border rounded-lg my-6">
                          <Baby className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                          <h3 className="text-lg font-medium mb-2">Past Due Date</h3>
                          <p className="text-gray-500 max-w-md mx-auto">
                            You are past your estimated due date. Only about 5% of babies are born on their actual due date,
                            and it's normal to deliver between 38 and 42 weeks. Consult with your healthcare provider about next steps.
                          </p>
                        </div>
                      ) : (
                        <div className="grid md:grid-cols-3 gap-6 my-6">
                          <div className="space-y-4">
                            <h3 className="text-lg font-medium">Baby Size</h3>
                            <div className="p-4 bg-primary/10 rounded-lg">
                              <div className="text-center">
                                <p className="text-sm text-gray-500 mb-1">Your baby is about the size of a</p>
                                <p className="text-xl font-semibold">
                                  {getCurrentMilestone(pregnancyResult.currentWeek).babySize}
                                </p>
                              </div>
                              
                              <Separator className="my-4" />
                              
                              <div className="grid grid-cols-2 gap-2 text-sm">
                                <div>
                                  <p className="text-gray-500">Weight:</p>
                                  <p className="font-medium">
                                    {getCurrentMilestone(pregnancyResult.currentWeek).babyWeight}
                                  </p>
                                </div>
                                
                                <div>
                                  <p className="text-gray-500">Length:</p>
                                  <p className="font-medium">
                                    {getCurrentMilestone(pregnancyResult.currentWeek).babyLength}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-4 md:col-span-2">
                            <h3 className="text-lg font-medium">Baby Development</h3>
                            <div className="space-y-2">
                              {getCurrentMilestone(pregnancyResult.currentWeek).developmentHighlights.map((highlight, index) => (
                                <div key={index} className="flex items-start">
                                  <Check className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                                  <p className="text-sm">{highlight}</p>
                                </div>
                              ))}
                            </div>
                            
                            <h3 className="text-lg font-medium mt-6">Changes for Mom</h3>
                            <div className="space-y-2">
                              {getCurrentMilestone(pregnancyResult.currentWeek).maternalChanges.map((change, index) => (
                                <div key={index} className="flex items-start">
                                  <Check className="h-4 w-4 text-primary mr-2 mt-0.5" />
                                  <p className="text-sm">{change}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {activeTab === "current" && (
                    <div className="space-y-6">
                      {pregnancyResult.currentWeek > 0 ? (
                        <>
                          <div className="text-center py-4">
                            <h3 className="text-xl font-bold">
                              {getCurrentMilestone(pregnancyResult.currentWeek).title}
                            </h3>
                            <p className="text-sm text-gray-500 mt-1">
                              Week {getCurrentMilestone(pregnancyResult.currentWeek).week}
                            </p>
                          </div>
                          
                          <p className="text-gray-600">
                            {getCurrentMilestone(pregnancyResult.currentWeek).description}
                          </p>
                          
                          <div className="grid md:grid-cols-2 gap-6 mt-6">
                            <div>
                              <h4 className="font-medium mb-3">Baby Development Highlights</h4>
                              <div className="space-y-2">
                                {getCurrentMilestone(pregnancyResult.currentWeek).developmentHighlights.map((highlight, index) => (
                                  <div key={index} className="flex items-start">
                                    <Check className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                                    <p className="text-sm">{highlight}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            
                            <div>
                              <h4 className="font-medium mb-3">Maternal Changes</h4>
                              <div className="space-y-2">
                                {getCurrentMilestone(pregnancyResult.currentWeek).maternalChanges.map((change, index) => (
                                  <div key={index} className="flex items-start">
                                    <Check className="h-4 w-4 text-primary mr-2 mt-0.5" />
                                    <p className="text-sm">{change}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 mt-6">
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Size</p>
                              <p className="font-medium">
                                {getCurrentMilestone(pregnancyResult.currentWeek).babySize}
                              </p>
                            </div>
                            
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Weight</p>
                              <p className="font-medium">
                                {getCurrentMilestone(pregnancyResult.currentWeek).babyWeight}
                              </p>
                            </div>
                            
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Length</p>
                              <p className="font-medium">
                                {getCurrentMilestone(pregnancyResult.currentWeek).babyLength}
                              </p>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="text-center py-10">
                          <CalendarDays className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                          <h3 className="text-lg font-medium mb-2">Getting Started</h3>
                          <p className="text-gray-500 max-w-md mx-auto">
                            You are in the pre-embryonic stage. While conception hasn't occurred yet,
                            your healthcare provider counts pregnancy from the first day of your last period.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {activeTab === "next" && (
                    <div className="space-y-6">
                      {pregnancyResult.currentWeek < 40 ? (
                        <>
                          <div className="text-center py-4">
                            <h3 className="text-xl font-bold">
                              {getNextMilestone(pregnancyResult.currentWeek).title}
                            </h3>
                            <p className="text-sm text-gray-500 mt-1">
                              Week {getNextMilestone(pregnancyResult.currentWeek).week}
                            </p>
                            <p className="text-sm text-primary mt-1">
                              {getNextMilestone(pregnancyResult.currentWeek).week - pregnancyResult.currentWeek} weeks away
                            </p>
                          </div>
                          
                          <p className="text-gray-600">
                            {getNextMilestone(pregnancyResult.currentWeek).description}
                          </p>
                          
                          <div className="grid md:grid-cols-2 gap-6 mt-6">
                            <div>
                              <h4 className="font-medium mb-3">Coming Up for Baby</h4>
                              <div className="space-y-2">
                                {getNextMilestone(pregnancyResult.currentWeek).developmentHighlights.map((highlight, index) => (
                                  <div key={index} className="flex items-start">
                                    <Check className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                                    <p className="text-sm">{highlight}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            
                            <div>
                              <h4 className="font-medium mb-3">Changes to Expect</h4>
                              <div className="space-y-2">
                                {getNextMilestone(pregnancyResult.currentWeek).maternalChanges.map((change, index) => (
                                  <div key={index} className="flex items-start">
                                    <Check className="h-4 w-4 text-primary mr-2 mt-0.5" />
                                    <p className="text-sm">{change}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 mt-6">
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Size</p>
                              <p className="font-medium">
                                {getNextMilestone(pregnancyResult.currentWeek).babySize}
                              </p>
                            </div>
                            
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Weight</p>
                              <p className="font-medium">
                                {getNextMilestone(pregnancyResult.currentWeek).babyWeight}
                              </p>
                            </div>
                            
                            <div className="p-4 bg-primary/10 rounded-lg text-center">
                              <p className="text-sm text-gray-500 mb-1">Length</p>
                              <p className="font-medium">
                                {getNextMilestone(pregnancyResult.currentWeek).babyLength}
                              </p>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="text-center py-10">
                          <Baby className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                          <h3 className="text-lg font-medium mb-2">Ready for Birth!</h3>
                          <p className="text-gray-500 max-w-md mx-auto">
                            You've reached full term! Your baby is ready to be born.
                            Labor typically starts between 37 and 42 weeks, so it could begin any day now.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center py-16">
                    <Baby className="h-16 w-16 mx-auto text-gray-300 mb-6" />
                    <h3 className="text-xl font-medium mb-2">Track Your Pregnancy</h3>
                    <p className="text-gray-500 max-w-md">
                      Enter the first day of your last menstrual period to calculate your due date 
                      and track your pregnancy journey week by week.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Pregnancy Dating</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This pregnancy calculator uses the first day of your last menstrual period (LMP) to estimate your due date 
                and track pregnancy milestones. This is the method most healthcare providers use.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">How It Works</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>A typical pregnancy lasts about 40 weeks, or 280 days, from the first day of your last period.</li>
                    <li>Conception usually occurs about 2 weeks after the first day of your last period.</li>
                    <li>The estimated due date is calculated as LMP + 280 days.</li>
                    <li>Only about 5% of babies are born exactly on their estimated due date.</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Trimesters</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li><strong>First Trimester:</strong> Weeks 1-13 (Months 1-3)</li>
                    <li><strong>Second Trimester:</strong> Weeks 14-26 (Months 4-6)</li>
                    <li><strong>Third Trimester:</strong> Weeks 27-40+ (Months 7-9+)</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg mt-6">
                <h3 className="text-lg font-medium text-blue-800 mb-2">Important Note</h3>
                <p className="text-sm text-blue-700">
                  This calculator provides estimates only. For accurate dating and pregnancy care, consult with a healthcare provider. 
                  An ultrasound in early pregnancy provides the most accurate due date estimation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default PregnancyCalculator;
