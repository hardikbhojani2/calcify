import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Percent } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schemas with zod
const percentageOfSchema = z.object({
  percentage: z.coerce.number().min(0, "Percentage must be positive"),
  value: z.coerce.number()
});

const percentageChangeSchema = z.object({
  oldValue: z.coerce.number(),
  newValue: z.coerce.number()
});

const isWhatPercentSchema = z.object({
  part: z.coerce.number(),
  whole: z.coerce.number().refine(val => val !== 0, {
    message: "Whole value cannot be zero",
  })
});

type PercentageOfFormValues = z.infer<typeof percentageOfSchema>;
type PercentageChangeFormValues = z.infer<typeof percentageChangeSchema>;
type IsWhatPercentFormValues = z.infer<typeof isWhatPercentSchema>;

const PercentageCalculator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("percentage-of");
  
  const [percentageOfResult, setPercentageOfResult] = useState<number | null>(null);
  const [percentageChangeResult, setPercentageChangeResult] = useState<{
    percentageChange: number;
    absoluteChange: number;
    increase: boolean;
  } | null>(null);
  const [isWhatPercentResult, setIsWhatPercentResult] = useState<number | null>(null);

  // Initialize the forms with default values
  const percentageOfForm = useForm<PercentageOfFormValues>({
    resolver: zodResolver(percentageOfSchema),
    defaultValues: {
      percentage: 15,
      value: 100,
    },
  });
  
  const percentageChangeForm = useForm<PercentageChangeFormValues>({
    resolver: zodResolver(percentageChangeSchema),
    defaultValues: {
      oldValue: 100,
      newValue: 125,
    },
  });
  
  const isWhatPercentForm = useForm<IsWhatPercentFormValues>({
    resolver: zodResolver(isWhatPercentSchema),
    defaultValues: {
      part: 25,
      whole: 100,
    },
  });

  // Function to calculate percentage of a value
  const calculatePercentageOf = (values: PercentageOfFormValues): number => {
    return (values.percentage / 100) * values.value;
  };
  
  // Function to calculate percentage change
  const calculatePercentageChange = (values: PercentageChangeFormValues): { 
    percentageChange: number;
    absoluteChange: number;
    increase: boolean;
  } => {
    const absoluteChange = Math.abs(values.newValue - values.oldValue);
    const percentageChange = (absoluteChange / Math.abs(values.oldValue)) * 100;
    const increase = values.newValue > values.oldValue;
    
    return {
      percentageChange,
      absoluteChange,
      increase
    };
  };
  
  // Function to calculate what percent one number is of another
  const calculateIsWhatPercent = (values: IsWhatPercentFormValues): number => {
    return (values.part / values.whole) * 100;
  };
  
  // Update results when form values change
  React.useEffect(() => {
    if (percentageOfForm.formState.isValid && activeTab === "percentage-of") {
      const currentValues = percentageOfForm.getValues();
      try {
        const result = calculatePercentageOf(currentValues);
        setPercentageOfResult(result);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    percentageOfForm.watch('percentage'),
    percentageOfForm.watch('value'),
    percentageOfForm,
    activeTab
  ]);
  
  React.useEffect(() => {
    if (percentageChangeForm.formState.isValid && activeTab === "percentage-change") {
      const currentValues = percentageChangeForm.getValues();
      try {
        const result = calculatePercentageChange(currentValues);
        setPercentageChangeResult(result);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    percentageChangeForm.watch('oldValue'),
    percentageChangeForm.watch('newValue'),
    percentageChangeForm,
    activeTab
  ]);
  
  React.useEffect(() => {
    if (isWhatPercentForm.formState.isValid && activeTab === "is-what-percent") {
      const currentValues = isWhatPercentForm.getValues();
      try {
        const result = calculateIsWhatPercent(currentValues);
        setIsWhatPercentResult(result);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    isWhatPercentForm.watch('part'),
    isWhatPercentForm.watch('whole'),
    isWhatPercentForm,
    activeTab
  ]);

  // Form submission handlers
  const onPercentageOfSubmit = (values: PercentageOfFormValues) => {
    try {
      const result = calculatePercentageOf(values);
      setPercentageOfResult(result);
      toast({
        title: 'Calculation complete',
        description: `${values.percentage}% of ${values.value} is ${result.toFixed(2)}`,
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error performing the calculation.',
        variant: 'destructive',
      });
    }
  };
  
  const onPercentageChangeSubmit = (values: PercentageChangeFormValues) => {
    try {
      const result = calculatePercentageChange(values);
      setPercentageChangeResult(result);
      toast({
        title: 'Calculation complete',
        description: `The percentage change is ${result.percentageChange.toFixed(2)}%`,
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error performing the calculation.',
        variant: 'destructive',
      });
    }
  };
  
  const onIsWhatPercentSubmit = (values: IsWhatPercentFormValues) => {
    try {
      const result = calculateIsWhatPercent(values);
      setIsWhatPercentResult(result);
      toast({
        title: 'Calculation complete',
        description: `${values.part} is ${result.toFixed(2)}% of ${values.whole}`,
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error performing the calculation.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Percent className="mr-2 h-8 w-8" /> Percentage Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="percentage-of" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="percentage-of">Find % of a Number</TabsTrigger>
            <TabsTrigger value="percentage-change">% Change</TabsTrigger>
            <TabsTrigger value="is-what-percent">What % is X of Y</TabsTrigger>
          </TabsList>
          
          {/* Percentage Of Tab */}
          <TabsContent value="percentage-of" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Find Percentage of a Number</CardTitle>
                <CardDescription>
                  Calculate what percentage of a number is.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...percentageOfForm}>
                  <form onSubmit={percentageOfForm.handleSubmit(onPercentageOfSubmit)} className="space-y-6">
                    <FormField
                      control={percentageOfForm.control}
                      name="percentage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Percentage (%)</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Percent className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                              <Input {...field} type="number" step="any" className="pl-10" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={percentageOfForm.control}
                      name="value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Of Value</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormDescription>
                            The number you want to find a percentage of
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Result</CardTitle>
                <CardDescription>
                  The calculated percentage of the value.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {percentageOfResult !== null ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Result</div>
                      <div className="text-4xl font-bold text-primary">
                        {percentageOfResult.toFixed(2)}
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Calculation Breakdown</h3>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-12">
                          <div className="col-span-4 font-medium">Percentage:</div>
                          <div className="col-span-8">{percentageOfForm.getValues().percentage}%</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-4 font-medium">Value:</div>
                          <div className="col-span-8">{percentageOfForm.getValues().value}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-4 font-medium">Formula:</div>
                          <div className="col-span-8">
                            {percentageOfForm.getValues().percentage}% × {percentageOfForm.getValues().value} = {percentageOfResult.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Explanation</h3>
                      <p className="text-sm text-gray-600">
                        To find a percentage of a number, convert the percentage to a decimal by dividing by 100, 
                        then multiply by the value. In this case, {percentageOfForm.getValues().percentage}/100 × {percentageOfForm.getValues().value} = {percentageOfResult.toFixed(2)}.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter values to see the calculation result.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Percentage Change Tab */}
          <TabsContent value="percentage-change" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Percentage Change</CardTitle>
                <CardDescription>
                  Find the percentage increase or decrease between two values.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...percentageChangeForm}>
                  <form onSubmit={percentageChangeForm.handleSubmit(onPercentageChangeSubmit)} className="space-y-6">
                    <FormField
                      control={percentageChangeForm.control}
                      name="oldValue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Original Value</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={percentageChangeForm.control}
                      name="newValue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>New Value</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Change</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Percentage Change Result</CardTitle>
                <CardDescription>
                  The percentage change between the two values.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {percentageChangeResult !== null ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">
                        {percentageChangeResult.increase ? "Percentage Increase" : "Percentage Decrease"}
                      </div>
                      <div className="text-4xl font-bold text-primary">
                        {percentageChangeResult.percentageChange.toFixed(2)}%
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Change Details</h3>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Original Value:</div>
                          <div className="col-span-7">{percentageChangeForm.getValues().oldValue}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">New Value:</div>
                          <div className="col-span-7">{percentageChangeForm.getValues().newValue}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Absolute Change:</div>
                          <div className="col-span-7">{percentageChangeResult.absoluteChange.toFixed(2)}</div>
                        </div>
                        <div className="grid grid-cols-12">
                          <div className="col-span-5 font-medium">Direction:</div>
                          <div className="col-span-7 font-medium" style={{ color: percentageChangeResult.increase ? 'green' : 'red' }}>
                            {percentageChangeResult.increase ? "Increase ↑" : "Decrease ↓"}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Calculation Method</h3>
                      <p className="text-sm text-gray-600">
                        The percentage change is calculated as:<br />
                        <span className="font-mono">((New - Original) / |Original|) × 100%</span><br /><br />
                        In this case:<br />
                        <span className="font-mono">
                          (({percentageChangeForm.getValues().newValue} - {percentageChangeForm.getValues().oldValue}) / |{percentageChangeForm.getValues().oldValue}|) × 100% = {percentageChangeResult.percentageChange.toFixed(2)}%
                        </span>
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter values to see the percentage change.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Is What Percent Tab */}
          <TabsContent value="is-what-percent" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>What Percentage Is X of Y?</CardTitle>
                <CardDescription>
                  Calculate what percentage one number is of another.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...isWhatPercentForm}>
                  <form onSubmit={isWhatPercentForm.handleSubmit(onIsWhatPercentSubmit)} className="space-y-6">
                    <FormField
                      control={isWhatPercentForm.control}
                      name="part"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Part Value (X)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={isWhatPercentForm.control}
                      name="whole"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Whole Value (Y)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Percentage</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Percentage Result</CardTitle>
                <CardDescription>
                  X as a percentage of Y.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isWhatPercentResult !== null ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">X is what percent of Y?</div>
                      <div className="text-4xl font-bold text-primary">
                        {isWhatPercentResult.toFixed(2)}%
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Full Answer</h3>
                      <p className="text-xl text-center font-medium">
                        {isWhatPercentForm.getValues().part} is {isWhatPercentResult.toFixed(2)}% of {isWhatPercentForm.getValues().whole}
                      </p>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Formula Used</h3>
                      <p className="text-sm text-gray-600">
                        To find what percentage X is of Y, divide X by Y and multiply by 100:<br />
                        <span className="font-mono">(X ÷ Y) × 100%</span><br /><br />
                        In this case:<br />
                        <span className="font-mono">
                          ({isWhatPercentForm.getValues().part} ÷ {isWhatPercentForm.getValues().whole}) × 100% = {isWhatPercentResult.toFixed(2)}%
                        </span>
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter values to see what percentage X is of Y.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Percentage Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our percentage calculator offers three essential percentage calculations:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Find Percentage of a Number</strong>: Calculate a specified percentage of any value (e.g., 15% of 200).</li>
                  <li><strong>Percentage Change</strong>: Determine the percentage increase or decrease between two values.</li>
                  <li><strong>What Percentage is X of Y</strong>: Find out what percentage one number represents of another.</li>
                </ul>
                <p>Key formulas used in percentage calculations:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Percentage of value: <span className="font-mono">(percentage ÷ 100) × value</span></li>
                  <li>Percentage change: <span className="font-mono">((new − original) ÷ |original|) × 100%</span></li>
                  <li>X is what percent of Y: <span className="font-mono">(X ÷ Y) × 100%</span></li>
                </ul>
                <p>Percentages are widely used in finance, statistics, science, and everyday calculations to express proportions and changes relative to a whole.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default PercentageCalculator;
