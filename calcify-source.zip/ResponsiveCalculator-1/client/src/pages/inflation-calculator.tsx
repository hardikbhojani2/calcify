import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, TrendingDown, DollarSign, BarChart, Clock, ShoppingCart } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for calculating inflation impact
const inflationImpactSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  startYear: z.coerce.number().min(1900, "Start year must be 1900 or later").max(new Date().getFullYear() + 100, "Start year cannot be more than 100 years in the future"),
  endYear: z.coerce.number().min(1900, "End year must be 1900 or later").max(new Date().getFullYear() + 100, "End year cannot be more than 100 years in the future"),
  inflationRate: z.coerce.number().min(0, "Inflation rate cannot be negative").max(100, "Inflation rate cannot exceed 100%"),
  direction: z.enum(["future", "past"]),
});

// Define the form schema for calculating purchasing power
const purchasingPowerSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  years: z.coerce.number().positive("Number of years must be positive").max(100, "Number of years cannot exceed 100"),
  inflationRate: z.coerce.number().min(0, "Inflation rate cannot be negative").max(100, "Inflation rate cannot exceed 100%"),
});

// Define the form schema for inflation adjusted income/savings
const incomeAdjustmentSchema = z.object({
  initialAmount: z.coerce.number().positive("Initial amount must be positive"),
  annualIncrease: z.coerce.number().min(0, "Annual increase cannot be negative").max(100, "Annual increase cannot exceed 100%"),
  years: z.coerce.number().positive("Number of years must be positive").max(50, "Number of years cannot exceed 50"),
  inflationRate: z.coerce.number().min(0, "Inflation rate cannot be negative").max(100, "Inflation rate cannot exceed 100%"),
  amountType: z.enum(["income", "savings"]),
});

type InflationImpactFormValues = z.infer<typeof inflationImpactSchema>;
type PurchasingPowerFormValues = z.infer<typeof purchasingPowerSchema>;
type IncomeAdjustmentFormValues = z.infer<typeof incomeAdjustmentSchema>;

interface YearlyData {
  year: number;
  nominalValue: number;
  realValue: number;
  cumulativeInflation: number;
}

const InflationCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("impact");
  const [impactResult, setImpactResult] = useState<{
    originalAmount: number;
    adjustedAmount: number;
    cumulativeInflationRate: number;
    yearlyData: YearlyData[];
    steps: string[];
  } | null>(null);
  
  const [powerResult, setPowerResult] = useState<{
    originalAmount: number;
    adjustedAmount: number;
    purchasingPowerLoss: number;
    yearlyData: YearlyData[];
    steps: string[];
  } | null>(null);
  
  const [incomeResult, setIncomeResult] = useState<{
    initialAmount: number;
    finalNominalAmount: number;
    finalRealAmount: number;
    realGrowthRate: number;
    yearlyData: YearlyData[];
    steps: string[];
  } | null>(null);
  
  // Initialize inflation impact form
  const impactForm = useForm<InflationImpactFormValues>({
    resolver: zodResolver(inflationImpactSchema),
    defaultValues: {
      amount: 100,
      startYear: new Date().getFullYear(),
      endYear: new Date().getFullYear() + 10,
      inflationRate: 2.5,
      direction: "future",
    },
  });
  
  // Initialize purchasing power form
  const powerForm = useForm<PurchasingPowerFormValues>({
    resolver: zodResolver(purchasingPowerSchema),
    defaultValues: {
      amount: 1000,
      years: 10,
      inflationRate: 2.5,
    },
  });
  
  // Initialize income adjustment form
  const incomeForm = useForm<IncomeAdjustmentFormValues>({
    resolver: zodResolver(incomeAdjustmentSchema),
    defaultValues: {
      initialAmount: 50000,
      annualIncrease: 3,
      years: 10,
      inflationRate: 2.5,
      amountType: "income",
    },
  });
  
  // Handle form changes
  const adjustEndYear = () => {
    const startYear = impactForm.getValues().startYear;
    const direction = impactForm.getValues().direction;
    
    // If direction is past, end year should be less than start year
    if (direction === "past" && impactForm.getValues().endYear >= startYear) {
      impactForm.setValue("endYear", startYear - 10);
    } 
    // If direction is future, end year should be greater than start year
    else if (direction === "future" && impactForm.getValues().endYear <= startYear) {
      impactForm.setValue("endYear", startYear + 10);
    }
  };
  
  // Watch form values
  React.useEffect(() => {
    const subscription = impactForm.watch((value, { name }) => {
      if (name === "startYear" || name === "direction") {
        adjustEndYear();
      }
    });
    return () => subscription.unsubscribe();
  }, [impactForm, adjustEndYear]);
  
  // Calculate inflation impact from one year to another
  const calculateInflationImpact = (values: InflationImpactFormValues) => {
    const { amount, startYear, endYear, inflationRate, direction } = values;
    const steps: string[] = [];
    
    steps.push(`Original amount: $${amount.toFixed(2)}`);
    steps.push(`Start year: ${startYear}`);
    steps.push(`End year: ${endYear}`);
    steps.push(`Annual inflation rate: ${inflationRate}%`);
    steps.push(`Direction: ${direction === "future" ? "Future value" : "Past value"}`);
    
    // Convert inflation rate to decimal
    const inflationRateDecimal = inflationRate / 100;
    steps.push(`Inflation rate as decimal: ${inflationRateDecimal}`);
    
    // Calculate number of years and adjust for direction
    let numYears: number;
    if (direction === "future") {
      numYears = endYear - startYear;
      steps.push(`Number of years: ${endYear} - ${startYear} = ${numYears}`);
    } else {
      numYears = startYear - endYear;
      steps.push(`Number of years: ${startYear} - ${endYear} = ${numYears}`);
    }
    
    // Calculate the cumulative inflation rate
    const cumulativeInflationRate = Math.pow(1 + inflationRateDecimal, numYears) - 1;
    steps.push(`Cumulative inflation rate: (1 + ${inflationRateDecimal})^${numYears} - 1 = ${(cumulativeInflationRate * 100).toFixed(2)}%`);
    
    // Calculate the adjusted amount
    let adjustedAmount: number;
    if (direction === "future") {
      // Future value increases with inflation
      adjustedAmount = amount * (1 + cumulativeInflationRate);
      steps.push(`Future value: $${amount.toFixed(2)} × (1 + ${cumulativeInflationRate.toFixed(4)}) = $${adjustedAmount.toFixed(2)}`);
    } else {
      // Past value decreases with inflation (we divide by inflation factor)
      adjustedAmount = amount / (1 + cumulativeInflationRate);
      steps.push(`Past value: $${amount.toFixed(2)} ÷ (1 + ${cumulativeInflationRate.toFixed(4)}) = $${adjustedAmount.toFixed(2)}`);
    }
    
    // Generate yearly data
    const yearlyData: YearlyData[] = [];
    let currentYear = startYear;
    let currentNominalValue = amount;
    let currentRealValue = amount;
    let yearlyInflation = direction === "future" ? inflationRateDecimal : -inflationRateDecimal;
    
    if (direction === "future") {
      for (let i = 0; i <= numYears; i++) {
        const year = startYear + i;
        const cumulativeRate = Math.pow(1 + inflationRateDecimal, i) - 1;
        
        yearlyData.push({
          year,
          nominalValue: i === 0 ? amount : amount * (1 + cumulativeRate),
          realValue: amount,
          cumulativeInflation: cumulativeRate * 100
        });
      }
    } else {
      for (let i = 0; i <= numYears; i++) {
        const year = startYear - i;
        const cumulativeRate = Math.pow(1 + inflationRateDecimal, i) - 1;
        
        yearlyData.push({
          year,
          nominalValue: amount,
          realValue: i === 0 ? amount : amount / (1 + cumulativeRate),
          cumulativeInflation: cumulativeRate * 100
        });
      }
    }
    
    return {
      originalAmount: amount,
      adjustedAmount,
      cumulativeInflationRate: cumulativeInflationRate * 100,
      yearlyData,
      steps
    };
  };
  
  // Calculate purchasing power over time
  const calculatePurchasingPower = (values: PurchasingPowerFormValues) => {
    const { amount, years, inflationRate } = values;
    const steps: string[] = [];
    
    steps.push(`Original amount: $${amount.toFixed(2)}`);
    steps.push(`Time period: ${years} years`);
    steps.push(`Annual inflation rate: ${inflationRate}%`);
    
    // Convert inflation rate to decimal
    const inflationRateDecimal = inflationRate / 100;
    steps.push(`Inflation rate as decimal: ${inflationRateDecimal}`);
    
    // Calculate future purchasing power
    const cumulativeInflationRate = Math.pow(1 + inflationRateDecimal, years) - 1;
    steps.push(`Cumulative inflation over ${years} years: ${(cumulativeInflationRate * 100).toFixed(2)}%`);
    
    const adjustedAmount = amount / (1 + cumulativeInflationRate);
    steps.push(`Purchasing power after ${years} years: $${amount.toFixed(2)} ÷ (1 + ${cumulativeInflationRate.toFixed(4)}) = $${adjustedAmount.toFixed(2)}`);
    
    const purchasingPowerLoss = amount - adjustedAmount;
    steps.push(`Loss of purchasing power: $${amount.toFixed(2)} - $${adjustedAmount.toFixed(2)} = $${purchasingPowerLoss.toFixed(2)}`);
    steps.push(`As percentage: ${((purchasingPowerLoss / amount) * 100).toFixed(2)}%`);
    
    // Generate yearly data
    const yearlyData: YearlyData[] = [];
    
    for (let i = 0; i <= years; i++) {
      const cumulativeRate = Math.pow(1 + inflationRateDecimal, i) - 1;
      const realValue = amount / (1 + cumulativeRate);
      
      yearlyData.push({
        year: i,
        nominalValue: amount, // Nominal stays the same
        realValue,
        cumulativeInflation: cumulativeRate * 100
      });
    }
    
    return {
      originalAmount: amount,
      adjustedAmount,
      purchasingPowerLoss,
      yearlyData,
      steps
    };
  };
  
  // Calculate inflation-adjusted income or savings
  const calculateIncomeAdjustment = (values: IncomeAdjustmentFormValues) => {
    const { initialAmount, annualIncrease, years, inflationRate, amountType } = values;
    const steps: string[] = [];
    
    steps.push(`Initial ${amountType}: $${initialAmount.toFixed(2)}`);
    steps.push(`Annual increase: ${annualIncrease}%`);
    steps.push(`Time period: ${years} years`);
    steps.push(`Annual inflation rate: ${inflationRate}%`);
    
    // Convert rates to decimals
    const inflationRateDecimal = inflationRate / 100;
    const annualIncreaseDecimal = annualIncrease / 100;
    
    steps.push(`Inflation rate as decimal: ${inflationRateDecimal}`);
    steps.push(`Annual increase as decimal: ${annualIncreaseDecimal}`);
    
    // Calculate real growth rate (nominal growth minus inflation)
    const realGrowthRate = ((1 + annualIncreaseDecimal) / (1 + inflationRateDecimal)) - 1;
    steps.push(`Real annual growth rate: ((1 + ${annualIncreaseDecimal}) ÷ (1 + ${inflationRateDecimal})) - 1 = ${(realGrowthRate * 100).toFixed(2)}%`);
    
    // Generate yearly data and calculate final amounts
    const yearlyData: YearlyData[] = [];
    let currentNominalValue = initialAmount;
    
    for (let i = 0; i <= years; i++) {
      const nominalValue = initialAmount * Math.pow(1 + annualIncreaseDecimal, i);
      const cumulativeInflation = Math.pow(1 + inflationRateDecimal, i) - 1;
      const realValue = nominalValue / (1 + cumulativeInflation);
      
      yearlyData.push({
        year: i,
        nominalValue,
        realValue,
        cumulativeInflation: cumulativeInflation * 100
      });
    }
    
    const finalNominalAmount = yearlyData[years].nominalValue;
    const finalRealAmount = yearlyData[years].realValue;
    
    steps.push(`Final nominal ${amountType} after ${years} years: $${finalNominalAmount.toFixed(2)}`);
    steps.push(`Final inflation-adjusted ${amountType}: $${finalRealAmount.toFixed(2)}`);
    
    if (realGrowthRate > 0) {
      steps.push(`Your ${amountType} is growing faster than inflation, resulting in increased purchasing power.`);
    } else if (realGrowthRate < 0) {
      steps.push(`Your ${amountType} is not keeping pace with inflation, resulting in decreased purchasing power.`);
    } else {
      steps.push(`Your ${amountType} is exactly keeping pace with inflation, maintaining constant purchasing power.`);
    }
    
    return {
      initialAmount,
      finalNominalAmount,
      finalRealAmount,
      realGrowthRate: realGrowthRate * 100,
      yearlyData,
      steps
    };
  };
  
  // Form submission handlers
  const onImpactSubmit = (values: InflationImpactFormValues) => {
    try {
      const result = calculateInflationImpact(values);
      setImpactResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onPowerSubmit = (values: PurchasingPowerFormValues) => {
    try {
      const result = calculatePurchasingPower(values);
      setPowerResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onIncomeSubmit = (values: IncomeAdjustmentFormValues) => {
    try {
      const result = calculateIncomeAdjustment(values);
      setIncomeResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <TrendingDown className="mr-2 h-8 w-8" /> Inflation Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="impact" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="impact">Inflation Impact</TabsTrigger>
                <TabsTrigger value="power">Purchasing Power</TabsTrigger>
                <TabsTrigger value="income">Income/Savings</TabsTrigger>
              </TabsList>
              
              {/* Inflation Impact Calculator */}
              <TabsContent value="impact">
                <Card>
                  <CardHeader>
                    <CardTitle>Inflation Impact Calculator</CardTitle>
                    <CardDescription>
                      Calculate how inflation changes the value of money over time.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...impactForm}>
                      <form onSubmit={impactForm.handleSubmit(onImpactSubmit)} className="space-y-6">
                        <FormField
                          control={impactForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The monetary amount to adjust for inflation.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={impactForm.control}
                          name="direction"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Calculation Direction</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={(value) => {
                                    field.onChange(value);
                                    // Adjust end year based on direction
                                    setTimeout(() => adjustEndYear(), 0);
                                  }}
                                  defaultValue={field.value}
                                  className="flex space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="future" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Future Value</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="past" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Past Value</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                Choose whether to calculate future value (inflation increases value) or past value (inflation decreases value).
                              </FormDescription>
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={impactForm.control}
                            name="startYear"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Start Year</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1900" max="2100" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={impactForm.control}
                            name="endYear"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>End Year</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1900" max="2100" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={impactForm.control}
                          name="inflationRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Annual Inflation Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormDescription>
                                Average annual inflation rate. The historical average in the US is around 3%.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Inflation Impact</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Purchasing Power Calculator */}
              <TabsContent value="power">
                <Card>
                  <CardHeader>
                    <CardTitle>Purchasing Power Calculator</CardTitle>
                    <CardDescription>
                      Calculate how inflation affects the purchasing power of money over time.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...powerForm}>
                      <form onSubmit={powerForm.handleSubmit(onPowerSubmit)} className="space-y-6">
                        <FormField
                          control={powerForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Current Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The current monetary amount to analyze.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={powerForm.control}
                            name="years"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="100" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={powerForm.control}
                            name="inflationRate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Inflation Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Purchasing Power</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Income/Savings Adjustment Calculator */}
              <TabsContent value="income">
                <Card>
                  <CardHeader>
                    <CardTitle>Inflation-Adjusted Value Calculator</CardTitle>
                    <CardDescription>
                      Calculate how inflation impacts your income or savings over time.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...incomeForm}>
                      <form onSubmit={incomeForm.handleSubmit(onIncomeSubmit)} className="space-y-6">
                        <FormField
                          control={incomeForm.control}
                          name="amountType"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Amount Type</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="income" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Income</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="savings" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Savings</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={incomeForm.control}
                          name="initialAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Initial {incomeForm.watch("amountType") === "income" ? "Income" : "Savings"}</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="100" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={incomeForm.control}
                            name="annualIncrease"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Increase (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  Expected annual raise or growth rate.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={incomeForm.control}
                            name="years"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="50" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={incomeForm.control}
                          name="inflationRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Annual Inflation Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Adjusted Value</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* Inflation Impact Results */}
            {activeTab === "impact" && (
              <div className="space-y-6">
                {impactResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Inflation Impact Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">
                              {impactForm.getValues().direction === "future" ? "Original" : "Current"} Amount
                            </p>
                            <p className="text-2xl font-bold">${impactResult.originalAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">
                              {impactForm.getValues().direction === "future" ? impactForm.getValues().startYear : impactForm.getValues().endYear}
                            </p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">
                              {impactForm.getValues().direction === "future" ? "Future" : "Past"} Value
                            </p>
                            <p className="text-2xl font-bold">${impactResult.adjustedAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">
                              {impactForm.getValues().direction === "future" ? impactForm.getValues().endYear : impactForm.getValues().startYear}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                          <p className="font-medium">Cumulative Inflation: {impactResult.cumulativeInflationRate.toFixed(2)}%</p>
                          <p className="text-sm text-gray-600 mt-1">
                            {impactForm.getValues().direction === "future" 
                              ? `$${impactResult.originalAmount.toFixed(2)} in ${impactForm.getValues().startYear} is equivalent to $${impactResult.adjustedAmount.toFixed(2)} in ${impactForm.getValues().endYear}.`
                              : `$${impactResult.originalAmount.toFixed(2)} in ${impactForm.getValues().endYear} is equivalent to $${impactResult.adjustedAmount.toFixed(2)} in ${impactForm.getValues().startYear}.`
                            }
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-4 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>{impactForm.getValues().direction === "future" ? "Nominal Value" : "Current Value"}</div>
                            <div>{impactForm.getValues().direction === "future" ? "Real Value" : "Past Value"}</div>
                            <div>Inflation Rate</div>
                          </div>
                          
                          {impactResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-4 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.nominalValue.toFixed(2)}</div>
                              <div>${data.realValue.toFixed(2)}</div>
                              <div>{data.cumulativeInflation.toFixed(2)}%</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {impactResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Inflation Impact Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <DollarSign className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Inflation Impact"</p>
                        <p className="text-sm mt-2">See how inflation affects the value of money over time</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Purchasing Power Results */}
            {activeTab === "power" && (
              <div className="space-y-6">
                {powerResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Purchasing Power Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Original Amount</p>
                            <p className="text-2xl font-bold">${powerResult.originalAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">Today</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Future Purchasing Power</p>
                            <p className="text-2xl font-bold">${powerResult.adjustedAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">After {powerForm.getValues().years} years</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Purchasing Power Loss</p>
                            <p className="text-2xl font-bold">${powerResult.purchasingPowerLoss.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Loss Percentage</p>
                            <p className="text-2xl font-bold">{((powerResult.purchasingPowerLoss / powerResult.originalAmount) * 100).toFixed(2)}%</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                          <p className="font-medium">What this means:</p>
                          <p className="text-sm text-gray-600 mt-1">
                            ${powerResult.originalAmount.toFixed(2)} today will have the same purchasing power as ${powerResult.adjustedAmount.toFixed(2)} in {powerForm.getValues().years} years.
                            You would need ${powerResult.originalAmount.toFixed(2)} + ${powerResult.purchasingPowerLoss.toFixed(2)} = ${(powerResult.originalAmount + powerResult.purchasingPowerLoss).toFixed(2)} in {powerForm.getValues().years} years to maintain your current purchasing power.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-4 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Nominal Value</div>
                            <div>Purchasing Power</div>
                            <div>Inflation Rate</div>
                          </div>
                          
                          {powerResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-4 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.nominalValue.toFixed(2)}</div>
                              <div>${data.realValue.toFixed(2)}</div>
                              <div>{data.cumulativeInflation.toFixed(2)}%</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {powerResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Purchasing Power Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Purchasing Power"</p>
                        <p className="text-sm mt-2">See how inflation erodes purchasing power over time</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Income/Savings Adjustment Results */}
            {activeTab === "income" && (
              <div className="space-y-6">
                {incomeResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Inflation-Adjusted {incomeForm.getValues().amountType === "income" ? "Income" : "Savings"} Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Initial {incomeForm.getValues().amountType === "income" ? "Income" : "Savings"}</p>
                            <p className="text-2xl font-bold">${incomeResult.initialAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Final Nominal {incomeForm.getValues().amountType === "income" ? "Income" : "Savings"}</p>
                            <p className="text-2xl font-bold">${incomeResult.finalNominalAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Final Real Value</p>
                            <p className="text-2xl font-bold">${incomeResult.finalRealAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">In today's dollars</p>
                          </div>
                          
                          <div className={`bg-primary/10 p-4 rounded-lg ${incomeResult.realGrowthRate >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                            <p className="text-sm text-gray-500">Real Growth Rate</p>
                            <p className="text-2xl font-bold">{incomeResult.realGrowthRate.toFixed(2)}%</p>
                            <p className="text-xs text-gray-500">Annual, adjusted for inflation</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                          <p className="font-medium">What this means:</p>
                          <p className="text-sm text-gray-600 mt-1">
                            {incomeResult.realGrowthRate > 0 
                              ? `Your ${incomeForm.getValues().amountType} is growing faster than inflation at a real rate of ${incomeResult.realGrowthRate.toFixed(2)}% per year, increasing your purchasing power over time.`
                              : incomeResult.realGrowthRate < 0 
                                ? `Your ${incomeForm.getValues().amountType} is not keeping pace with inflation (real growth of ${incomeResult.realGrowthRate.toFixed(2)}% per year), which is decreasing your purchasing power over time.`
                                : `Your ${incomeForm.getValues().amountType} is exactly keeping pace with inflation, maintaining the same purchasing power over time.`
                            }
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-4 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Nominal Value</div>
                            <div>Real Value</div>
                            <div>Inflation Rate</div>
                          </div>
                          
                          {incomeResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-4 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.nominalValue.toFixed(2)}</div>
                              <div>${data.realValue.toFixed(2)}</div>
                              <div>{data.cumulativeInflation.toFixed(2)}%</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {incomeResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Inflation-Adjusted Value Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <BarChart className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Adjusted Value"</p>
                        <p className="text-sm mt-2">See if your income or savings is keeping pace with inflation</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Educational Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Understanding Inflation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">What is Inflation?</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Inflation is the rate at which the general level of prices for goods and services rises, causing purchasing power to fall. 
                    Central banks try to limit inflation to keep the economy running smoothly, typically targeting an inflation rate of around 2%.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">The Rule of 72</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    A quick way to estimate how long it will take for the value of money to be cut in half is to use the "Rule of 72".
                    Divide 72 by the annual inflation rate. For example, at 3% inflation, prices will double (and purchasing power will be cut in half) in about 72 ÷ 3 = 24 years.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Protecting Against Inflation</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    To maintain purchasing power, investments should aim to exceed the inflation rate. Common inflation hedges include:
                  </p>
                  <ul className="list-disc pl-6 mt-1 space-y-1 text-sm text-gray-600">
                    <li>Stocks (historically average 7-10% annual returns)</li>
                    <li>Real estate (appreciates with inflation and provides rental income)</li>
                    <li>Treasury Inflation-Protected Securities (TIPS)</li>
                    <li>I Bonds (savings bonds with returns tied to inflation)</li>
                    <li>Commodities (like gold, which tend to maintain value during inflation)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default InflationCalculator;
