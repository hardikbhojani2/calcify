import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Clock, Plus, Minus } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for time difference
const timeDifferenceSchema = z.object({
  hours1: z.coerce.number().min(0, "Hours must be positive").max(23, "Hours must be 0-23"),
  minutes1: z.coerce.number().min(0, "Minutes must be positive").max(59, "Minutes must be 0-59"),
  seconds1: z.coerce.number().min(0, "Seconds must be positive").max(59, "Seconds must be 0-59"),
  hours2: z.coerce.number().min(0, "Hours must be positive").max(23, "Hours must be 0-23"),
  minutes2: z.coerce.number().min(0, "Minutes must be positive").max(59, "Minutes must be 0-59"),
  seconds2: z.coerce.number().min(0, "Seconds must be positive").max(59, "Seconds must be 0-59"),
});

// Define the form schema for time addition/subtraction
const timeAddSubtractSchema = z.object({
  baseHours: z.coerce.number().min(0, "Hours must be positive").max(23, "Hours must be 0-23"),
  baseMinutes: z.coerce.number().min(0, "Minutes must be positive").max(59, "Minutes must be 0-59"),
  baseSeconds: z.coerce.number().min(0, "Seconds must be positive").max(59, "Seconds must be 0-59"),
  addHours: z.coerce.number().min(0, "Hours must be positive"),
  addMinutes: z.coerce.number().min(0, "Minutes must be positive"),
  addSeconds: z.coerce.number().min(0, "Seconds must be positive"),
  operation: z.enum(["add", "subtract"]),
});

// Define the form schema for time conversion
const timeConversionSchema = z.object({
  value: z.coerce.number().positive("Value must be positive"),
  fromUnit: z.enum(["seconds", "minutes", "hours", "days", "weeks"]),
  toUnit: z.enum(["seconds", "minutes", "hours", "days", "weeks"]),
});

type TimeDifferenceFormValues = z.infer<typeof timeDifferenceSchema>;
type TimeAddSubtractFormValues = z.infer<typeof timeAddSubtractSchema>;
type TimeConversionFormValues = z.infer<typeof timeConversionSchema>;

const TimeCalculator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("difference");
  
  const [differenceResults, setDifferenceResults] = useState<{
    hours: number;
    minutes: number;
    seconds: number;
    totalSeconds: number;
    totalMinutes: number;
    totalHours: number;
  } | null>(null);
  
  const [addSubtractResults, setAddSubtractResults] = useState<{
    hours: number;
    minutes: number;
    seconds: number;
    description: string;
  } | null>(null);
  
  const [conversionResults, setConversionResults] = useState<{
    result: number;
    fromUnit: string;
    toUnit: string;
  } | null>(null);

  // Initialize the form for time difference
  const differenceForm = useForm<TimeDifferenceFormValues>({
    resolver: zodResolver(timeDifferenceSchema),
    defaultValues: {
      hours1: 9,
      minutes1: 0,
      seconds1: 0,
      hours2: 17,
      minutes2: 0,
      seconds2: 0,
    },
  });
  
  // Initialize the form for time addition/subtraction
  const addSubtractForm = useForm<TimeAddSubtractFormValues>({
    resolver: zodResolver(timeAddSubtractSchema),
    defaultValues: {
      baseHours: 9,
      baseMinutes: 0,
      baseSeconds: 0,
      addHours: 1,
      addMinutes: 30,
      addSeconds: 0,
      operation: "add",
    },
  });
  
  // Initialize the form for time conversion
  const conversionForm = useForm<TimeConversionFormValues>({
    resolver: zodResolver(timeConversionSchema),
    defaultValues: {
      value: 1,
      fromUnit: "hours",
      toUnit: "minutes",
    },
  });

  // Function to calculate the difference between two times
  const calculateTimeDifference = (values: TimeDifferenceFormValues) => {
    // Convert both times to seconds
    const time1Seconds = values.hours1 * 3600 + values.minutes1 * 60 + values.seconds1;
    const time2Seconds = values.hours2 * 3600 + values.minutes2 * 60 + values.seconds2;
    
    // Calculate the absolute difference in seconds
    const diffSeconds = Math.abs(time2Seconds - time1Seconds);
    
    // Convert back to hours, minutes, seconds
    const hours = Math.floor(diffSeconds / 3600);
    const minutes = Math.floor((diffSeconds % 3600) / 60);
    const seconds = diffSeconds % 60;
    
    return {
      hours,
      minutes,
      seconds,
      totalSeconds: diffSeconds,
      totalMinutes: diffSeconds / 60,
      totalHours: diffSeconds / 3600
    };
  };
  
  // Function to add or subtract time
  const calculateTimeAddSubtract = (values: TimeAddSubtractFormValues) => {
    // Convert base time to seconds
    const baseSeconds = values.baseHours * 3600 + values.baseMinutes * 60 + values.baseSeconds;
    
    // Convert time to add/subtract to seconds
    const operationSeconds = values.addHours * 3600 + values.addMinutes * 60 + values.addSeconds;
    
    // Add or subtract seconds
    let resultSeconds: number;
    if (values.operation === "add") {
      resultSeconds = baseSeconds + operationSeconds;
    } else {
      resultSeconds = baseSeconds - operationSeconds;
      // Handle negative time by wrapping around (24-hour format)
      if (resultSeconds < 0) {
        resultSeconds = 86400 + (resultSeconds % 86400); // 86400 seconds in a day
      }
    }
    
    // Keep result within 24 hours
    resultSeconds = resultSeconds % 86400;
    
    // Convert back to hours, minutes, seconds
    const hours = Math.floor(resultSeconds / 3600);
    const minutes = Math.floor((resultSeconds % 3600) / 60);
    const seconds = resultSeconds % 60;
    
    // Create description
    const baseTimeStr = `${values.baseHours.toString().padStart(2, '0')}:${values.baseMinutes.toString().padStart(2, '0')}:${values.baseSeconds.toString().padStart(2, '0')}`;
    const operationTimeStr = `${values.addHours.toString().padStart(2, '0')}:${values.addMinutes.toString().padStart(2, '0')}:${values.addSeconds.toString().padStart(2, '0')}`;
    const description = `${baseTimeStr} ${values.operation === "add" ? "+" : "-"} ${operationTimeStr}`;
    
    return {
      hours,
      minutes,
      seconds,
      description
    };
  };
  
  // Function to convert between time units
  const calculateTimeConversion = (values: TimeConversionFormValues) => {
    const { value, fromUnit, toUnit } = values;
    
    // Convert the value to seconds (base unit)
    let valueInSeconds: number;
    switch (fromUnit) {
      case "seconds":
        valueInSeconds = value;
        break;
      case "minutes":
        valueInSeconds = value * 60;
        break;
      case "hours":
        valueInSeconds = value * 3600;
        break;
      case "days":
        valueInSeconds = value * 86400;
        break;
      case "weeks":
        valueInSeconds = value * 604800; // 7 days * 24 hours * 60 minutes * 60 seconds
        break;
      default:
        throw new Error("Invalid source unit");
    }
    
    // Convert from seconds to target unit
    let result: number;
    switch (toUnit) {
      case "seconds":
        result = valueInSeconds;
        break;
      case "minutes":
        result = valueInSeconds / 60;
        break;
      case "hours":
        result = valueInSeconds / 3600;
        break;
      case "days":
        result = valueInSeconds / 86400;
        break;
      case "weeks":
        result = valueInSeconds / 604800;
        break;
      default:
        throw new Error("Invalid target unit");
    }
    
    return {
      result,
      fromUnit,
      toUnit
    };
  };

  // Update difference results when form values change
  React.useEffect(() => {
    if (differenceForm.formState.isValid && activeTab === "difference") {
      const currentValues = differenceForm.getValues();
      try {
        const results = calculateTimeDifference(currentValues);
        setDifferenceResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    differenceForm.watch('hours1'),
    differenceForm.watch('minutes1'),
    differenceForm.watch('seconds1'),
    differenceForm.watch('hours2'),
    differenceForm.watch('minutes2'),
    differenceForm.watch('seconds2'),
    differenceForm,
    activeTab
  ]);
  
  // Update add/subtract results when form values change
  React.useEffect(() => {
    if (addSubtractForm.formState.isValid && activeTab === "add-subtract") {
      const currentValues = addSubtractForm.getValues();
      try {
        const results = calculateTimeAddSubtract(currentValues);
        setAddSubtractResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    addSubtractForm.watch('baseHours'),
    addSubtractForm.watch('baseMinutes'),
    addSubtractForm.watch('baseSeconds'),
    addSubtractForm.watch('addHours'),
    addSubtractForm.watch('addMinutes'),
    addSubtractForm.watch('addSeconds'),
    addSubtractForm.watch('operation'),
    addSubtractForm,
    activeTab
  ]);
  
  // Update conversion results when form values change
  React.useEffect(() => {
    if (conversionForm.formState.isValid && activeTab === "conversion") {
      const currentValues = conversionForm.getValues();
      try {
        const results = calculateTimeConversion(currentValues);
        setConversionResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    conversionForm.watch('value'),
    conversionForm.watch('fromUnit'),
    conversionForm.watch('toUnit'),
    conversionForm,
    activeTab
  ]);
  
  // Form submission handlers
  const onDifferenceSubmit = (values: TimeDifferenceFormValues) => {
    try {
      const results = calculateTimeDifference(values);
      setDifferenceResults(results);
      toast({
        title: 'Time difference calculated',
        description: 'The difference between the times has been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating the time difference.',
        variant: 'destructive',
      });
    }
  };
  
  const onAddSubtractSubmit = (values: TimeAddSubtractFormValues) => {
    try {
      const results = calculateTimeAddSubtract(values);
      setAddSubtractResults(results);
      toast({
        title: 'Time calculation completed',
        description: `The time has been ${values.operation === 'add' ? 'added' : 'subtracted'} successfully.`,
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error performing the time calculation.',
        variant: 'destructive',
      });
    }
  };
  
  const onConversionSubmit = (values: TimeConversionFormValues) => {
    try {
      const results = calculateTimeConversion(values);
      setConversionResults(results);
      toast({
        title: 'Time conversion completed',
        description: 'The time conversion has been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Conversion Error',
        description: 'There was an error performing the time conversion.',
        variant: 'destructive',
      });
    }
  };
  
  // Helper function to format unit names
  const formatUnitName = (unit: string, value: number): string => {
    const unitName = unit.charAt(0).toUpperCase() + unit.slice(1);
    return value === 1 ? unitName.replace(/s$/, '') : unitName; // Remove trailing 's' for singular form
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Clock className="mr-2 h-8 w-8" /> Time Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="difference" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="difference">Time Difference</TabsTrigger>
            <TabsTrigger value="add-subtract">Add/Subtract Time</TabsTrigger>
            <TabsTrigger value="conversion">Time Conversion</TabsTrigger>
          </TabsList>
          
          {/* Time Difference Tab */}
          <TabsContent value="difference" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Time Difference</CardTitle>
                <CardDescription>
                  Find the exact time between two times.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...differenceForm}>
                  <form onSubmit={differenceForm.handleSubmit(onDifferenceSubmit)} className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">First Time</h3>
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={differenceForm.control}
                          name="hours1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hours</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="23" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={differenceForm.control}
                          name="minutes1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Minutes</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={differenceForm.control}
                          name="seconds1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Seconds</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Second Time</h3>
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={differenceForm.control}
                          name="hours2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hours</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="23" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={differenceForm.control}
                          name="minutes2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Minutes</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={differenceForm.control}
                          name="seconds2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Seconds</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate Difference</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Time Difference Results</CardTitle>
                <CardDescription>
                  The calculated time difference.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {differenceResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Time Difference</div>
                      <div className="text-3xl font-bold text-primary">
                        {differenceResults.hours.toString().padStart(2, '0')}:
                        {differenceResults.minutes.toString().padStart(2, '0')}:
                        {differenceResults.seconds.toString().padStart(2, '0')}
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Between Times</div>
                        <div className="text-xl font-semibold">
                          {differenceForm.getValues().hours1.toString().padStart(2, '0')}:
                          {differenceForm.getValues().minutes1.toString().padStart(2, '0')}:
                          {differenceForm.getValues().seconds1.toString().padStart(2, '0')}
                          {' '}&nbsp;and&nbsp;{' '}
                          {differenceForm.getValues().hours2.toString().padStart(2, '0')}:
                          {differenceForm.getValues().minutes2.toString().padStart(2, '0')}:
                          {differenceForm.getValues().seconds2.toString().padStart(2, '0')}
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Detailed Breakdown</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Total Hours:</span>
                          <span>{differenceResults.totalHours.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Total Minutes:</span>
                          <span>{differenceResults.totalMinutes.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Total Seconds:</span>
                          <span>{differenceResults.totalSeconds}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter two times to see the difference between them.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Add/Subtract Time Tab */}
          <TabsContent value="add-subtract" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Add or Subtract Time</CardTitle>
                <CardDescription>
                  Calculate a new time by adding or subtracting hours, minutes, and seconds.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...addSubtractForm}>
                  <form onSubmit={addSubtractForm.handleSubmit(onAddSubtractSubmit)} className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Base Time</h3>
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={addSubtractForm.control}
                          name="baseHours"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hours</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="23" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={addSubtractForm.control}
                          name="baseMinutes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Minutes</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={addSubtractForm.control}
                          name="baseSeconds"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Seconds</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="59" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <FormField
                      control={addSubtractForm.control}
                      name="operation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Operation</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select operation" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="add">Add Time</SelectItem>
                              <SelectItem value="subtract">Subtract Time</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">
                        {addSubtractForm.watch('operation') === 'add' ? 'Time to Add' : 'Time to Subtract'}
                      </h3>
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={addSubtractForm.control}
                          name="addHours"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hours</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  {addSubtractForm.watch('operation') === 'add' ? 
                                    <Plus className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" /> :
                                    <Minus className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />}
                                  <Input 
                                    {...field} 
                                    type="number" 
                                    min="0" 
                                    className="pl-10" 
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={addSubtractForm.control}
                          name="addMinutes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Minutes</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={addSubtractForm.control}
                          name="addSeconds"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Seconds</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate New Time</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Time Calculation Results</CardTitle>
                <CardDescription>
                  Your new calculated time.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {addSubtractResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Result Time</div>
                      <div className="text-3xl font-bold text-primary">
                        {addSubtractResults.hours.toString().padStart(2, '0')}:
                        {addSubtractResults.minutes.toString().padStart(2, '0')}:
                        {addSubtractResults.seconds.toString().padStart(2, '0')}
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Calculation</div>
                        <div className="text-xl font-semibold">{addSubtractResults.description}</div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Time Details</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Hours:</span>
                          <span>{addSubtractResults.hours}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Minutes:</span>
                          <span>{addSubtractResults.minutes}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Seconds:</span>
                          <span>{addSubtractResults.seconds}</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Note: Results use a 24-hour format (0-23 hours).
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Set your time calculation parameters to see the result.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Time Conversion Tab */}
          <TabsContent value="conversion" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Convert Time Units</CardTitle>
                <CardDescription>
                  Convert between different time units (seconds, minutes, hours, days, weeks).
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...conversionForm}>
                  <form onSubmit={conversionForm.handleSubmit(onConversionSubmit)} className="space-y-6">
                    <FormField
                      control={conversionForm.control}
                      name="value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Value</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="any" min="0" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={conversionForm.control}
                        name="fromUnit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>From Unit</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select unit" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="seconds">Seconds</SelectItem>
                                <SelectItem value="minutes">Minutes</SelectItem>
                                <SelectItem value="hours">Hours</SelectItem>
                                <SelectItem value="days">Days</SelectItem>
                                <SelectItem value="weeks">Weeks</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={conversionForm.control}
                        name="toUnit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>To Unit</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select unit" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="seconds">Seconds</SelectItem>
                                <SelectItem value="minutes">Minutes</SelectItem>
                                <SelectItem value="hours">Hours</SelectItem>
                                <SelectItem value="days">Days</SelectItem>
                                <SelectItem value="weeks">Weeks</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">Convert</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Conversion Results</CardTitle>
                <CardDescription>
                  Your time unit conversion results.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {conversionResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Result</div>
                      <div className="text-3xl font-bold text-primary">
                        {conversionResults.result.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Conversion</div>
                        <div className="text-xl font-semibold">
                          {conversionForm.getValues().value} {formatUnitName(conversionResults.fromUnit, conversionForm.getValues().value)} = {conversionResults.result.toLocaleString(undefined, { maximumFractionDigits: 6 })} {formatUnitName(conversionResults.toUnit, conversionResults.result)}
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Conversion Details</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Input Value:</span>
                          <span>{conversionForm.getValues().value}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Input Unit:</span>
                          <span>{formatUnitName(conversionResults.fromUnit, conversionForm.getValues().value)}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Output Unit:</span>
                          <span>{formatUnitName(conversionResults.toUnit, conversionResults.result)}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Result:</span>
                          <span>{conversionResults.result.toLocaleString(undefined, { maximumFractionDigits: 6 })}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter a value and select units to see the conversion result.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Time Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our time calculator offers three primary functions:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Time Difference</strong>: Calculate the exact time between two times in hours, minutes, and seconds.</li>
                  <li><strong>Add/Subtract Time</strong>: Find a new time by adding or subtracting hours, minutes, and seconds from a starting time.</li>
                  <li><strong>Time Conversion</strong>: Convert between different time units such as seconds, minutes, hours, days, and weeks.</li>
                </ul>
                <p>These calculations use standard time measurements:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>1 minute = 60 seconds</li>
                  <li>1 hour = 60 minutes = 3,600 seconds</li>
                  <li>1 day = 24 hours = 1,440 minutes = 86,400 seconds</li>
                  <li>1 week = 7 days = 168 hours = 10,080 minutes = 604,800 seconds</li>
                </ul>
                <p className="text-gray-500">Note: Time calculations are based on a 24-hour clock format (0-23 hours).</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default TimeCalculator;
