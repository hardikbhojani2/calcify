import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calculator, Info, HeartHandshake, Code, Lightbulb } from 'lucide-react';
import { Link } from 'wouter';

const About: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Info className="mr-2 h-8 w-8" /> About Our Calculator Suite
          </h1>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Our Mission</CardTitle>
            <CardDescription>
              Providing accurate, accessible calculation tools for everyone
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Our all-in-one calculator suite was created with the mission of making calculations 
              accessible to everyone. We believe that reliable calculation tools should be available for free, 
              without downloads, signups, or interruptions.
            </p>
            <p>
              Whether you need to calculate your mortgage payments, check your BMI, solve complex math problems, 
              or track pregnancy milestones, our comprehensive suite of calculators has you covered.
            </p>
          </CardContent>
        </Card>
        
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <Card className="md:col-span-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-lg font-medium">
                <HeartHandshake className="h-5 w-5 inline-block mr-2" />
                User-Centered Design
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Each calculator is designed with user experience in mind. We provide clear instructions, instant results, 
                educational information, and a responsive design that works on all devices.
              </p>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-lg font-medium">
                <Code className="h-5 w-5 inline-block mr-2" />
                Technical Precision
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Our calculators use industry-standard formulas and best practices to ensure accurate results. 
                Each calculator is thoroughly tested and includes step-by-step explanations when applicable.
              </p>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-lg font-medium">
                <Lightbulb className="h-5 w-5 inline-block mr-2" />
                Educational Focus
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Beyond just providing results, we aim to educate. Each calculator includes explanations of 
                formulas, terms, and concepts to help you understand the calculations being performed.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Our Calculator Categories</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-2">Financial Calculators</h3>
              <p className="text-sm text-gray-600 mb-2">
                Plan your financial future with our comprehensive set of financial calculators, including 
                mortgage, loan, interest rate, and investment calculators.
              </p>
              <div className="flex flex-wrap gap-2">
                <Link href="/mortgage-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary-foreground hover:bg-primary/20 cursor-pointer">
                    Mortgage Calculator
                  </span>
                </Link>
                <Link href="/loan-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary-foreground hover:bg-primary/20 cursor-pointer">
                    Loan Calculator
                  </span>
                </Link>
                <Link href="/interest-rate-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary-foreground hover:bg-primary/20 cursor-pointer">
                    Interest Rate Calculator
                  </span>
                </Link>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="text-lg font-medium mb-2">Fitness & Health Calculators</h3>
              <p className="text-sm text-gray-600 mb-2">
                Monitor your health and fitness with calculators for BMI, body fat, calorie needs, and pregnancy tracking.
              </p>
              <div className="flex flex-wrap gap-2">
                <Link href="/bmi-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 hover:bg-green-200 cursor-pointer">
                    BMI Calculator
                  </span>
                </Link>
                <Link href="/calorie-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 hover:bg-green-200 cursor-pointer">
                    Calorie Calculator
                  </span>
                </Link>
                <Link href="/body-fat-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 hover:bg-green-200 cursor-pointer">
                    Body Fat Calculator
                  </span>
                </Link>
                <Link href="/pregnancy-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 hover:bg-green-200 cursor-pointer">
                    Pregnancy Calculator
                  </span>
                </Link>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="text-lg font-medium mb-2">Math Calculators</h3>
              <p className="text-sm text-gray-600 mb-2">
                Solve mathematical problems with our scientific, fraction, percentage, and statistical calculators.
              </p>
              <div className="flex flex-wrap gap-2">
                <Link href="/scientific-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer">
                    Scientific Calculator
                  </span>
                </Link>
                <Link href="/fraction-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer">
                    Fraction Calculator
                  </span>
                </Link>
                <Link href="/percentage-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer">
                    Percentage Calculator
                  </span>
                </Link>
                <Link href="/standard-deviation-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer">
                    Standard Deviation Calculator
                  </span>
                </Link>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="text-lg font-medium mb-2">Other Calculators</h3>
              <p className="text-sm text-gray-600 mb-2">
                Use our utility calculators for everyday tasks like age calculation, date differences, time conversion, and more.
              </p>
              <div className="flex flex-wrap gap-2">
                <Link href="/age-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 hover:bg-purple-200 cursor-pointer">
                    Age Calculator
                  </span>
                </Link>
                <Link href="/date-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 hover:bg-purple-200 cursor-pointer">
                    Date Calculator
                  </span>
                </Link>
                <Link href="/time-calculator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 hover:bg-purple-200 cursor-pointer">
                    Time Calculator
                  </span>
                </Link>
                <Link href="/password-generator">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 hover:bg-purple-200 cursor-pointer">
                    Password Generator
                  </span>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Privacy & Security</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              We prioritize your privacy and security. All calculations are performed in your browser, 
              and we do not store or transmit any of your personal data. You can use our calculators 
              with confidence, knowing your information remains private.
            </p>
            <p>
              For more information about our privacy practices, please visit our <Link href="/privacy" className="text-blue-600 hover:underline">Privacy Policy</Link> page.
            </p>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;
