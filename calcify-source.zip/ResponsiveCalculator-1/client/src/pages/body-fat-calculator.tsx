import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Percent, FileText, Activity } from 'lucide-react';
import { Link } from 'wouter';

// Define general schema
const baseSchema = z.object({
  system: z.enum(["metric", "imperial"]),
  gender: z.enum(["male", "female"]),
  age: z.coerce.number().int().min(15, "Age must be at least 15").max(80, "Age must be at most 80"),
});

// Navy method schema
const navySchema = baseSchema.extend({
  height: z.coerce.number().positive("Height must be positive"),
  weight: z.coerce.number().positive("Weight must be positive"),
  neck: z.coerce.number().positive("Neck measurement must be positive"),
  waist: z.coerce.number().positive("Waist measurement must be positive"),
  hip: z.coerce.number().positive("Hip measurement must be positive").optional(),
});

// Skinfold method schema
const skinfoldSchema = baseSchema.extend({
  chest: z.coerce.number().min(0, "Cannot be negative"),
  abdominal: z.coerce.number().min(0, "Cannot be negative"),
  thigh: z.coerce.number().min(0, "Cannot be negative"),
  tricep: z.coerce.number().min(0, "Cannot be negative").optional(),
  suprailiac: z.coerce.number().min(0, "Cannot be negative").optional(),
});

type NavyFormValues = z.infer<typeof navySchema>;
type SkinfoldFormValues = z.infer<typeof skinfoldSchema>;

interface BodyFatCategory {
  category: string;
  range: string;
  color: string;
  description: string;
}

const bodyFatCategories: Record<string, BodyFatCategory[]> = {
  male: [
    { category: "Essential Fat", range: "2-5%", color: "bg-blue-500", description: "Minimum fat needed for basic physical and physiological health" },
    { category: "Athletes", range: "6-13%", color: "bg-green-500", description: "Typical for competitive athletes" },
    { category: "Fitness", range: "14-17%", color: "bg-green-400", description: "Lean and well-defined physique" },
    { category: "Average", range: "18-24%", color: "bg-yellow-500", description: "Typical healthy range for many men" },
    { category: "Overweight", range: "25-29%", color: "bg-orange-500", description: "Some excess fat accumulation" },
    { category: "Obese", range: "30%+", color: "bg-red-500", description: "Excess fat associated with health risks" },
  ],
  female: [
    { category: "Essential Fat", range: "10-13%", color: "bg-blue-500", description: "Minimum fat needed for basic physical and physiological health" },
    { category: "Athletes", range: "14-20%", color: "bg-green-500", description: "Typical for competitive athletes" },
    { category: "Fitness", range: "21-24%", color: "bg-green-400", description: "Lean and well-defined physique" },
    { category: "Average", range: "25-31%", color: "bg-yellow-500", description: "Typical healthy range for many women" },
    { category: "Overweight", range: "32-39%", color: "bg-orange-500", description: "Some excess fat accumulation" },
    { category: "Obese", range: "40%+", color: "bg-red-500", description: "Excess fat associated with health risks" },
  ],
};

const BodyFatCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState("navy");
  const [bodyFatResult, setBodyFatResult] = useState<{
    bodyFatPercentage: number;
    leanMass?: number;
    fatMass?: number;
    category: string;
    color: string;
  } | null>(null);

  // Navy method form
  const navyForm = useForm<NavyFormValues>({
    resolver: zodResolver(navySchema),
    defaultValues: {
      system: "metric",
      gender: "male",
      age: 30,
      height: 175, // cm
      weight: 75, // kg
      neck: 36, // cm
      waist: 85, // cm
      hip: 0, // Only used for women
    },
  });

  // Skinfold method form
  const skinfoldForm = useForm<SkinfoldFormValues>({
    resolver: zodResolver(skinfoldSchema),
    defaultValues: {
      system: "metric",
      gender: "male",
      age: 30,
      chest: 10,
      abdominal: 15,
      thigh: 10,
      tricep: 0, // Used for women
      suprailiac: 0, // Used for women
    },
  });

  // Watch for changes
  const navySystem = navyForm.watch("system");
  const navyGender = navyForm.watch("gender");
  const skinfoldGender = skinfoldForm.watch("gender");

  // Calculate body fat percentage using Navy method
  const calculateNavyMethod = (values: NavyFormValues) => {
    let bodyFatPercentage: number;
    let heightConversion = values.height;
    let neckConversion = values.neck;
    let waistConversion = values.waist;
    let hipConversion = values.hip || 0;

    // Convert imperial to metric if needed
    if (values.system === "imperial") {
      heightConversion = values.height * 2.54; // inches to cm
      neckConversion = values.neck * 2.54; // inches to cm
      waistConversion = values.waist * 2.54; // inches to cm
      if (values.hip) {
        hipConversion = values.hip * 2.54; // inches to cm
      }
    }

    // U.S. Navy Method formulas
    if (values.gender === "male") {
      bodyFatPercentage = 495 / (1.0324 - 0.19077 * Math.log10(waistConversion - neckConversion) + 0.15456 * Math.log10(heightConversion)) - 450;
    } else {
      // Female formula requires hip measurement
      if (!hipConversion) {
        throw new Error("Hip measurement is required for women");
      }
      bodyFatPercentage = 495 / (1.29579 - 0.35004 * Math.log10(waistConversion + hipConversion - neckConversion) + 0.22100 * Math.log10(heightConversion)) - 450;
    }

    // Calculate lean mass and fat mass if weight is provided
    let leanMass, fatMass;
    if (values.weight) {
      fatMass = (values.weight * bodyFatPercentage) / 100;
      leanMass = values.weight - fatMass;

      // If using imperial, convert to pounds
      if (values.system === "imperial") {
        fatMass = parseFloat((fatMass * 2.20462).toFixed(1)); // kg to lbs
        leanMass = parseFloat((leanMass * 2.20462).toFixed(1)); // kg to lbs
      } else {
        fatMass = parseFloat(fatMass.toFixed(1));
        leanMass = parseFloat(leanMass.toFixed(1));
      }
    }

    // Determine body fat category
    const category = getBodyFatCategory(bodyFatPercentage, values.gender);

    return {
      bodyFatPercentage: parseFloat(bodyFatPercentage.toFixed(1)),
      leanMass,
      fatMass,
      category: category.category,
      color: category.color,
    };
  };

  // Calculate body fat percentage using Skinfold method (Jackson-Pollock)
  const calculateSkinfoldMethod = (values: SkinfoldFormValues) => {
    let bodyFatPercentage: number;
    let bodyDensity: number;

    if (values.gender === "male") {
      // Jackson-Pollock 3-site formula for men (chest, abdominal, thigh)
      const sum = values.chest + values.abdominal + values.thigh;
      bodyDensity = 1.10938 - (0.0008267 * sum) + (0.0000016 * sum * sum) - (0.0002574 * values.age);
      bodyFatPercentage = (495 / bodyDensity) - 450;
    } else {
      // Jackson-Pollock 3-site formula for women (tricep, suprailiac, thigh)
      if (!values.tricep || !values.suprailiac) {
        throw new Error("Tricep and suprailiac measurements are required for women");
      }
      const sum = values.tricep + values.suprailiac + values.thigh;
      bodyDensity = 1.099421 - (0.0009929 * sum) + (0.0000023 * sum * sum) - (0.0001392 * values.age);
      bodyFatPercentage = (495 / bodyDensity) - 450;
    }

    // Determine body fat category
    const category = getBodyFatCategory(bodyFatPercentage, values.gender);

    return {
      bodyFatPercentage: parseFloat(bodyFatPercentage.toFixed(1)),
      category: category.category,
      color: category.color,
    };
  };

  // Get body fat category based on percentage and gender
  const getBodyFatCategory = (percentage: number, gender: string): BodyFatCategory => {
    const categories = bodyFatCategories[gender];
    if (gender === "male") {
      if (percentage < 6) return categories[0];
      if (percentage < 14) return categories[1];
      if (percentage < 18) return categories[2];
      if (percentage < 25) return categories[3];
      if (percentage < 30) return categories[4];
      return categories[5];
    } else {
      if (percentage < 14) return categories[0];
      if (percentage < 21) return categories[1];
      if (percentage < 25) return categories[2];
      if (percentage < 32) return categories[3];
      if (percentage < 40) return categories[4];
      return categories[5];
    }
  };

  // Form submission handlers
  const onNavySubmit = (values: NavyFormValues) => {
    try {
      const result = calculateNavyMethod(values);
      setBodyFatResult(result);
    } catch (error) {
      if (error instanceof Error) {
        navyForm.setError("hip", { message: error.message });
      }
    }
  };

  const onSkinfoldSubmit = (values: SkinfoldFormValues) => {
    try {
      const result = calculateSkinfoldMethod(values);
      setBodyFatResult(result);
    } catch (error) {
      if (error instanceof Error) {
        if (error.message.includes("Tricep")) {
          skinfoldForm.setError("tricep", { message: error.message });
        } else if (error.message.includes("suprailiac")) {
          skinfoldForm.setError("suprailiac", { message: error.message });
        }
      }
    }
  };

  // Function to get body fat percentage progress
  const getBodyFatProgress = (percentage: number, gender: string): number => {
    const maxValue = gender === "male" ? 40 : 50;
    return Math.min((percentage / maxValue) * 100, 100);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Percent className="mr-2 h-8 w-8" /> Body Fat Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="navy" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="navy">Navy Method</TabsTrigger>
            <TabsTrigger value="skinfold">Skinfold Method</TabsTrigger>
          </TabsList>
          
          {/* Navy Method Tab */}
          <TabsContent value="navy" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Navy Method Calculator</CardTitle>
                <CardDescription>
                  Calculate body fat percentage using body circumference measurements.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...navyForm}>
                  <form onSubmit={navyForm.handleSubmit(onNavySubmit)} className="space-y-6">
                    <FormField
                      control={navyForm.control}
                      name="system"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Measurement System</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="metric" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Metric (cm, kg)</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="imperial" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Imperial (in, lbs)</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={navyForm.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Gender</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={navyForm.control}
                        name="age"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Age</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" min="15" max="80" />
                            </FormControl>
                            <FormDescription>Years</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={navyForm.control}
                        name="height"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Height</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.1" />
                            </FormControl>
                            <FormDescription>
                              {navySystem === "metric" ? "cm" : "inches"}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={navyForm.control}
                        name="weight"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Weight</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.1" />
                            </FormControl>
                            <FormDescription>
                              {navySystem === "metric" ? "kg" : "lbs"}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={navyForm.control}
                        name="neck"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Neck Circumference</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.1" />
                            </FormControl>
                            <FormDescription>
                              {navySystem === "metric" ? "cm" : "inches"}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={navyForm.control}
                        name="waist"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Waist Circumference</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.1" />
                            </FormControl>
                            <FormDescription>
                              {navySystem === "metric" ? "cm" : "inches"}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {navyGender === "female" && (
                        <FormField
                          control={navyForm.control}
                          name="hip"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hip Circumference</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.1" />
                              </FormControl>
                              <FormDescription>
                                {navySystem === "metric" ? "cm" : "inches"}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate Body Fat</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle>Body Fat Results</CardTitle>
                <CardDescription>
                  Your calculated body fat percentage and category.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {bodyFatResult && activeTab === "navy" ? (
                  <div className="space-y-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-primary">
                        {bodyFatResult.bodyFatPercentage}%
                      </div>
                      <div className={`text-lg font-medium mt-1 ${bodyFatResult.color.replace('bg-', 'text-')}`}>
                        {bodyFatResult.category}
                      </div>
                      
                      <div className="mt-4">
                        <Progress 
                          className="h-3" 
                          value={getBodyFatProgress(bodyFatResult.bodyFatPercentage, navyGender)} 
                        />
                        <div className="flex justify-between text-xs mt-1 text-gray-500">
                          <span>Essential</span>
                          <span>Fitness</span>
                          <span>Average</span>
                          <span>Obese</span>
                        </div>
                      </div>
                    </div>

                    {bodyFatResult.leanMass && bodyFatResult.fatMass && (
                      <div className="mt-6 space-y-4">
                        <div>
                          <p className="font-medium">Body Composition</p>
                          <div className="grid grid-cols-2 gap-4 mt-2">
                            <div className="bg-blue-50 p-3 rounded-lg text-center">
                              <div className="text-sm text-gray-600">Lean Mass</div>
                              <div className="text-xl font-bold text-blue-600">
                                {bodyFatResult.leanMass} {navySystem === "metric" ? "kg" : "lbs"}
                              </div>
                            </div>
                            <div className="bg-amber-50 p-3 rounded-lg text-center">
                              <div className="text-sm text-gray-600">Fat Mass</div>
                              <div className="text-xl font-bold text-amber-600">
                                {bodyFatResult.fatMass} {navySystem === "metric" ? "kg" : "lbs"}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    <Separator />

                    <div className="text-sm text-gray-600 space-y-4">
                      <p>
                        <span className="font-medium">About Your Category: </span>
                        {bodyFatCategories[navyGender].find(c => c.category === bodyFatResult.category)?.description}
                      </p>
                      
                      <p className="text-xs text-gray-500">
                        The U.S. Navy Method estimates body fat percentage using body circumference measurements. 
                        While it provides a good estimate, it may not be as accurate as direct methods like DEXA scans.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
                    <Percent className="h-12 w-12 mb-4 text-gray-400" />
                    <p>Fill out the form and click "Calculate Body Fat" to see your results.</p>
                    <p className="mt-2 text-sm">
                      Your body fat percentage, category, and composition breakdown will appear here.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Skinfold Method Tab */}
          <TabsContent value="skinfold" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Skinfold Method Calculator</CardTitle>
                <CardDescription>
                  Calculate body fat percentage using skinfold measurements.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...skinfoldForm}>
                  <form onSubmit={skinfoldForm.handleSubmit(onSkinfoldSubmit)} className="space-y-6">
                    <FormField
                      control={skinfoldForm.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Gender</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={skinfoldForm.control}
                      name="age"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Age</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" min="15" max="80" />
                          </FormControl>
                          <FormDescription>Years</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="p-4 bg-blue-50 rounded-lg mb-4">
                      <h3 className="font-medium mb-2">
                        {skinfoldGender === "male" ? "Male 3-Site Measurements" : "Female 3-Site Measurements"}
                      </h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Enter skinfold measurements in millimeters (mm).
                      </p>
                      
                      {skinfoldGender === "male" ? (
                        <div className="space-y-4">
                          <FormField
                            control={skinfoldForm.control}
                            name="chest"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Chest Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={skinfoldForm.control}
                            name="abdominal"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Abdominal Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={skinfoldForm.control}
                            name="thigh"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Thigh Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <FormField
                            control={skinfoldForm.control}
                            name="tricep"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Tricep Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={skinfoldForm.control}
                            name="suprailiac"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Suprailiac Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={skinfoldForm.control}
                            name="thigh"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Thigh Skinfold</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" />
                                </FormControl>
                                <FormDescription>mm</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate Body Fat</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle>Body Fat Results</CardTitle>
                <CardDescription>
                  Your calculated body fat percentage and category.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {bodyFatResult && activeTab === "skinfold" ? (
                  <div className="space-y-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-primary">
                        {bodyFatResult.bodyFatPercentage}%
                      </div>
                      <div className={`text-lg font-medium mt-1 ${bodyFatResult.color.replace('bg-', 'text-')}`}>
                        {bodyFatResult.category}
                      </div>
                      
                      <div className="mt-4">
                        <Progress 
                          className="h-3" 
                          value={getBodyFatProgress(bodyFatResult.bodyFatPercentage, skinfoldGender)} 
                        />
                        <div className="flex justify-between text-xs mt-1 text-gray-500">
                          <span>Essential</span>
                          <span>Fitness</span>
                          <span>Average</span>
                          <span>Obese</span>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="text-sm text-gray-600 space-y-4">
                      <p>
                        <span className="font-medium">About Your Category: </span>
                        {bodyFatCategories[skinfoldGender].find(c => c.category === bodyFatResult.category)?.description}
                      </p>
                      
                      <p className="text-xs text-gray-500">
                        The Jackson-Pollock 3-site skinfold method estimates body fat percentage 
                        based on the thickness of skinfolds at specific sites. It's generally more 
                        accurate than the Navy method but requires proper technique with calipers.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
                    <FileText className="h-12 w-12 mb-4 text-gray-400" />
                    <p>Fill out the form and click "Calculate Body Fat" to see your results.</p>
                    <p className="mt-2 text-sm">
                      Your body fat percentage and category will appear here.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Body Fat Measurement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                Body fat percentage is the proportion of fat to total body weight. 
                It's an important health metric that can be more meaningful than BMI as it 
                distinguishes between fat and lean mass.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Activity className="w-4 h-4 mr-2" />
                    Navy Method
                  </h3>
                  <p className="mt-2 text-sm">
                    The U.S. Navy circumference method uses measurements of the neck, waist, 
                    and (for women) hips to estimate body fat percentage. It's easy to perform 
                    and requires only a measuring tape.
                  </p>
                  <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
                    <li>Measure neck at narrowest point</li>
                    <li>Measure waist at navel for men, at narrowest point for women</li>
                    <li>Measure hips at widest point (women only)</li>
                    <li>Easy to perform without special equipment</li>
                    <li>Accuracy is within 3-4% of more advanced methods</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <FileText className="w-4 h-4 mr-2" />
                    Skinfold Method
                  </h3>
                  <p className="mt-2 text-sm">
                    The Jackson-Pollock skinfold method measures the thickness of fat folds at 
                    specific sites using calipers. It's more accurate than the Navy method but 
                    requires proper technique and equipment.
                  </p>
                  <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
                    <li>For men: chest, abdominal, and thigh measurements</li>
                    <li>For women: tricep, suprailiac, and thigh measurements</li>
                    <li>Requires skinfold calipers and proper technique</li>
                    <li>More accurate than circumference methods</li>
                    <li>Accuracy is within 2-3% of advanced methods</li>
                  </ul>
                </div>
              </div>
              
              <h3 className="text-lg font-medium text-gray-900 mt-4">Body Fat Categories and Health</h3>
              <p className="text-sm">
                Body fat categories vary by gender due to physiological differences. Women naturally 
                have higher body fat percentages than men. Essential fat is the minimum required for 
                basic physiological functions.
              </p>
              
              <p className="text-gray-500 text-sm">
                <strong>Note:</strong> These calculators provide estimates only. For the most accurate 
                body fat measurement, consider methods like DEXA scans, hydrostatic weighing, or 
                Bod Pod analysis. Always consult with a healthcare professional before making significant 
                lifestyle changes based on these results.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default BodyFatCalculator;
