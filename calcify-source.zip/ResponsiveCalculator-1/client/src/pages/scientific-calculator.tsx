import React, { useState } from 'react';
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calculator, History } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const ScientificCalculator: React.FC = () => {
  const [display, setDisplay] = useState<string>('0');
  const [expression, setExpression] = useState<string>('');
  const [memory, setMemory] = useState<number>(0);
  const [history, setHistory] = useState<Array<{expression: string, result: string}>>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [isNewCalculation, setIsNewCalculation] = useState<boolean>(true);

  // Function to handle number inputs
  const handleNumber = (num: string) => {
    if (display === '0' || isNewCalculation) {
      setDisplay(num);
      setIsNewCalculation(false);
    } else {
      setDisplay(display + num);
    }
  };

  // Function to handle operator inputs
  const handleOperator = (op: string) => {
    if (isNewCalculation) {
      setExpression(display + ' ' + op + ' ');
    } else {
      setExpression(expression + display + ' ' + op + ' ');
    }
    setIsNewCalculation(true);
  };

  // Function to handle decimal point
  const handleDecimal = () => {
    if (isNewCalculation) {
      setDisplay('0.');
      setIsNewCalculation(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  // Function to handle equals button
  const handleEquals = () => {
    try {
      // Create full expression and format it for display
      const fullExpression = expression + display;
      
      // Replace special operators for calculation
      const sanitizedExpression = fullExpression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/\^/g, '**')
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/√\(/g, 'Math.sqrt(')
        .replace(/π/g, 'Math.PI');
      
      // Evaluate the expression
      // eslint-disable-next-line no-eval
      const result = eval(sanitizedExpression);
      
      // Format the result
      const formattedResult = parseFloat(result.toFixed(8)).toString();
      
      // Update history
      setHistory([...history, { expression: fullExpression, result: formattedResult }]);
      
      // Update display with result
      setDisplay(formattedResult);
      setExpression('');
      setIsNewCalculation(true);
    } catch (error) {
      setDisplay('Error');
      setExpression('');
      setIsNewCalculation(true);
    }
  };

  // Function to handle clear button
  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setIsNewCalculation(true);
  };

  // Function to handle backspace
  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  // Function to handle percentage
  const handlePercentage = () => {
    try {
      const value = parseFloat(display) / 100;
      setDisplay(value.toString());
    } catch (error) {
      setDisplay('Error');
    }
  };

  // Function to handle special functions
  const handleFunction = (func: string) => {
    try {
      let result: number;
      const value = parseFloat(display);
      
      switch (func) {
        case 'sin':
          result = Math.sin(value);
          break;
        case 'cos':
          result = Math.cos(value);
          break;
        case 'tan':
          result = Math.tan(value);
          break;
        case 'sqrt':
          if (value < 0) throw new Error('Invalid input');
          result = Math.sqrt(value);
          break;
        case 'log':
          if (value <= 0) throw new Error('Invalid input');
          result = Math.log10(value);
          break;
        case 'ln':
          if (value <= 0) throw new Error('Invalid input');
          result = Math.log(value);
          break;
        case 'squared':
          result = value * value;
          break;
        case 'cubed':
          result = value * value * value;
          break;
        case '1/x':
          if (value === 0) throw new Error('Division by zero');
          result = 1 / value;
          break;
        default:
          throw new Error('Unknown function');
      }
      
      setDisplay(parseFloat(result.toFixed(8)).toString());
      setIsNewCalculation(true);
    } catch (error) {
      setDisplay('Error');
      setIsNewCalculation(true);
    }
  };

  // Memory functions
  const handleMemoryStore = () => {
    setMemory(parseFloat(display));
  };

  const handleMemoryRecall = () => {
    setDisplay(memory.toString());
    setIsNewCalculation(true);
  };

  const handleMemoryClear = () => {
    setMemory(0);
  };

  const handleMemoryAdd = () => {
    setMemory(memory + parseFloat(display));
  };

  const handleMemorySubtract = () => {
    setMemory(memory - parseFloat(display));
  };

  // Toggle history view
  const toggleHistory = () => {
    setShowHistory(!showHistory);
  };

  // Use item from history
  const useHistoryItem = (historyItem: { expression: string, result: string }) => {
    setDisplay(historyItem.result);
    setIsNewCalculation(true);
    setShowHistory(false);
  };

  // Clear history
  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Calculator className="mr-2 h-8 w-8" /> Scientific Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Scientific Calculator</CardTitle>
                <CardDescription>
                  Perform advanced mathematical calculations with this scientific calculator.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 flex justify-between items-center">
                  <div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={toggleHistory}
                      className="flex items-center gap-1"
                    >
                      <History className="h-4 w-4" />
                      {showHistory ? 'Hide History' : 'Show History'}
                    </Button>
                  </div>
                  <div className="text-xs text-gray-500">
                    {memory !== 0 && <span className="mr-2">M</span>}
                    {expression && (
                      <div className="text-right overflow-x-auto whitespace-nowrap max-w-[300px]">
                        {expression}
                      </div>
                    )}
                  </div>
                </div>

                {/* Display */}
                <div className="bg-gray-100 p-4 mb-4 rounded-md">
                  <div className="text-right text-3xl font-mono overflow-x-auto whitespace-nowrap">
                    {display}
                  </div>
                </div>

                {/* Calculator keys */}
                <div className="grid grid-cols-5 gap-2">
                  {/* Memory functions row */}
                  <Button variant="outline" size="sm" onClick={handleMemoryClear}>MC</Button>
                  <Button variant="outline" size="sm" onClick={handleMemoryRecall}>MR</Button>
                  <Button variant="outline" size="sm" onClick={handleMemoryAdd}>M+</Button>
                  <Button variant="outline" size="sm" onClick={handleMemorySubtract}>M-</Button>
                  <Button variant="outline" size="sm" onClick={handleMemoryStore}>MS</Button>
                  
                  {/* Scientific functions row 1 */}
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('squared')}>x²</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('cubed')}>x³</Button>
                  <Button variant="secondary" size="sm" onClick={() => setDisplay(Math.PI.toString())}>π</Button>
                  <Button variant="secondary" size="sm" onClick={() => setDisplay(Math.E.toString())}>e</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('1/x')}>1/x</Button>
                  
                  {/* Scientific functions row 2 */}
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('sqrt')}>√</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('log')}>log</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('ln')}>ln</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleOperator('^')}>^</Button>
                  <Button variant="secondary" size="sm" onClick={handlePercentage}>%</Button>
                  
                  {/* Scientific functions row 3 */}
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('sin')}>sin</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('cos')}>cos</Button>
                  <Button variant="secondary" size="sm" onClick={() => handleFunction('tan')}>tan</Button>
                  <Button variant="destructive" size="sm" onClick={handleClear}>C</Button>
                  <Button variant="destructive" size="sm" onClick={handleBackspace}>⌫</Button>
                  
                  {/* Numbers and basic operations */}
                  <Button onClick={() => handleNumber('7')}>7</Button>
                  <Button onClick={() => handleNumber('8')}>8</Button>
                  <Button onClick={() => handleNumber('9')}>9</Button>
                  <Button variant="secondary" onClick={() => handleOperator('÷')}>÷</Button>
                  <Button variant="secondary" onClick={() => handleOperator('×')}>×</Button>
                  
                  <Button onClick={() => handleNumber('4')}>4</Button>
                  <Button onClick={() => handleNumber('5')}>5</Button>
                  <Button onClick={() => handleNumber('6')}>6</Button>
                  <Button variant="secondary" onClick={() => handleOperator('-')}>-</Button>
                  <Button variant="secondary" onClick={() => handleOperator('+')}>+</Button>
                  
                  <Button onClick={() => handleNumber('1')}>1</Button>
                  <Button onClick={() => handleNumber('2')}>2</Button>
                  <Button onClick={() => handleNumber('3')}>3</Button>
                  <Button 
                    variant="default" 
                    className="row-span-2 bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={handleEquals}
                  >
                    =
                  </Button>
                  <Button variant="secondary" onClick={() => handleNumber('0')} className="col-span-2">0</Button>
                  <Button variant="secondary" onClick={handleDecimal}>.</Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* History panel */}
          <div className={`${showHistory ? 'block' : 'hidden md:block'}`}>
            <Card className="h-full">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">History</CardTitle>
                  {history.length > 0 && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={clearHistory}
                      className="text-xs text-red-500 hover:text-red-700"
                    >
                      Clear History
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {history.length > 0 ? (
                  <div className="space-y-2 max-h-[500px] overflow-y-auto">
                    {history.slice().reverse().map((item, index) => (
                      <div 
                        key={index} 
                        className="p-2 border rounded-md hover:bg-gray-50 cursor-pointer"
                        onClick={() => useHistoryItem(item)}
                      >
                        <div className="text-sm text-gray-500">{item.expression}</div>
                        <div className="text-lg font-medium">{item.result}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <History className="h-12 w-12 mx-auto mb-2 opacity-30" />
                    <p>No calculation history yet</p>
                    <p className="text-sm">Your calculations will appear here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>How to Use the Scientific Calculator</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This scientific calculator supports a wide range of functions for both simple and complex calculations.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Basic Operations</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Addition (+), Subtraction (-), Multiplication (×), Division (÷)</li>
                    <li>Percentage calculations (%)</li>
                    <li>Powers and roots (x², x³, √)</li>
                    <li>Memory functions (M+, M-, MR, MS, MC)</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Advanced Functions</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Trigonometric functions (sin, cos, tan)</li>
                    <li>Logarithmic functions (log, ln)</li>
                    <li>Constants (π, e)</li>
                    <li>Exponents and power functions (^)</li>
                    <li>Reciprocal (1/x)</li>
                  </ul>
                </div>
              </div>
              
              <h3 className="text-lg font-medium text-gray-900">Keyboard Shortcuts</h3>
              <p className="text-sm">
                You can also use your keyboard for input:
              </p>
              <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
                <li>Numbers 0-9 for digit input</li>
                <li>+, -, *, / for basic operations</li>
                <li>Enter key for equals (=)</li>
                <li>Backspace for deleting the last character</li>
                <li>Escape key for clear (C)</li>
              </ul>
              
              <Separator className="my-4" />
              
              <p className="text-sm text-gray-500">
                <strong>Note:</strong> This calculator evaluates expressions using standard mathematical order of operations (PEMDAS):
                Parentheses, Exponents, Multiplication and Division, Addition and Subtraction.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default ScientificCalculator;
