import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Shield, Lock, Eye, FileText } from 'lucide-react';
import { Link } from 'wouter';

const Privacy: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Shield className="mr-2 h-8 w-8" /> Privacy Policy
          </h1>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Our Commitment to Privacy</CardTitle>
            <CardDescription>
              Last Updated: May 1, 2025
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              At Calculator Suite, we are committed to protecting your privacy. This Privacy Policy explains how we collect, 
              use, disclose, and safeguard your information when you visit our website, including any other media form, 
              media channel, mobile website, or mobile application related or connected thereto (collectively, the "Site").
            </p>
            <p>
              Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, 
              please do not access the site.
            </p>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="mr-2 h-6 w-6" /> Information We Collect
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <h3 className="text-lg font-medium">Information You Provide to Us</h3>
            <p>We may collect information that you provide when you:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Contact us through the contact form</li>
              <li>Subscribe to our newsletter</li>
              <li>Respond to surveys or other communication</li>
            </ul>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Calculator Data</h3>
            <p>
              <strong>Our calculators operate entirely within your browser.</strong> The data you enter into our 
              calculators (such as financial information, health metrics, or other personal details) is processed 
              locally on your device and is not transmitted to or stored on our servers. We have specifically 
              designed our service this way to maximize your privacy.
            </p>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Automatically Collected Information</h3>
            <p>
              When you access our Site, we may automatically collect certain information about your device, including:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Device type and browser information</li>
              <li>Operating system</li>
              <li>IP address</li>
              <li>Pages visited and time spent on the Site</li>
              <li>Referring website or source</li>
            </ul>
            <p className="text-sm text-gray-600 mt-2">
              This information is used solely for analyzing trends, administering the site, tracking users' movement 
              around the site, and gathering demographic information.
            </p>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lock className="mr-2 h-6 w-6" /> How We Use Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>We may use the information we collect for various purposes, including to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Improve and optimize our website</li>
              <li>Respond to your comments, questions, and requests</li>
              <li>Monitor and analyze usage patterns and trends</li>
              <li>Protect the security and integrity of our Site</li>
              <li>Comply with any applicable laws and regulations</li>
            </ul>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Cookies and Tracking Technologies</h3>
            <p>
              We use cookies and similar tracking technologies to track activity on our Site and hold certain information. 
              Cookies are files with a small amount of data which may include an anonymous unique identifier. 
              You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
            </p>
            <p className="text-sm text-gray-600 mt-2">
              We use functionality cookies to recognize you on our website and remember your previously selected preferences, 
              analytical cookies to understand how visitors interact with our website, and occasionally advertising cookies 
              if we choose to display advertisements.
            </p>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-6 w-6" /> Disclosure of Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>We may share information we have collected in certain situations. Your information may be disclosed as follows:</p>
            
            <h3 className="text-lg font-medium">By Law or to Protect Rights</h3>
            <p>
              If we believe the release of information is necessary to comply with the law, enforce our site policies, 
              or protect our or others' rights, property, or safety, we may share your information.
            </p>
            
            <h3 className="text-lg font-medium">Third-Party Service Providers</h3>
            <p>
              We may share your information with third-party service providers who perform services on our behalf, 
              such as analytics providers and email service providers. These service providers are contractually 
              obligated to keep your information confidential.
            </p>
            
            <h3 className="text-lg font-medium">Business Transfers</h3>
            <p>
              If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your information 
              may be transferred as part of that transaction, but we will notify you via prominent notice on our Site 
              of any change in ownership or uses of your information.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Your Rights and Choices</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>You have certain rights regarding the personal information we collect about you:</p>
            
            <h3 className="text-lg font-medium">Access and Update</h3>
            <p>
              You may contact us to request access to, correct, or delete any personal information that you have provided to us. 
              We may not accommodate a request to change information if we believe the change would violate any law or legal 
              requirement or cause the information to be incorrect.
            </p>
            
            <h3 className="text-lg font-medium">Cookies and Tracking</h3>
            <p>
              Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser 
              to remove or reject browser cookies. Please note that if you choose to remove or reject cookies, this could affect 
              certain features of our Site.
            </p>
            
            <h3 className="text-lg font-medium">Communications</h3>
            <p>
              If you no longer wish to receive correspondence, emails, or other communications from us, you may opt-out by:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Clicking the unsubscribe link in our emails</li>
              <li>Contacting us using the contact information provided below</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6">Contact Us</h3>
            <p>
              If you have questions or concerns about this Privacy Policy, please contact us at:
            </p>
            <p className="mt-2">
              Email: <span className="text-blue-600">privacy@calculatorsuite.example.com</span>
            </p>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default Privacy;
