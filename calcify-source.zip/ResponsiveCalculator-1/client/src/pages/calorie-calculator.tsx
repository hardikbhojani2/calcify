import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Flame, Activity, BarChart } from 'lucide-react';
import { Link } from 'wouter';

// Define the calorie calculator form schema
const calorieSchema = z.object({
  system: z.enum(["metric", "imperial"]),
  gender: z.enum(["male", "female"]),
  age: z.coerce.number().int().min(15, "Age must be at least 15").max(80, "Age must be at most 80"),
  height: z.coerce.number().positive("Height must be positive"),
  weight: z.coerce.number().positive("Weight must be positive"),
  activityLevel: z.enum(["sedentary", "light", "moderate", "active", "very_active"]),
  goal: z.enum(["maintain", "mild_loss", "weight_loss", "extreme_loss", "mild_gain", "weight_gain", "fast_gain"]),
});

type FormValues = z.infer<typeof calorieSchema>;

const activityLevelDescriptions = {
  sedentary: "Little to no exercise / desk job",
  light: "Light exercise 1-3 days/week",
  moderate: "Moderate exercise 3-5 days/week",
  active: "Heavy exercise 6-7 days/week",
  very_active: "Very heavy exercise, physical job or training twice a day"
};

const goalDescriptions = {
  maintain: "Maintain current weight",
  mild_loss: "Mild weight loss (0.25 kg/week)",
  weight_loss: "Weight loss (0.5 kg/week)",
  extreme_loss: "Extreme weight loss (1 kg/week)",
  mild_gain: "Mild weight gain (0.25 kg/week)",
  weight_gain: "Weight gain (0.5 kg/week)",
  fast_gain: "Fast weight gain (1 kg/week)"
};

const macroRatios = {
  maintain: { carbs: 50, protein: 25, fat: 25 },
  mild_loss: { carbs: 45, protein: 30, fat: 25 },
  weight_loss: { carbs: 40, protein: 35, fat: 25 },
  extreme_loss: { carbs: 25, protein: 45, fat: 30 },
  mild_gain: { carbs: 55, protein: 25, fat: 20 },
  weight_gain: { carbs: 60, protein: 25, fat: 15 },
  fast_gain: { carbs: 65, protein: 20, fat: 15 }
};

const CalorieCalculator: React.FC = () => {
  const [calorieResult, setCalorieResult] = useState<{
    bmr: number;
    maintenanceCalories: number;
    goalCalories: number;
    macros: {
      carbs: { grams: number; calories: number; percentage: number };
      protein: { grams: number; calories: number; percentage: number };
      fat: { grams: number; calories: number; percentage: number };
    };
  } | null>(null);

  // Initialize the form
  const form = useForm<FormValues>({
    resolver: zodResolver(calorieSchema),
    defaultValues: {
      system: "metric",
      gender: "male",
      age: 30,
      height: 175, // cm
      weight: 75, // kg
      activityLevel: "moderate",
      goal: "maintain",
    },
  });

  // Watch for system changes to update labels
  const selectedSystem = form.watch("system");
  const selectedGoal = form.watch("goal");

  // Function to calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
  const calculateBMR = (values: FormValues): number => {
    // Convert imperial to metric if needed
    let weightInKg = values.weight;
    let heightInCm = values.height;

    if (values.system === "imperial") {
      weightInKg = values.weight * 0.453592; // Convert pounds to kg
      heightInCm = values.height * 2.54; // Convert inches to cm
    }

    // Mifflin-St Jeor Equation
    let bmr: number;
    if (values.gender === "male") {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * values.age + 5;
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * values.age - 161;
    }

    return Math.round(bmr);
  };

  // Function to calculate maintenance calories based on activity level
  const calculateMaintenanceCalories = (bmr: number, activityLevel: string): number => {
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9
    };

    return Math.round(bmr * activityMultipliers[activityLevel]);
  };

  // Function to calculate goal calories based on weight goal
  const calculateGoalCalories = (maintenanceCalories: number, goal: string): number => {
    // Caloric adjustments for different goals
    // For metric: 1 kg of weight change per week is approximately 7700 calories (1100 calories/day)
    // For imperial: 1 lb of weight change per week is approximately 3500 calories (500 calories/day)
    const goalAdjustments: Record<string, number> = {
      maintain: 0,
      mild_loss: -275, // 0.25 kg/week
      weight_loss: -550, // 0.5 kg/week
      extreme_loss: -1100, // 1 kg/week
      mild_gain: 275, // 0.25 kg/week
      weight_gain: 550, // 0.5 kg/week
      fast_gain: 1100 // 1 kg/week
    };

    return Math.round(maintenanceCalories + goalAdjustments[goal]);
  };

  // Function to calculate macronutrients based on goal calories
  const calculateMacros = (goalCalories: number, goal: string) => {
    const { carbs, protein, fat } = macroRatios[goal as keyof typeof macroRatios];

    const carbCalories = (goalCalories * carbs) / 100;
    const proteinCalories = (goalCalories * protein) / 100;
    const fatCalories = (goalCalories * fat) / 100;

    // 1g of carbs = 4 calories, 1g of protein = 4 calories, 1g of fat = 9 calories
    const carbGrams = Math.round(carbCalories / 4);
    const proteinGrams = Math.round(proteinCalories / 4);
    const fatGrams = Math.round(fatCalories / 9);

    return {
      carbs: { grams: carbGrams, calories: Math.round(carbCalories), percentage: carbs },
      protein: { grams: proteinGrams, calories: Math.round(proteinCalories), percentage: protein },
      fat: { grams: fatGrams, calories: Math.round(fatCalories), percentage: fat }
    };
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    const bmr = calculateBMR(values);
    const maintenanceCalories = calculateMaintenanceCalories(bmr, values.activityLevel);
    const goalCalories = calculateGoalCalories(maintenanceCalories, values.goal);
    const macros = calculateMacros(goalCalories, values.goal);

    setCalorieResult({
      bmr,
      maintenanceCalories,
      goalCalories,
      macros
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Flame className="mr-2 h-8 w-8" /> Calorie Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Daily Calories</CardTitle>
              <CardDescription>Find out how many calories you need based on your goals.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="system"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Measurement System</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="metric" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Metric (cm, kg)</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="imperial" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Imperial (in, lbs)</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Gender</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="male" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="female" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="age"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Age</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" min="15" max="80" />
                          </FormControl>
                          <FormDescription>
                            Years
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="height"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Height</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" />
                          </FormControl>
                          <FormDescription>
                            {selectedSystem === "metric" ? "cm" : "inches"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="weight"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Weight</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" />
                          </FormControl>
                          <FormDescription>
                            {selectedSystem === "metric" ? "kg" : "lbs"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="activityLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Activity Level</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select activity level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.entries(activityLevelDescriptions).map(([value, description]) => (
                              <SelectItem key={value} value={value}>
                                {description}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="goal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Goal</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your goal" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.entries(goalDescriptions).map(([value, description]) => (
                              <SelectItem key={value} value={value}>
                                {description}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button type="submit" className="w-full">Calculate Calories</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Calorie Results</CardTitle>
              <CardDescription>
                These calculations estimate your caloric needs based on your details and goals.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {calorieResult ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-sm font-medium text-gray-500 mb-1">Daily Calories for Your Goal</div>
                    <div className="text-4xl font-bold text-primary">
                      {calorieResult.goalCalories}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      Calories per day to {selectedGoal.includes('loss') ? 'lose' : selectedGoal.includes('gain') ? 'gain' : 'maintain'} weight
                    </div>
                  </div>

                  <Separator />
                  
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-medium flex items-center">
                        <Activity className="w-4 h-4 mr-2 text-gray-500" />
                        Metabolic Information
                      </h3>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <div className="text-sm">
                          <div className="font-medium">BMR:</div>
                          <div>{calorieResult.bmr} calories/day</div>
                          <div className="text-xs text-gray-500 mt-1">
                            Calories your body needs at complete rest
                          </div>
                        </div>
                        <div className="text-sm">
                          <div className="font-medium">Maintenance:</div>
                          <div>{calorieResult.maintenanceCalories} calories/day</div>
                          <div className="text-xs text-gray-500 mt-1">
                            Calories to maintain current weight
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium flex items-center">
                        <BarChart className="w-4 h-4 mr-2 text-gray-500" />
                        Recommended Macronutrients
                      </h3>
                      <div className="mt-2 space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                            <span className="text-sm">Carbs ({calorieResult.macros.carbs.percentage}%)</span>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">{calorieResult.macros.carbs.grams}g</span>
                            <span className="text-gray-500 ml-1">({calorieResult.macros.carbs.calories} cal)</span>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                            <span className="text-sm">Protein ({calorieResult.macros.protein.percentage}%)</span>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">{calorieResult.macros.protein.grams}g</span>
                            <span className="text-gray-500 ml-1">({calorieResult.macros.protein.calories} cal)</span>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                            <span className="text-sm">Fat ({calorieResult.macros.fat.percentage}%)</span>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">{calorieResult.macros.fat.grams}g</span>
                            <span className="text-gray-500 ml-1">({calorieResult.macros.fat.calories} cal)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />
                  
                  <div className="text-sm text-gray-500 space-y-1">
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Height:</span>
                      <span className="col-span-2">
                        {form.getValues().height} {selectedSystem === "metric" ? "cm" : "in"}
                      </span>
                    </div>
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Weight:</span>
                      <span className="col-span-2">
                        {form.getValues().weight} {selectedSystem === "metric" ? "kg" : "lbs"}
                      </span>
                    </div>
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Age:</span>
                      <span className="col-span-2">{form.getValues().age} years</span>
                    </div>
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Gender:</span>
                      <span className="col-span-2 capitalize">{form.getValues().gender}</span>
                    </div>
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Activity:</span>
                      <span className="col-span-2">
                        {activityLevelDescriptions[form.getValues().activityLevel as keyof typeof activityLevelDescriptions]}
                      </span>
                    </div>
                    <div className="grid grid-cols-3">
                      <span className="font-medium">Goal:</span>
                      <span className="col-span-2">
                        {goalDescriptions[form.getValues().goal as keyof typeof goalDescriptions]}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
                  <Flame className="h-12 w-12 mb-4 text-gray-400" />
                  <p>Fill out the form and click "Calculate Calories" to see your results.</p>
                  <p className="mt-2 text-sm">
                    Your personalized calorie needs and macronutrient breakdown will appear here.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Calorie Calculation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This calculator uses the Mifflin-St Jeor Equation to estimate your Basal Metabolic Rate (BMR), 
                which is the number of calories your body needs to maintain basic physiological functions while at rest.
              </p>
              
              <h3 className="text-lg font-medium text-gray-900">Understanding Calorie Calculations:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li><span className="font-medium">BMR (Basal Metabolic Rate):</span> The calories your body burns at complete rest.</li>
                <li><span className="font-medium">Maintenance Calories:</span> BMR adjusted for your activity level, representing the calories needed to maintain your current weight.</li>
                <li><span className="font-medium">Goal Calories:</span> Adjusted from maintenance calories based on your weight goal (lose, maintain, or gain).</li>
                <li><span className="font-medium">Macronutrients:</span> The distribution of calories among carbohydrates, protein, and fat, adjusted according to your goal.</li>
              </ul>
              
              <h3 className="text-lg font-medium text-gray-900">Guidelines for Healthy Weight Management:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>A safe rate of weight loss is 0.5-1 kg (1-2 pounds) per week.</li>
                <li>Gradual changes are more sustainable than drastic calorie reductions.</li>
                <li>Combine calorie management with regular physical activity for best results.</li>
                <li>Focus on nutrient-rich foods rather than just calorie counting.</li>
                <li>Stay hydrated, as water is essential for metabolism and can help with weight management.</li>
              </ul>
              
              <p className="text-gray-500 text-sm">
                <strong>Note:</strong> This calculator provides estimates only. Individual metabolism varies, and other factors like medical conditions, medications, and genetics play a role in energy requirements. 
                Consult with a healthcare professional before making significant changes to your diet or exercise regimen.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default CalorieCalculator;
