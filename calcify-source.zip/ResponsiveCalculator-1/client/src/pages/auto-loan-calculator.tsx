import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Car, DollarSign, CalendarClock, Info } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema
const formSchema = z.object({
  vehiclePrice: z.coerce.number().positive("Vehicle price must be greater than zero"),
  downPayment: z.coerce.number().min(0, "Down payment cannot be negative"),
  tradeInValue: z.coerce.number().min(0, "Trade-in value cannot be negative"),
  salesTax: z.coerce.number().min(0, "Sales tax cannot be negative").max(100, "Sales tax cannot exceed 100%"),
  loanTerm: z.coerce.number().int().min(1, "Loan term must be at least 1 month").max(120, "Loan term cannot exceed 120 months"),
  interestRate: z.coerce.number().min(0, "Interest rate cannot be negative").max(100, "Interest rate cannot exceed 100%"),
  paymentFrequency: z.enum(["monthly", "biweekly", "weekly"]),
  includeExtras: z.boolean().default(false),
  titleFee: z.coerce.number().min(0, "Title fee cannot be negative"),
  registrationFee: z.coerce.number().min(0, "Registration fee cannot be negative"),
  dealerFee: z.coerce.number().min(0, "Dealer fee cannot be negative"),
});

type FormValues = z.infer<typeof formSchema>;

const AutoLoanCalculator: React.FC = () => {
  const [result, setResult] = useState<{
    loanAmount: number;
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
    paymentSchedule: Array<{
      period: number;
      payment: number;
      principal: number;
      interest: number;
      balance: number;
    }>;
  } | null>(null);
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      vehiclePrice: 30000,
      downPayment: 3000,
      tradeInValue: 0,
      salesTax: 6,
      loanTerm: 60,
      interestRate: 4.5,
      paymentFrequency: "monthly",
      includeExtras: false,
      titleFee: 100,
      registrationFee: 200,
      dealerFee: 500,
    },
  });
  
  // Watch form values for real-time updates
  const includeExtras = form.watch("includeExtras");
  const downPayment = form.watch("downPayment");
  const vehiclePrice = form.watch("vehiclePrice");
  const tradeInValue = form.watch("tradeInValue");
  const salesTax = form.watch("salesTax");
  
  // Calculate loan details
  const calculateLoan = (values: FormValues) => {
    const {
      vehiclePrice,
      downPayment,
      tradeInValue,
      salesTax,
      loanTerm,
      interestRate,
      paymentFrequency,
      includeExtras,
      titleFee,
      registrationFee,
      dealerFee,
    } = values;
    
    // Calculate taxable amount (vehicle price minus trade-in value)
    const taxableAmount = vehiclePrice - tradeInValue;
    const taxAmount = (taxableAmount * salesTax) / 100;
    
    // Calculate total extras
    let extrasTotal = 0;
    if (includeExtras) {
      extrasTotal = titleFee + registrationFee + dealerFee;
    }
    
    // Calculate loan amount
    const loanAmount = vehiclePrice - downPayment - tradeInValue + taxAmount + extrasTotal;
    
    // Convert to monthly values
    const monthlyRate = interestRate / 100 / 12;
    const totalMonths = loanTerm;
    
    // Calculate monthly payment (standard loan amortization formula)
    let monthlyPayment = 0;
    if (interestRate === 0) {
      // If interest rate is 0, simple division
      monthlyPayment = loanAmount / totalMonths;
    } else {
      // Standard loan amortization formula
      monthlyPayment = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -totalMonths));
    }
    
    // Calculate payment based on frequency
    let frequencyMultiplier = 1;
    let paymentPeriods = totalMonths;
    
    if (paymentFrequency === "biweekly") {
      frequencyMultiplier = 12 / 26;
      paymentPeriods = totalMonths * 26 / 12;
    } else if (paymentFrequency === "weekly") {
      frequencyMultiplier = 12 / 52;
      paymentPeriods = totalMonths * 52 / 12;
    }
    
    const frequencyPayment = monthlyPayment * frequencyMultiplier;
    
    // Calculate total payment and interest
    const totalPayment = frequencyPayment * paymentPeriods;
    const totalInterest = totalPayment - loanAmount;
    
    // Generate payment schedule (using monthly payments for consistency)
    const paymentSchedule = [];
    let balance = loanAmount;
    
    for (let period = 1; period <= totalMonths; period++) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      balance -= principalPayment;
      
      paymentSchedule.push({
        period,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance) // Ensure balance doesn't go below 0 due to rounding
      });
      
      if (balance <= 0) {
        break;
      }
    }
    
    return {
      loanAmount,
      monthlyPayment: frequencyPayment,
      totalPayment,
      totalInterest,
      paymentSchedule
    };
  };
  
  // Submit handler
  const onSubmit = (values: FormValues) => {
    try {
      const results = calculateLoan(values);
      setResult(results);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };
  
  // Calculate estimated loan amount for display
  const estimatedLoanAmount = () => {
    try {
      const taxableAmount = vehiclePrice - tradeInValue;
      const taxAmount = (taxableAmount * salesTax) / 100;
      
      let extrasTotal = 0;
      if (includeExtras) {
        const titleFee = form.getValues("titleFee");
        const registrationFee = form.getValues("registrationFee");
        const dealerFee = form.getValues("dealerFee");
        extrasTotal = titleFee + registrationFee + dealerFee;
      }
      
      return vehiclePrice - downPayment - tradeInValue + taxAmount + extrasTotal;
    } catch {
      return 0;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Car className="mr-2 h-8 w-8" /> Auto Loan Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Calculate Auto Loan Payments</CardTitle>
                <CardDescription>
                  Enter your auto loan details to calculate your payments and amortization schedule.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Vehicle Information</h3>
                      
                      <FormField
                        control={form.control}
                        name="vehiclePrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Vehicle Price</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-3 text-gray-500">$</span>
                                <Input {...field} type="number" step="100" min="0" className="pl-7" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="downPayment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Down Payment</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="100" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="tradeInValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Trade-in Value</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="100" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="salesTax"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sales Tax Rate (%)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input {...field} type="number" step="0.1" min="0" max="100" />
                                <span className="absolute right-3 top-3 text-gray-500">%</span>
                              </div>
                            </FormControl>
                            <FormDescription>
                              Your local sales tax rate for vehicles.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Loan Details</h3>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="loanTerm"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Loan Term (months)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" min="1" max="120" />
                                  <span className="absolute right-3 top-3 text-gray-500">mo</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="interestRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Interest Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.01" min="0" max="100" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="paymentFrequency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Frequency</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select payment frequency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="monthly">Monthly</SelectItem>
                                <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                <SelectItem value="weekly">Weekly</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              How often you'll make payments on your loan.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="includeExtras"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                            <FormControl>
                              <div className="flex items-center h-4 mt-1">
                                <input
                                  type="checkbox"
                                  checked={field.value}
                                  onChange={field.onChange}
                                  className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                />
                              </div>
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Include Additional Fees
                              </FormLabel>
                              <FormDescription>
                                Add title, registration, and dealer fees to the loan amount.
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      {includeExtras && (
                        <div className="grid grid-cols-3 gap-4 mt-4">
                          <FormField
                            control={form.control}
                            name="titleFee"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Title Fee</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="registrationFee"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Registration Fee</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="dealerFee"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Dealer Fee</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium">Estimated Loan Amount:</p>
                        <p className="text-lg font-semibold">${estimatedLoanAmount().toFixed(2)}</p>
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate Auto Loan</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
          
          <div>
            {result ? (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Auto Loan Results</CardTitle>
                    <CardDescription>
                      Based on your loan details, here's your payment information.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <p className="text-sm text-gray-500">Loan Amount</p>
                        <p className="text-2xl font-bold">${result.loanAmount.toFixed(2)}</p>
                      </div>
                      
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <p className="text-sm text-gray-500">
                          {form.getValues("paymentFrequency") === "monthly" ? "Monthly" : 
                           form.getValues("paymentFrequency") === "biweekly" ? "Bi-weekly" : 
                           "Weekly"} Payment
                        </p>
                        <p className="text-2xl font-bold">${result.monthlyPayment.toFixed(2)}</p>
                      </div>
                      
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <p className="text-sm text-gray-500">Total Interest</p>
                        <p className="text-2xl font-bold">${result.totalInterest.toFixed(2)}</p>
                      </div>
                      
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <p className="text-sm text-gray-500">Total Payment</p>
                        <p className="text-2xl font-bold">${result.totalPayment.toFixed(2)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Amortization Schedule</CardTitle>
                    <CardDescription>
                      Monthly payment breakdown for your auto loan.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="border rounded-md divide-y max-h-[400px] overflow-auto">
                      <div className="grid grid-cols-5 gap-4 p-3 font-medium bg-gray-50 sticky top-0">
                        <div>Month</div>
                        <div>Payment</div>
                        <div>Principal</div>
                        <div>Interest</div>
                        <div>Remaining</div>
                      </div>
                      
                      {result.paymentSchedule.map((period) => (
                        <div key={period.period} className="grid grid-cols-5 gap-4 p-3 text-sm">
                          <div>{period.period}</div>
                          <div>${period.payment.toFixed(2)}</div>
                          <div>${period.principal.toFixed(2)}</div>
                          <div>${period.interest.toFixed(2)}</div>
                          <div>${period.balance.toFixed(2)}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Auto Loan Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center py-12 h-full flex flex-col items-center justify-center text-gray-500">
                    <Info className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-lg">Enter your auto loan details and click "Calculate Auto Loan"</p>
                    <p className="text-sm mt-2">Results will appear here</p>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Understanding Auto Loans</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Vehicle Purchase Breakdown</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    When you buy a car, the loan amount includes the vehicle price, minus your down payment and trade-in, 
                    plus sales tax and any additional fees. Understanding this breakdown helps you negotiate better deals.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Payment Frequency Options</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    <strong>Monthly payments</strong> are standard for most auto loans. <strong>Bi-weekly payments</strong> (every two weeks) 
                    result in 26 payments per year (equivalent to 13 monthly payments), helping you pay off your loan faster. 
                    <strong>Weekly payments</strong> can further accelerate payoff and reduce interest costs.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Additional Costs to Consider</h3>
                  <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-gray-600">
                    <li><strong>Insurance:</strong> Auto lenders require comprehensive coverage while the loan is active.</li>
                    <li><strong>Maintenance:</strong> Budget for regular service and unexpected repairs.</li>
                    <li><strong>Fuel and operating costs:</strong> Consider the vehicle's fuel efficiency.</li>
                    <li><strong>Depreciation:</strong> New vehicles typically lose 20-30% of their value in the first year.</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AutoLoanCalculator;
