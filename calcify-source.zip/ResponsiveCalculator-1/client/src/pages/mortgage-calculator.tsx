import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Calculator, DollarSign, Home, Percent } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema with zod
const formSchema = z.object({
  propertyValue: z.coerce.number().positive("Property value must be positive"),
  downPayment: z.coerce.number().min(0, "Down payment can't be negative"),
  loanTerm: z.coerce.number().int().min(1, "Loan term must be at least 1 year").max(40, "Loan term cannot exceed 40 years"),
  interestRate: z.coerce.number().min(0.1, "Interest rate must be positive").max(25, "Interest rate too high")
});

type FormValues = z.infer<typeof formSchema>;

const MortgageCalculator: React.FC = () => {
  const { toast } = useToast();
  const [results, setResults] = useState<{
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
    downPaymentPercentage: number;
  } | null>(null);

  // Initialize the form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      propertyValue: 300000,
      downPayment: 60000,
      loanTerm: 30,
      interestRate: 4.5
    },
  });

  // Watch form values for real-time updates
  const propertyValue = form.watch('propertyValue');
  const downPayment = form.watch('downPayment');
  const loanTerm = form.watch('loanTerm');
  const interestRate = form.watch('interestRate');
  
  // Calculate down payment percentage
  const downPaymentPercentage = propertyValue > 0 ? (downPayment / propertyValue) * 100 : 0;
  
  // Calculate loan amount
  const loanAmount = propertyValue - downPayment;

  // Function to calculate mortgage payments
  const calculateMortgage = (values: FormValues) => {
    const p = values.propertyValue - values.downPayment; // Principal (loan amount)
    const r = values.interestRate / 100 / 12; // Monthly interest rate
    const n = values.loanTerm * 12; // Total number of payments
    
    // Monthly payment formula: P * (r * (1 + r)^n) / ((1 + r)^n - 1)
    let monthlyPayment = 0;
    if (r > 0) {
      monthlyPayment = p * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    } else {
      monthlyPayment = p / n; // If interest rate is 0, simple division
    }
    
    const totalPayment = monthlyPayment * n;
    const totalInterest = totalPayment - p;
    
    return {
      monthlyPayment: monthlyPayment, 
      totalPayment: totalPayment,
      totalInterest: totalInterest,
      downPaymentPercentage: (values.downPayment / values.propertyValue) * 100
    };
  };
  
  // Update results in real-time when form values change
  React.useEffect(() => {
    if (form.formState.isValid) {
      const currentValues = form.getValues();
      try {
        const results = calculateMortgage(currentValues);
        setResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [propertyValue, downPayment, loanTerm, interestRate, form]);

  const onSubmit = (values: FormValues) => {
    try {
      const results = calculateMortgage(values);
      setResults(results);
      toast({
        title: 'Mortgage calculated',
        description: 'Your mortgage has been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating your mortgage.',
        variant: 'destructive',
      });
    }
  };

  // Handle down payment slider change
  const handleDownPaymentSliderChange = (value: number[]) => {
    const percentage = value[0];
    const newDownPayment = (percentage / 100) * propertyValue;
    form.setValue('downPayment', newDownPayment, { shouldValidate: true });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Home className="mr-2 h-8 w-8" /> Mortgage Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Form Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calculator className="mr-2 h-5 w-5" />
                Calculate Your Mortgage
              </CardTitle>
              <CardDescription>
                Enter your property details to calculate monthly mortgage payments.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="propertyValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Value ($)</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                            <Input 
                              {...field} 
                              type="number" 
                              className="pl-10" 
                              onChange={(e) => {
                                field.onChange(e);
                                const newValue = parseFloat(e.target.value);
                                if (!isNaN(newValue) && newValue > 0) {
                                  // Adjust down payment to maintain the same percentage
                                  const currentPercentage = downPaymentPercentage;
                                  const newDownPayment = (currentPercentage / 100) * newValue;
                                  form.setValue('downPayment', newDownPayment, { shouldValidate: true });
                                }
                              }}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="downPayment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          Down Payment ($) - {downPaymentPercentage.toFixed(1)}%
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                            <Input {...field} type="number" className="pl-10" />
                          </div>
                        </FormControl>
                        <Slider
                          defaultValue={[20]}
                          value={[downPaymentPercentage]}
                          max={100}
                          step={1}
                          onValueChange={handleDownPaymentSliderChange}
                          className="mt-2"
                        />
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="loanTerm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loan Term (Years)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="interestRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Interest Rate (%)</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Percent className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                              <Input {...field} type="number" step="0.1" className="pl-10" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit" className="w-full">Calculate</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Results Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="mr-2 h-5 w-5" />
                Mortgage Summary
              </CardTitle>
              <CardDescription>
                Based on your inputs, here's your mortgage breakdown.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results ? (
                <div className="space-y-6">
                  <div className="text-center p-6 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-500">Monthly Payment</div>
                    <div className="text-4xl font-bold text-primary">
                      ${results.monthlyPayment.toFixed(2)}
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Loan Amount</div>
                      <div className="text-xl font-semibold">${loanAmount.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Down Payment</div>
                      <div className="text-xl font-semibold">${downPayment.toFixed(2)} ({downPaymentPercentage.toFixed(1)}%)</div>
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Total Loan Payments</div>
                      <div className="text-xl font-semibold">${results.totalPayment.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Total Interest</div>
                      <div className="text-xl font-semibold">${results.totalInterest.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Payment Breakdown</h3>
                    <div className="text-sm text-gray-600">
                      <div className="flex justify-between mb-1">
                        <span>Principal + Interest:</span>
                        <span>${results.monthlyPayment.toFixed(2)}/month</span>
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        This calculation does not include property taxes, home insurance, or HOA fees.
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 text-gray-500">
                  Enter your mortgage details to see the results here.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Mortgage Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our mortgage calculator uses the standard amortization formula to calculate your monthly mortgage payments:
                </p>
                <div className="bg-gray-50 p-4 rounded font-mono text-sm">
                  M = P × (r × (1 + r)^n) / ((1 + r)^n - 1)
                </div>
                <p>Where:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>M</strong> = Monthly payment</li>
                  <li><strong>P</strong> = Principal (loan amount)</li>
                  <li><strong>r</strong> = Monthly interest rate (annual rate divided by 12)</li>
                  <li><strong>n</strong> = Total number of payments (years × 12)</li>
                </ul>
                <p className="text-gray-500">Note: This calculator provides estimates only and does not include property taxes, home insurance, or HOA fees.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default MortgageCalculator;
