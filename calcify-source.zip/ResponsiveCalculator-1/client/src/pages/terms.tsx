import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Scale, FileText, AlertTriangle, HelpCircle } from 'lucide-react';
import { Link } from 'wouter';

const Terms: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Scale className="mr-2 h-8 w-8" /> Terms of Service
          </h1>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Terms of Service Agreement</CardTitle>
            <CardDescription>
              Last Updated: May 1, 2025
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Welcome to Calculator Suite. Please read these Terms of Service ("Terms") carefully before using our website 
              operated by Calculator Suite ("us", "we", or "our").
            </p>
            <p>
              Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. 
              These Terms apply to all visitors, users, and others who access or use the Service. By accessing or using the 
              Service, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the Service.
            </p>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-6 w-6" /> Use of Service
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <h3 className="text-lg font-medium">Permissions</h3>
            <p>
              We grant you a non-exclusive, non-transferable, revocable license to access and use our Service 
              strictly in accordance with these Terms.
            </p>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Restrictions</h3>
            <p>You agree not to use the Service:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>In any way that violates any applicable federal, state, local, or international law or regulation</li>
              <li>To impersonate or attempt to impersonate Calculator Suite, a Calculator Suite employee, another user, or any other person or entity</li>
              <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Service</li>
              <li>To cause harm, disrupt, or damage to the Service or servers</li>
              <li>To attempt to gain unauthorized access to any parts of the Service</li>
            </ul>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Intellectual Property</h3>
            <p>
              The Service and its original content, features, and functionality are and will remain the exclusive property of 
              Calculator Suite and its licensors. The Service is protected by copyright, trademark, and other laws of both the 
              United States and foreign countries. Our trademarks and trade dress may not be used in connection with any product 
              or service without the prior written consent of Calculator Suite.
            </p>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="mr-2 h-6 w-6" /> Disclaimer and Limitations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <h3 className="text-lg font-medium">Calculator Accuracy Disclaimer</h3>
            <p>
              The calculators provided on our website are designed for informational and educational purposes only. While we 
              strive to ensure the accuracy of our calculators, we make no representations or warranties of any kind, express 
              or implied, about the completeness, accuracy, reliability, suitability, or availability of the calculators or 
              the information they provide.
            </p>
            <p>
              Users should not rely on the calculators for professional, financial, medical, legal, or other important decisions. 
              Always consult with a qualified professional before making any decision based on the information provided by our calculators.
            </p>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Limitation of Liability</h3>
            <p>
              In no event shall Calculator Suite, nor its directors, employees, partners, agents, suppliers, or affiliates, be 
              liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, 
              loss of profits, data, use, goodwill, or other intangible losses, resulting from:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Your access to or use of or inability to access or use the Service</li>
              <li>Any conduct or content of any third party on the Service</li>
              <li>Any content obtained from the Service</li>
              <li>Unauthorized access, use, or alteration of your transmissions or content</li>
              <li>Reliance on calculations or information provided through our calculators</li>
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <HelpCircle className="mr-2 h-6 w-6" /> Additional Terms
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <h3 className="text-lg font-medium">Changes to Terms</h3>
            <p>
              We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, 
              we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material 
              change will be determined at our sole discretion. By continuing to access or use our Service after those revisions 
              become effective, you agree to be bound by the revised terms.
            </p>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Governing Law</h3>
            <p>
              These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its 
              conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a 
              waiver of those rights.
            </p>
            
            <Separator className="my-4" />
            
            <h3 className="text-lg font-medium">Contact Us</h3>
            <p>
              If you have any questions about these Terms, please contact us at:
            </p>
            <p className="mt-2">
              Email: <span className="text-blue-600">terms@calculatorsuite.example.com</span>
            </p>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default Terms;
