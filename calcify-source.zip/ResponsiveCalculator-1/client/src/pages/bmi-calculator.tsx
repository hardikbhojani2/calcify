import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Scale, Ruler, Heart } from 'lucide-react';
import { Link } from 'wouter';

// Define the BMI form schema
const bmiSchema = z.object({
  system: z.enum(["metric", "imperial"]),
  height: z.coerce.number().positive("Height must be positive"),
  weight: z.coerce.number().positive("Weight must be positive"),
  age: z.coerce.number().int().min(2, "Age must be at least 2").max(120, "Age must be at most 120"),
  gender: z.enum(["male", "female"]),
});

type FormValues = z.infer<typeof bmiSchema>;

const BMICalculator: React.FC = () => {
  const [bmiResult, setBmiResult] = useState<{
    bmi: number;
    category: string;
    color: string;
    healthRisk: string;
    idealWeight: {
      min: number;
      max: number;
    };
  } | null>(null);

  // Initialize the form
  const form = useForm<FormValues>({
    resolver: zodResolver(bmiSchema),
    defaultValues: {
      system: "metric",
      height: 170, // cm
      weight: 70, // kg
      age: 30,
      gender: "male",
    },
  });

  // Watch for system changes to update labels
  const selectedSystem = form.watch("system");

  // Function to calculate BMI
  const calculateBMI = (values: FormValues) => {
    let bmi: number;
    let heightInMeters: number;
    let weightInKg: number;

    if (values.system === "metric") {
      heightInMeters = values.height / 100; // Convert cm to m
      weightInKg = values.weight;
    } else {
      // Convert inches to meters
      heightInMeters = values.height * 0.0254;
      // Convert pounds to kg
      weightInKg = values.weight * 0.453592;
    }

    bmi = weightInKg / (heightInMeters * heightInMeters);
    bmi = parseFloat(bmi.toFixed(1));

    // Determine BMI category
    let category: string;
    let color: string;
    let healthRisk: string;

    if (bmi < 16) {
      category = "Severe Thinness";
      color = "bg-red-500";
      healthRisk = "Very severe health risk";
    } else if (bmi < 17) {
      category = "Moderate Thinness";
      color = "bg-orange-500";
      healthRisk = "High health risk";
    } else if (bmi < 18.5) {
      category = "Mild Thinness";
      color = "bg-yellow-500";
      healthRisk = "Moderate health risk";
    } else if (bmi < 25) {
      category = "Normal";
      color = "bg-green-500";
      healthRisk = "Low health risk";
    } else if (bmi < 30) {
      category = "Overweight";
      color = "bg-yellow-500";
      healthRisk = "Moderate health risk";
    } else if (bmi < 35) {
      category = "Obese Class I";
      color = "bg-orange-500";
      healthRisk = "High health risk";
    } else if (bmi < 40) {
      category = "Obese Class II";
      color = "bg-red-500";
      healthRisk = "Very high health risk";
    } else {
      category = "Obese Class III";
      color = "bg-red-600";
      healthRisk = "Extremely high health risk";
    }

    // Calculate ideal weight range based on BMI between 18.5 and 24.9
    const minIdealBMI = 18.5;
    const maxIdealBMI = 24.9;
    const minWeight = parseFloat((minIdealBMI * heightInMeters * heightInMeters).toFixed(1));
    const maxWeight = parseFloat((maxIdealBMI * heightInMeters * heightInMeters).toFixed(1));

    // Convert back to pounds if using imperial
    const idealWeight = {
      min: values.system === "metric" ? minWeight : parseFloat((minWeight / 0.453592).toFixed(1)),
      max: values.system === "metric" ? maxWeight : parseFloat((maxWeight / 0.453592).toFixed(1)),
    };

    return {
      bmi,
      category,
      color,
      healthRisk,
      idealWeight,
    };
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    const result = calculateBMI(values);
    setBmiResult(result);
  };

  // Function to get BMI category color class
  const getBmiProgressPercentage = (bmi: number) => {
    // Map BMI to a percentage between 0 and 100
    if (bmi < 14) return 5; // Minimum display
    if (bmi > 40) return 95; // Maximum display
    
    // Otherwise map to a range between 5% and 95%
    return ((bmi - 14) / (40 - 14)) * 90 + 5;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Scale className="mr-2 h-8 w-8" /> BMI Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Your BMI</CardTitle>
              <CardDescription>Body Mass Index (BMI) helps to determine if you're at a healthy weight.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="system"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Measurement System</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="metric" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Metric (cm, kg)</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="imperial" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Imperial (in, lbs)</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="height"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Height ({selectedSystem === "metric" ? "cm" : "inches"})</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" />
                          </FormControl>
                          <FormDescription>
                            {selectedSystem === "metric" ? "Centimeters" : "Inches"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="weight"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Weight ({selectedSystem === "metric" ? "kg" : "lbs"})</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" />
                          </FormControl>
                          <FormDescription>
                            {selectedSystem === "metric" ? "Kilograms" : "Pounds"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="age"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Age</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" min="2" max="120" />
                          </FormControl>
                          <FormDescription>
                            Years
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Gender</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full">Calculate BMI</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your BMI Results</CardTitle>
              <CardDescription>
                BMI is an estimate of body fat and a good measure of your risk for diseases.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {bmiResult ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="relative inline-block mx-auto my-4">
                      <div className="text-4xl font-bold">{bmiResult.bmi}</div>
                      <div className={`text-lg font-medium mt-1 ${bmiResult.color.replace('bg-', 'text-')}`}>
                        {bmiResult.category}
                      </div>
                    </div>
                    
                    <div className="my-4">
                      <Progress className="h-3" value={getBmiProgressPercentage(bmiResult.bmi)} />
                      <div className="flex justify-between text-xs mt-1 text-gray-500">
                        <span>Underweight</span>
                        <span>Normal</span>
                        <span>Overweight</span>
                        <span>Obese</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <p className="font-medium flex items-center mb-1">
                        <Heart className="w-4 h-4 mr-1 text-red-500" />
                        Health Risk Assessment
                      </p>
                      <p className="text-sm text-gray-600">{bmiResult.healthRisk}</p>
                    </div>
                    
                    <div>
                      <p className="font-medium flex items-center mb-1">
                        <Ruler className="w-4 h-4 mr-1 text-blue-500" />
                        Ideal Weight Range
                      </p>
                      <p className="text-sm text-gray-600">
                        Based on your height, a healthy weight range would be between{' '}
                        <span className="font-medium">
                          {bmiResult.idealWeight.min}{' '}
                          {selectedSystem === "metric" ? "kg" : "lbs"}
                        </span>{' '}
                        and{' '}
                        <span className="font-medium">
                          {bmiResult.idealWeight.max}{' '}
                          {selectedSystem === "metric" ? "kg" : "lbs"}
                        </span>
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="text-sm text-gray-500 space-y-1">
                    <div className="grid grid-cols-2">
                      <span className="font-medium">Height:</span>
                      <span>
                        {form.getValues().height} {selectedSystem === "metric" ? "cm" : "in"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2">
                      <span className="font-medium">Weight:</span>
                      <span>
                        {form.getValues().weight} {selectedSystem === "metric" ? "kg" : "lbs"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2">
                      <span className="font-medium">Age:</span>
                      <span>{form.getValues().age} years</span>
                    </div>
                    <div className="grid grid-cols-2">
                      <span className="font-medium">Gender:</span>
                      <span className="capitalize">{form.getValues().gender}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
                  <Scale className="h-12 w-12 mb-4 text-gray-400" />
                  <p>Fill out the form and click "Calculate BMI" to see your results.</p>
                  <p className="mt-2 text-sm">
                    Your BMI, weight category, and health recommendations will appear here.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About BMI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                Body Mass Index (BMI) is a numerical value of your weight in relation to your height. 
                It's a commonly used method to categorize whether a person has a healthy body weight for their height.
              </p>
              
              <h3 className="text-lg font-medium text-gray-900">BMI Categories:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li><span className="font-medium">Below 16:</span> Severe Thinness</li>
                <li><span className="font-medium">16 - 17:</span> Moderate Thinness</li>
                <li><span className="font-medium">17 - 18.5:</span> Mild Thinness</li>
                <li><span className="font-medium">18.5 - 25:</span> Normal Weight</li>
                <li><span className="font-medium">25 - 30:</span> Overweight</li>
                <li><span className="font-medium">30 - 35:</span> Obese Class I</li>
                <li><span className="font-medium">35 - 40:</span> Obese Class II</li>
                <li><span className="font-medium">Above 40:</span> Obese Class III</li>
              </ul>
              
              <h3 className="text-lg font-medium text-gray-900">Limitations of BMI:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>BMI doesn't distinguish between weight from muscle and weight from fat.</li>
                <li>Athletes with high muscle mass may have a high BMI but not excess fat.</li>
                <li>It doesn't account for differences in body composition between different populations.</li>
                <li>BMI may not be as accurate for elderly individuals, pregnant women, or children.</li>
              </ul>
              
              <p className="text-gray-500 text-sm">
                <strong>Note:</strong> BMI is a screening tool, not a diagnostic tool. 
                For a comprehensive health assessment, consult with a healthcare professional.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default BMICalculator;
