import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calculator, DollarSign, TrendingUp, Scale, Clock } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for ROI calculator
const roiSchema = z.object({
  initialInvestment: z.coerce.number().nonnegative("Initial investment cannot be negative"),
  finalValue: z.coerce.number().nonnegative("Final value cannot be negative"),
  holdingPeriod: z.coerce.number().positive("Holding period must be positive"),
  periodicCashflows: z.coerce.number(),
});

// Define the form schema for debt-to-income ratio calculator
const dtiSchema = z.object({
  monthlyIncome: z.coerce.number().positive("Monthly income must be positive"),
  housingPayment: z.coerce.number().nonnegative("Housing payment cannot be negative"),
  carPayment: z.coerce.number().nonnegative("Car payment cannot be negative"),
  studentLoanPayment: z.coerce.number().nonnegative("Student loan payment cannot be negative"),
  creditCardPayment: z.coerce.number().nonnegative("Credit card payment cannot be negative"),
  otherDebt: z.coerce.number().nonnegative("Other debt cannot be negative"),
});

// Define the form schema for present/future value calculator
const timeValueSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  rate: z.coerce.number().min(-100, "Rate cannot be less than -100%").max(100, "Rate cannot exceed 100%"),
  years: z.coerce.number().positive("Years must be positive"),
  compoundFrequency: z.coerce.number().int().min(1, "Compound frequency must be 1 or greater"),
  calculationType: z.enum(["present", "future"]),
});

type ROIFormValues = z.infer<typeof roiSchema>;
type DTIFormValues = z.infer<typeof dtiSchema>;
type TimeValueFormValues = z.infer<typeof timeValueSchema>;

const FinanceCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("roi");
  const [roiResult, setRoiResult] = useState<{
    totalROI: number;
    annualizedROI: number;
    totalProfit: number;
    includingCashflows: number;
    steps: string[];
  } | null>(null);
  
  const [dtiResult, setDtiResult] = useState<{
    frontEndRatio: number;
    backEndRatio: number;
    monthlyDebtPayments: number;
    allDebtRatio: number;
    status: "excellent" | "good" | "acceptable" | "high" | "severe";
    steps: string[];
  } | null>(null);
  
  const [timeValueResult, setTimeValueResult] = useState<{
    result: number;
    calculationType: string;
    steps: string[];
  } | null>(null);
  
  // Initialize ROI calculator form
  const roiForm = useForm<ROIFormValues>({
    resolver: zodResolver(roiSchema),
    defaultValues: {
      initialInvestment: 10000,
      finalValue: 15000,
      holdingPeriod: 3,
      periodicCashflows: 0,
    },
  });
  
  // Initialize DTI calculator form
  const dtiForm = useForm<DTIFormValues>({
    resolver: zodResolver(dtiSchema),
    defaultValues: {
      monthlyIncome: 5000,
      housingPayment: 1200,
      carPayment: 350,
      studentLoanPayment: 250,
      creditCardPayment: 200,
      otherDebt: 0,
    },
  });
  
  // Initialize time value of money calculator form
  const timeValueForm = useForm<TimeValueFormValues>({
    resolver: zodResolver(timeValueSchema),
    defaultValues: {
      amount: 1000,
      rate: 5,
      years: 5,
      compoundFrequency: 12,
      calculationType: "future",
    },
  });
  
  // Calculate ROI (Return on Investment)
  const calculateROI = (values: ROIFormValues) => {
    const { initialInvestment, finalValue, holdingPeriod, periodicCashflows } = values;
    const steps: string[] = [];
    
    steps.push(`Initial Investment: $${initialInvestment.toFixed(2)}`);
    steps.push(`Final Value: $${finalValue.toFixed(2)}`);
    steps.push(`Holding Period: ${holdingPeriod} years`);
    steps.push(`Periodic Cashflows: $${periodicCashflows.toFixed(2)}`);
    
    // Calculate total ROI without considering cashflows
    const totalProfit = finalValue - initialInvestment;
    steps.push(`Total Profit: $${finalValue.toFixed(2)} - $${initialInvestment.toFixed(2)} = $${totalProfit.toFixed(2)}`);
    
    // Calculate simple ROI percentage
    const totalROI = (totalProfit / initialInvestment) * 100;
    steps.push(`Total ROI: ($${totalProfit.toFixed(2)} ÷ $${initialInvestment.toFixed(2)}) × 100 = ${totalROI.toFixed(2)}%`);
    
    // Calculate annualized ROI using the CAGR formula
    // CAGR = (Final Value / Initial Value)^(1/n) - 1
    const annualizedROI = (Math.pow(finalValue / initialInvestment, 1 / holdingPeriod) - 1) * 100;
    steps.push(`Annualized ROI (CAGR): [(${finalValue.toFixed(2)} ÷ ${initialInvestment.toFixed(2)})^(1/${holdingPeriod}) - 1] × 100 = ${annualizedROI.toFixed(2)}%`);
    
    // If there are periodic cashflows, include them in a modified ROI calculation
    let includingCashflows = totalROI;
    if (periodicCashflows !== 0) {
      // Calculate total cashflows over the holding period
      const totalCashflows = periodicCashflows * holdingPeriod;
      steps.push(`Total Cashflows: $${periodicCashflows.toFixed(2)} × ${holdingPeriod} years = $${totalCashflows.toFixed(2)}`);
      
      // Adjust the ROI calculation to include these cashflows
      includingCashflows = (totalProfit / (initialInvestment + totalCashflows)) * 100;
      steps.push(`ROI including cashflows: ($${totalProfit.toFixed(2)} ÷ ($${initialInvestment.toFixed(2)} + $${totalCashflows.toFixed(2)})) × 100 = ${includingCashflows.toFixed(2)}%`);
    } else {
      steps.push("No periodic cashflows to include in calculation.");
    }
    
    return {
      totalROI,
      annualizedROI,
      totalProfit,
      includingCashflows,
      steps
    };
  };
  
  // Calculate DTI ratios (Debt-to-Income)
  const calculateDTI = (values: DTIFormValues) => {
    const { monthlyIncome, housingPayment, carPayment, studentLoanPayment, creditCardPayment, otherDebt } = values;
    const steps: string[] = [];
    
    steps.push(`Monthly Income: $${monthlyIncome.toFixed(2)}`);
    steps.push(`Housing Payment: $${housingPayment.toFixed(2)}`);
    steps.push(`Car Payment: $${carPayment.toFixed(2)}`);
    steps.push(`Student Loan Payment: $${studentLoanPayment.toFixed(2)}`);
    steps.push(`Credit Card Payment: $${creditCardPayment.toFixed(2)}`);
    steps.push(`Other Debt: $${otherDebt.toFixed(2)}`);
    
    // Calculate front-end ratio (housing payment to income)
    const frontEndRatio = (housingPayment / monthlyIncome) * 100;
    steps.push(`Front-End Ratio (Housing Only): ($${housingPayment.toFixed(2)} ÷ $${monthlyIncome.toFixed(2)}) × 100 = ${frontEndRatio.toFixed(2)}%`);
    
    // Calculate total monthly debt payments
    const totalDebtPayments = housingPayment + carPayment + studentLoanPayment + creditCardPayment + otherDebt;
    steps.push(`Total Monthly Debt Payments: $${housingPayment.toFixed(2)} + $${carPayment.toFixed(2)} + $${studentLoanPayment.toFixed(2)} + $${creditCardPayment.toFixed(2)} + $${otherDebt.toFixed(2)} = $${totalDebtPayments.toFixed(2)}`);
    
    // Calculate back-end ratio (all debt to income)
    const backEndRatio = (totalDebtPayments / monthlyIncome) * 100;
    steps.push(`Back-End Ratio (All Debt): ($${totalDebtPayments.toFixed(2)} ÷ $${monthlyIncome.toFixed(2)}) × 100 = ${backEndRatio.toFixed(2)}%`);
    
    // Calculate all debt to income ratio (for consistency with front-end and back-end ratios)
    const allDebtRatio = backEndRatio;
    
    // Determine status based on back-end ratio
    let status: "excellent" | "good" | "acceptable" | "high" | "severe";
    if (backEndRatio <= 28) {
      status = "excellent";
      steps.push(`Status: Excellent (DTI ratio <= 28%)`);
    } else if (backEndRatio <= 36) {
      status = "good";
      steps.push(`Status: Good (DTI ratio <= 36%)`);
    } else if (backEndRatio <= 43) {
      status = "acceptable";
      steps.push(`Status: Acceptable (DTI ratio <= 43%)`);
    } else if (backEndRatio <= 50) {
      status = "high";
      steps.push(`Status: High (DTI ratio <= 50%)`);
    } else {
      status = "severe";
      steps.push(`Status: Severe (DTI ratio > 50%)`);
    }
    
    return {
      frontEndRatio,
      backEndRatio,
      monthlyDebtPayments: totalDebtPayments,
      allDebtRatio,
      status,
      steps
    };
  };
  
  // Calculate time value of money (present/future value)
  const calculateTimeValue = (values: TimeValueFormValues) => {
    const { amount, rate, years, compoundFrequency, calculationType } = values;
    const steps: string[] = [];
    
    // Convert rate to decimal
    const rateDecimal = rate / 100;
    
    steps.push(`Amount: $${amount.toFixed(2)}`);
    steps.push(`Interest Rate: ${rate}% (${rateDecimal} as decimal)`);
    steps.push(`Time Period: ${years} years`);
    steps.push(`Compounding Frequency: ${compoundFrequency} times per year`);
    steps.push(`Calculation Type: ${calculationType === "present" ? "Present Value" : "Future Value"}`);
    
    let result: number;
    
    if (calculationType === "future") {
      // Calculate future value: FV = PV * (1 + r/n)^(n*t)
      result = amount * Math.pow(1 + rateDecimal / compoundFrequency, compoundFrequency * years);
      steps.push(`Future Value Formula: FV = PV × (1 + r/n)^(n×t)`);
      steps.push(`Future Value: $${amount.toFixed(2)} × (1 + ${rateDecimal.toFixed(4)} ÷ ${compoundFrequency})^(${compoundFrequency} × ${years}) = $${result.toFixed(2)}`);
    } else {
      // Calculate present value: PV = FV / (1 + r/n)^(n*t)
      result = amount / Math.pow(1 + rateDecimal / compoundFrequency, compoundFrequency * years);
      steps.push(`Present Value Formula: PV = FV ÷ (1 + r/n)^(n×t)`);
      steps.push(`Present Value: $${amount.toFixed(2)} ÷ (1 + ${rateDecimal.toFixed(4)} ÷ ${compoundFrequency})^(${compoundFrequency} × ${years}) = $${result.toFixed(2)}`);
    }
    
    return {
      result,
      calculationType: calculationType === "present" ? "Present Value" : "Future Value",
      steps
    };
  };
  
  // Form submission handlers
  const onROISubmit = (values: ROIFormValues) => {
    try {
      const result = calculateROI(values);
      setRoiResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onDTISubmit = (values: DTIFormValues) => {
    try {
      const result = calculateDTI(values);
      setDtiResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onTimeValueSubmit = (values: TimeValueFormValues) => {
    try {
      const result = calculateTimeValue(values);
      setTimeValueResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  // Helper function to get status color
  const getStatusColor = (status: string): string => {
    switch (status) {
      case "excellent": return "text-green-600";
      case "good": return "text-green-500";
      case "acceptable": return "text-yellow-500";
      case "high": return "text-orange-500";
      case "severe": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Calculator className="mr-2 h-8 w-8" /> Finance Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="roi" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="roi">ROI</TabsTrigger>
                <TabsTrigger value="dti">Debt-to-Income</TabsTrigger>
                <TabsTrigger value="timevalue">Time Value</TabsTrigger>
              </TabsList>
              
              {/* ROI Calculator */}
              <TabsContent value="roi">
                <Card>
                  <CardHeader>
                    <CardTitle>Return on Investment (ROI) Calculator</CardTitle>
                    <CardDescription>
                      Calculate the return on investment for your assets or projects.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...roiForm}>
                      <form onSubmit={roiForm.handleSubmit(onROISubmit)} className="space-y-6">
                        <FormField
                          control={roiForm.control}
                          name="initialInvestment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Initial Investment</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The amount initially invested in the asset or project.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={roiForm.control}
                          name="finalValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Final Value</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The final value of the investment at the end of the holding period.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={roiForm.control}
                            name="holdingPeriod"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Holding Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" min="0.1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={roiForm.control}
                            name="periodicCashflows"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Periodic Cashflows (optional)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  Annual cash outflows or inflows during the investment period.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate ROI</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* DTI Calculator */}
              <TabsContent value="dti">
                <Card>
                  <CardHeader>
                    <CardTitle>Debt-to-Income (DTI) Ratio Calculator</CardTitle>
                    <CardDescription>
                      Calculate your debt-to-income ratio to assess your financial health.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...dtiForm}>
                      <form onSubmit={dtiForm.handleSubmit(onDTISubmit)} className="space-y-6">
                        <FormField
                          control={dtiForm.control}
                          name="monthlyIncome"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Monthly Gross Income</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                Your total monthly income before taxes and other deductions.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Separator className="my-2" />
                        <h3 className="text-sm font-medium">Monthly Debt Payments</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={dtiForm.control}
                            name="housingPayment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Housing Payment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={dtiForm.control}
                            name="carPayment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Car Payment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={dtiForm.control}
                            name="studentLoanPayment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Student Loan Payment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={dtiForm.control}
                            name="creditCardPayment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Credit Card Payment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={dtiForm.control}
                          name="otherDebt"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Other Debt Payments</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate DTI Ratio</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Time Value Calculator */}
              <TabsContent value="timevalue">
                <Card>
                  <CardHeader>
                    <CardTitle>Time Value of Money Calculator</CardTitle>
                    <CardDescription>
                      Calculate the present or future value of money considering time and interest.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...timeValueForm}>
                      <form onSubmit={timeValueForm.handleSubmit(onTimeValueSubmit)} className="space-y-6">
                        <div className="flex flex-col space-y-2">
                          <FormField
                            control={timeValueForm.control}
                            name="calculationType"
                            render={({ field }) => (
                              <FormItem>
                                <div className="flex space-x-4">
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="radio" 
                                      id="future" 
                                      value="future" 
                                      checked={field.value === "future"}
                                      onChange={() => field.onChange("future")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                    <FormLabel htmlFor="future" className="font-normal">Future Value</FormLabel>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="radio" 
                                      id="present" 
                                      value="present" 
                                      checked={field.value === "present"}
                                      onChange={() => field.onChange("present")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                    <FormLabel htmlFor="present" className="font-normal">Present Value</FormLabel>
                                  </div>
                                </div>
                                <FormDescription>
                                  Choose whether to calculate future value from present amount or vice versa.
                                </FormDescription>
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={timeValueForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {timeValueForm.watch("calculationType") === "future" ? "Present Amount" : "Future Amount"}
                              </FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                {timeValueForm.watch("calculationType") === "future" 
                                  ? "The amount you're starting with today." 
                                  : "The amount you expect to have in the future."}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={timeValueForm.control}
                            name="rate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Interest Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={timeValueForm.control}
                            name="years"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" min="0.1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={timeValueForm.control}
                          name="compoundFrequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Compounding Frequency (per year)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="1" />
                              </FormControl>
                              <FormDescription>
                                How many times interest is compounded per year. Use 1 for annual, 4 for quarterly, 12 for monthly, 365 for daily.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate {timeValueForm.watch("calculationType") === "future" ? "Future" : "Present"} Value</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* ROI Results */}
            {activeTab === "roi" && (
              <div className="space-y-6">
                {roiResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Return on Investment Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total ROI</p>
                            <p className="text-2xl font-bold">{roiResult.totalROI.toFixed(2)}%</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Annualized ROI</p>
                            <p className="text-2xl font-bold">{roiResult.annualizedROI.toFixed(2)}%</p>
                            <p className="text-xs text-gray-500">Compound Annual Growth Rate (CAGR)</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Profit</p>
                            <p className="text-2xl font-bold">${roiResult.totalProfit.toFixed(2)}</p>
                          </div>
                          
                          {roiForm.getValues().periodicCashflows !== 0 && (
                            <div className="bg-primary/10 p-4 rounded-lg">
                              <p className="text-sm text-gray-500">ROI with Cashflows</p>
                              <p className="text-2xl font-bold">{roiResult.includingCashflows.toFixed(2)}%</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {roiResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>ROI Calculator Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <TrendingUp className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your investment details and click "Calculate ROI"</p>
                        <p className="text-sm mt-2">Analyze the performance of your investments or projects</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding ROI</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-medium">What is ROI?</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Return on Investment (ROI) measures the profitability of an investment relative to its cost. It's expressed as a percentage and helps 
                        compare the efficiency of different investments or evaluate a single investment's performance.
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium">Total ROI vs. Annualized ROI</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        <strong>Total ROI</strong> shows the overall return for the entire holding period, while <strong>Annualized ROI</strong> (CAGR) normalizes 
                        the return to an annual rate, making it easier to compare investments held for different time periods.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* DTI Results */}
            {activeTab === "dti" && (
              <div className="space-y-6">
                {dtiResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Debt-to-Income Ratio Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Front-End Ratio</p>
                            <p className="text-2xl font-bold">{dtiResult.frontEndRatio.toFixed(2)}%</p>
                            <p className="text-xs text-gray-500">Housing costs to income</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Back-End Ratio</p>
                            <p className="text-2xl font-bold">{dtiResult.backEndRatio.toFixed(2)}%</p>
                            <p className="text-xs text-gray-500">All debt to income</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Monthly Income</p>
                            <p className="text-2xl font-bold">${dtiForm.getValues().monthlyIncome.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Monthly Debt Payments</p>
                            <p className="text-2xl font-bold">${dtiResult.monthlyDebtPayments.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className={`mt-4 p-4 rounded-lg ${getStatusColor(dtiResult.status)} bg-opacity-10 border border-opacity-20 ${getStatusColor(dtiResult.status).replace('text', 'border')}`}>
                          <p className={`font-medium ${getStatusColor(dtiResult.status)}`}>DTI Status: {dtiResult.status.charAt(0).toUpperCase() + dtiResult.status.slice(1)}</p>
                          <p className="text-sm text-gray-600 mt-1">
                            {dtiResult.status === "excellent" && "Your debt-to-income ratio is excellent. You're in a strong financial position with plenty of borrowing capacity."}
                            {dtiResult.status === "good" && "Your debt-to-income ratio is good. You have a healthy balance between debt and income."}
                            {dtiResult.status === "acceptable" && "Your debt-to-income ratio is acceptable but approaching concerning levels. Consider reducing debt if possible."}
                            {dtiResult.status === "high" && "Your debt-to-income ratio is high. You may have difficulty qualifying for new loans. Focus on reducing debt."}
                            {dtiResult.status === "severe" && "Your debt-to-income ratio is severe. You're likely experiencing financial stress. Strongly consider debt reduction strategies."}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {dtiResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>DTI Calculator Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Scale className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your income and debt details and click "Calculate DTI Ratio"</p>
                        <p className="text-sm mt-2">Assess your financial health and borrowing capacity</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding DTI Ratios</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-medium">What is DTI?</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Debt-to-Income (DTI) ratio compares your monthly debt payments to your gross monthly income. It's a key metric lenders use to assess your 
                        ability to manage monthly payments and repay debts.
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium">Front-End vs. Back-End Ratio</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        <strong>Front-End Ratio</strong> only includes housing costs (mortgage/rent, property taxes, insurance). 
                        <strong>Back-End Ratio</strong> includes all debt payments including housing, credit cards, auto loans, and other debt.
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium">DTI Ratio Guidelines</h3>
                      <ul className="space-y-1 text-sm text-gray-600 mt-1">
                        <li><span className="text-green-600 font-medium">Excellent:</span> Below 28%</li>
                        <li><span className="text-green-500 font-medium">Good:</span> 28-36%</li>
                        <li><span className="text-yellow-500 font-medium">Acceptable:</span> 36-43%</li>
                        <li><span className="text-orange-500 font-medium">High:</span> 43-50%</li>
                        <li><span className="text-red-600 font-medium">Severe:</span> Above 50%</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* Time Value Results */}
            {activeTab === "timevalue" && (
              <div className="space-y-6">
                {timeValueResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>{timeValueResult.calculationType} Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">
                              {timeValueForm.getValues().calculationType === "future" ? "Present Value" : "Future Value"}
                            </p>
                            <p className="text-2xl font-bold">${timeValueForm.getValues().amount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">{timeValueResult.calculationType}</p>
                            <p className="text-2xl font-bold">${timeValueResult.result.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Interest Rate</p>
                            <p className="text-2xl font-bold">{timeValueForm.getValues().rate}%</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Time Period</p>
                            <p className="text-2xl font-bold">{timeValueForm.getValues().years} years</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                          <p className="font-medium">What this means:</p>
                          <p className="text-sm text-gray-600 mt-1">
                            {timeValueForm.getValues().calculationType === "future" 
                              ? `$${timeValueForm.getValues().amount.toFixed(2)} today will be worth $${timeValueResult.result.toFixed(2)} in ${timeValueForm.getValues().years} years, given a ${timeValueForm.getValues().rate}% interest rate compounded ${timeValueForm.getValues().compoundFrequency} times per year.`
                              : `To have $${timeValueForm.getValues().amount.toFixed(2)} in ${timeValueForm.getValues().years} years, you need $${timeValueResult.result.toFixed(2)} today, assuming a ${timeValueForm.getValues().rate}% interest rate compounded ${timeValueForm.getValues().compoundFrequency} times per year.`
                            }
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {timeValueResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Time Value Calculator Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Clock className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and calculate the time value of money</p>
                        <p className="text-sm mt-2">See how money changes value over time with compound interest</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Time Value of Money</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-medium">The Concept</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        The time value of money is the principle that a sum of money is worth more now than the same sum will be in the future due to its 
                        earnings potential. This is a core principle in finance theory.
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium">Present Value vs. Future Value</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        <strong>Present Value (PV)</strong> is what a future sum of money is worth today. 
                        <strong>Future Value (FV)</strong> is what a current sum of money will be worth at a specified future date.
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium">The Power of Compounding</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Higher compounding frequency (e.g., monthly instead of annually) leads to greater future value. 
                        This is because interest is earned on both the principal and the accumulated interest, accelerating growth over time.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default FinanceCalculator;
