import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, GraduationCap, Plus, Book } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for course grades
const courseGradesSchema = z.object({
  courses: z.array(
    z.object({
      name: z.string().min(1, "Course name is required"),
      grade: z.coerce.number().min(0, "Grade must be at least 0").max(100, "Grade cannot exceed 100"),
      credits: z.coerce.number().min(0, "Credits must be positive"),
    })
  ),
});

// Define the form schema for final grade calculator
const finalGradeSchema = z.object({
  currentGrade: z.coerce.number().min(0, "Current grade must be at least 0").max(100, "Current grade cannot exceed 100"),
  currentWeight: z.coerce.number().min(0, "Current weight must be positive").max(100, "Weight cannot exceed 100"),
  desiredGrade: z.coerce.number().min(0, "Desired grade must be at least 0").max(100, "Desired grade cannot exceed 100"),
  finalWeight: z.coerce.number().min(0, "Final weight must be positive").max(100, "Weight cannot exceed 100"),
});

// Define the form schema for grade distribution (weighted calculation)
const weightedGradeSchema = z.object({
  categories: z.array(
    z.object({
      name: z.string().min(1, "Category name is required"),
      weight: z.coerce.number().min(0, "Weight must be at least 0").max(100, "Weight cannot exceed 100"),
      score: z.coerce.number().min(0, "Score must be at least 0").max(100, "Score cannot exceed 100"),
    })
  ),
});

type CourseGradesFormValues = z.infer<typeof courseGradesSchema>;
type FinalGradeFormValues = z.infer<typeof finalGradeSchema>;
type WeightedGradeFormValues = z.infer<typeof weightedGradeSchema>;
type Course = CourseGradesFormValues['courses'][0];
type Category = WeightedGradeFormValues['categories'][0];

const GradeCalculator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("gpa");
  
  const [gpaResults, setGpaResults] = useState<{
    totalCredits: number;
    gpa: number;
    letterGrades: { [key: string]: string };
    courseGPAs: { [key: string]: number };
  } | null>(null);
  
  const [finalGradeResults, setFinalGradeResults] = useState<{
    requiredGrade: number;
    isPossible: boolean;
  } | null>(null);
  
  const [weightedGradeResults, setWeightedGradeResults] = useState<{
    finalGrade: number;
    letterGrade: string;
    weightSum: number;
  } | null>(null);

  // Initialize form for GPA calculator with default courses
  const defaultCourses: Course[] = [
    { name: "Math", grade: 90, credits: 3 },
    { name: "Science", grade: 85, credits: 4 },
    { name: "English", grade: 88, credits: 3 },
  ];
  
  const gpaForm = useForm<CourseGradesFormValues>({
    resolver: zodResolver(courseGradesSchema),
    defaultValues: {
      courses: defaultCourses,
    },
  });
  
  // Initialize form for final grade calculator
  const finalGradeForm = useForm<FinalGradeFormValues>({
    resolver: zodResolver(finalGradeSchema),
    defaultValues: {
      currentGrade: 85,
      currentWeight: 70,
      desiredGrade: 90,
      finalWeight: 30,
    },
  });
  
  // Initialize form for weighted grade calculator with default categories
  const defaultCategories: Category[] = [
    { name: "Quizzes", weight: 15, score: 85 },
    { name: "Homework", weight: 25, score: 90 },
    { name: "Midterm", weight: 25, score: 82 },
    { name: "Final Exam", weight: 35, score: 88 },
  ];
  
  const weightedGradeForm = useForm<WeightedGradeFormValues>({
    resolver: zodResolver(weightedGradeSchema),
    defaultValues: {
      categories: defaultCategories,
    },
  });

  // Function to convert grade to 4.0 scale
  const getGradePoints = (grade: number): number => {
    if (grade >= 97) return 4.0;       // A+
    else if (grade >= 93) return 4.0;  // A
    else if (grade >= 90) return 3.7;  // A-
    else if (grade >= 87) return 3.3;  // B+
    else if (grade >= 83) return 3.0;  // B
    else if (grade >= 80) return 2.7;  // B-
    else if (grade >= 77) return 2.3;  // C+
    else if (grade >= 73) return 2.0;  // C
    else if (grade >= 70) return 1.7;  // C-
    else if (grade >= 67) return 1.3;  // D+
    else if (grade >= 63) return 1.0;  // D
    else if (grade >= 60) return 0.7;  // D-
    else return 0.0;                   // F
  };
  
  // Function to convert grade to letter grade
  const getLetterGrade = (grade: number): string => {
    if (grade >= 97) return "A+";
    else if (grade >= 93) return "A";
    else if (grade >= 90) return "A-";
    else if (grade >= 87) return "B+";
    else if (grade >= 83) return "B";
    else if (grade >= 80) return "B-";
    else if (grade >= 77) return "C+";
    else if (grade >= 73) return "C";
    else if (grade >= 70) return "C-";
    else if (grade >= 67) return "D+";
    else if (grade >= 63) return "D";
    else if (grade >= 60) return "D-";
    else return "F";
  };
  
  // Function to calculate GPA
  const calculateGPA = (values: CourseGradesFormValues) => {
    let totalCredits = 0;
    let totalGradePoints = 0;
    const letterGrades: { [key: string]: string } = {};
    const courseGPAs: { [key: string]: number } = {};
    
    values.courses.forEach(course => {
      const credits = course.credits;
      const gradePoints = getGradePoints(course.grade);
      
      totalCredits += credits;
      totalGradePoints += credits * gradePoints;
      
      letterGrades[course.name] = getLetterGrade(course.grade);
      courseGPAs[course.name] = gradePoints;
    });
    
    const gpa = totalCredits > 0 ? totalGradePoints / totalCredits : 0;
    
    return {
      totalCredits,
      gpa,
      letterGrades,
      courseGPAs
    };
  };
  
  // Function to calculate required final grade
  const calculateFinalGrade = (values: FinalGradeFormValues) => {
    const { currentGrade, currentWeight, desiredGrade, finalWeight } = values;
    
    // Check if weights sum to 100%
    if (currentWeight + finalWeight !== 100) {
      throw new Error("Current weight and final weight must sum to 100%");
    }
    
    // Calculate required grade on final
    // Formula: requiredGrade = (desiredGrade - (currentGrade * currentWeight / 100)) / (finalWeight / 100)
    const requiredGrade = (desiredGrade - (currentGrade * currentWeight / 100)) / (finalWeight / 100);
    
    // Check if it's possible to achieve the desired grade
    const isPossible = requiredGrade <= 100;
    
    return {
      requiredGrade: Math.max(0, requiredGrade), // Ensure it's not negative
      isPossible
    };
  };
  
  // Function to calculate weighted grade
  const calculateWeightedGrade = (values: WeightedGradeFormValues) => {
    let finalGrade = 0;
    let weightSum = 0;
    
    values.categories.forEach(category => {
      finalGrade += (category.score * category.weight / 100);
      weightSum += category.weight;
    });
    
    // Check if weights sum to 100%
    if (Math.abs(weightSum - 100) > 0.1) { // Allow small rounding errors
      throw new Error(`Category weights sum to ${weightSum}%, not 100%`);
    }
    
    return {
      finalGrade,
      letterGrade: getLetterGrade(finalGrade),
      weightSum
    };
  };

  // Update GPA results when form values change
  React.useEffect(() => {
    if (gpaForm.formState.isValid && activeTab === "gpa") {
      const currentValues = gpaForm.getValues();
      try {
        const results = calculateGPA(currentValues);
        setGpaResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [gpaForm, activeTab]);
  
  // Update final grade results when form values change
  React.useEffect(() => {
    if (finalGradeForm.formState.isValid && activeTab === "final-grade") {
      const currentValues = finalGradeForm.getValues();
      try {
        const results = calculateFinalGrade(currentValues);
        setFinalGradeResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    finalGradeForm.watch('currentGrade'),
    finalGradeForm.watch('currentWeight'),
    finalGradeForm.watch('desiredGrade'),
    finalGradeForm.watch('finalWeight'),
    finalGradeForm,
    activeTab
  ]);
  
  // Update weighted grade results when form values change
  React.useEffect(() => {
    if (weightedGradeForm.formState.isValid && activeTab === "weighted-grade") {
      const currentValues = weightedGradeForm.getValues();
      try {
        const results = calculateWeightedGrade(currentValues);
        setWeightedGradeResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [weightedGradeForm, activeTab]);

  // Form submission handlers
  const onGPASubmit = (values: CourseGradesFormValues) => {
    try {
      const results = calculateGPA(values);
      setGpaResults(results);
      toast({
        title: 'GPA calculated',
        description: 'Your GPA has been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating your GPA.',
        variant: 'destructive',
      });
    }
  };
  
  const onFinalGradeSubmit = (values: FinalGradeFormValues) => {
    try {
      const results = calculateFinalGrade(values);
      setFinalGradeResults(results);
      toast({
        title: 'Final grade calculated',
        description: 'Your required final grade has been calculated successfully.',
      });
    } catch (error) {
      let errorMessage = 'There was an error calculating your required final grade.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Calculation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };
  
  const onWeightedGradeSubmit = (values: WeightedGradeFormValues) => {
    try {
      const results = calculateWeightedGrade(values);
      setWeightedGradeResults(results);
      toast({
        title: 'Weighted grade calculated',
        description: 'Your weighted grade has been calculated successfully.',
      });
    } catch (error) {
      let errorMessage = 'There was an error calculating your weighted grade.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Calculation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };
  
  // Functions to add or remove courses and categories
  const addCourse = () => {
    const currentCourses = gpaForm.getValues().courses;
    gpaForm.setValue('courses', [
      ...currentCourses,
      { name: "", grade: 85, credits: 3 }
    ]);
  };
  
  const removeCourse = (index: number) => {
    const currentCourses = gpaForm.getValues().courses;
    if (currentCourses.length > 1) {
      const newCourses = [...currentCourses];
      newCourses.splice(index, 1);
      gpaForm.setValue('courses', newCourses);
    } else {
      toast({
        title: 'Cannot Remove Course',
        description: 'You must have at least one course.',
        variant: 'destructive',
      });
    }
  };
  
  const addCategory = () => {
    const currentCategories = weightedGradeForm.getValues().categories;
    weightedGradeForm.setValue('categories', [
      ...currentCategories,
      { name: "", weight: 0, score: 85 }
    ]);
  };
  
  const removeCategory = (index: number) => {
    const currentCategories = weightedGradeForm.getValues().categories;
    if (currentCategories.length > 1) {
      const newCategories = [...currentCategories];
      newCategories.splice(index, 1);
      weightedGradeForm.setValue('categories', newCategories);
    } else {
      toast({
        title: 'Cannot Remove Category',
        description: 'You must have at least one category.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <GraduationCap className="mr-2 h-8 w-8" /> Grade Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="gpa" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="gpa">GPA Calculator</TabsTrigger>
            <TabsTrigger value="final-grade">Final Grade Calculator</TabsTrigger>
            <TabsTrigger value="weighted-grade">Weighted Grade Calculator</TabsTrigger>
          </TabsList>
          
          {/* GPA Calculator Tab */}
          <TabsContent value="gpa">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Calculate Your GPA</CardTitle>
                  <CardDescription>
                    Enter your courses, grades, and credit hours to calculate your GPA.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...gpaForm}>
                    <form onSubmit={gpaForm.handleSubmit(onGPASubmit)} className="space-y-6">
                      {gpaForm.getValues().courses.map((course, index) => (
                        <div key={index} className="p-4 border rounded-md">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-medium">Course {index + 1}</h3>
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm" 
                              onClick={() => removeCourse(index)}
                            >
                              Remove
                            </Button>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-4">
                            <FormField
                              control={gpaForm.control}
                              name={`courses.${index}.name`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Course Name</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Book className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                                      <Input {...field} className="pl-10" />
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={gpaForm.control}
                                name={`courses.${index}.grade`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Grade (%)</FormLabel>
                                    <FormControl>
                                      <Input 
                                        {...field} 
                                        type="number" 
                                        min="0" 
                                        max="100" 
                                        step="0.1" 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={gpaForm.control}
                                name={`courses.${index}.credits`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Credit Hours</FormLabel>
                                    <FormControl>
                                      <Input 
                                        {...field} 
                                        type="number" 
                                        min="0" 
                                        step="0.5" 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <div className="flex gap-4">
                        <Button type="button" variant="outline" onClick={addCourse} className="w-1/2">
                          Add Course
                        </Button>
                        <Button type="submit" className="w-1/2">Calculate GPA</Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>GPA Results</CardTitle>
                  <CardDescription>
                    Your calculated GPA and course breakdown.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {gpaResults ? (
                    <div className="space-y-6">
                      <div className="text-center p-6 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500">Your GPA</div>
                        <div className="text-5xl font-bold text-primary">
                          {gpaResults.gpa.toFixed(2)}
                        </div>
                        <div className="text-sm mt-2 text-gray-500">
                          on a 4.0 scale
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="text-lg font-medium mb-3">Course Breakdown</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2">Course</th>
                                <th className="text-center py-2">Grade (%)</th>
                                <th className="text-center py-2">Letter</th>
                                <th className="text-center py-2">Grade Points</th>
                                <th className="text-center py-2">Credits</th>
                              </tr>
                            </thead>
                            <tbody>
                              {gpaForm.getValues().courses.map((course, index) => (
                                <tr key={index} className="border-b">
                                  <td className="py-2">{course.name}</td>
                                  <td className="text-center">{course.grade.toFixed(1)}%</td>
                                  <td className="text-center">{gpaResults.letterGrades[course.name]}</td>
                                  <td className="text-center">{gpaResults.courseGPAs[course.name].toFixed(1)}</td>
                                  <td className="text-center">{course.credits}</td>
                                </tr>
                              ))}
                              <tr className="font-semibold bg-gray-50">
                                <td className="py-2" colSpan={4}>Total Credits:</td>
                                <td className="text-center">{gpaResults.totalCredits}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h3 className="font-medium text-blue-800 mb-2">GPA Scale</h3>
                        <div className="text-sm text-gray-600 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                          <div>A+ (97-100): 4.0</div>
                          <div>A (93-96): 4.0</div>
                          <div>A- (90-92): 3.7</div>
                          <div>B+ (87-89): 3.3</div>
                          <div>B (83-86): 3.0</div>
                          <div>B- (80-82): 2.7</div>
                          <div>C+ (77-79): 2.3</div>
                          <div>C (73-76): 2.0</div>
                          <div>C- (70-72): 1.7</div>
                          <div>D+ (67-69): 1.3</div>
                          <div>D (63-66): 1.0</div>
                          <div>D- (60-62): 0.7</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-8 text-gray-500">
                      Enter your courses to calculate your GPA.
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Final Grade Calculator Tab */}
          <TabsContent value="final-grade" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Required Final Grade</CardTitle>
                <CardDescription>
                  Calculate what grade you need on your final exam to achieve your desired overall grade.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...finalGradeForm}>
                  <form onSubmit={finalGradeForm.handleSubmit(onFinalGradeSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={finalGradeForm.control}
                        name="currentGrade"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Grade (%)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="0" 
                                max="100" 
                                step="0.1" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={finalGradeForm.control}
                        name="currentWeight"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Weight (%)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="0" 
                                max="100" 
                                step="1" 
                              />
                            </FormControl>
                            <FormMessage />
                            <FormDescription>
                              Percentage of your grade so far
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={finalGradeForm.control}
                        name="desiredGrade"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Desired Final Grade (%)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="0" 
                                max="100" 
                                step="0.1" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={finalGradeForm.control}
                        name="finalWeight"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Final Exam Weight (%)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="0" 
                                max="100" 
                                step="1" 
                              />
                            </FormControl>
                            <FormMessage />
                            <FormDescription>
                              Percentage of your total grade
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate Required Grade</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Final Grade Requirements</CardTitle>
                <CardDescription>
                  What you need to score on your final exam.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {finalGradeResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Required Grade on Final</div>
                      <div className="text-5xl font-bold text-primary">
                        {finalGradeResults.requiredGrade > 100 ? "100+" : finalGradeResults.requiredGrade.toFixed(1)}%
                      </div>
                      {!finalGradeResults.isPossible && (
                        <div className="mt-2 text-red-500 font-medium">
                          Not mathematically possible
                        </div>
                      )}
                    </div>

                    <Separator />

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Current Grade</div>
                        <div className="text-xl font-semibold">{finalGradeForm.getValues().currentGrade}%</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Desired Grade</div>
                        <div className="text-xl font-semibold">{finalGradeForm.getValues().desiredGrade}%</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Current Weight</div>
                        <div className="text-xl font-semibold">{finalGradeForm.getValues().currentWeight}%</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Final Exam Weight</div>
                        <div className="text-xl font-semibold">{finalGradeForm.getValues().finalWeight}%</div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">What This Means</h3>
                      <div className="text-sm text-gray-600">
                        {finalGradeResults.isPossible ? (
                          <p>
                            To achieve a final grade of {finalGradeForm.getValues().desiredGrade}%, 
                            you need to score at least {finalGradeResults.requiredGrade.toFixed(1)}% 
                            on your final exam.
                          </p>
                        ) : (
                          <p>
                            Unfortunately, it's not mathematically possible to achieve a final grade of 
                            {finalGradeForm.getValues().desiredGrade}% with your current grade of 
                            {finalGradeForm.getValues().currentGrade}% and the given weights. 
                            You would need to score above 100% on your final exam.
                          </p>
                        )}
                      </div>
                      <div className="mt-3 text-xs text-gray-500">
                        Note: This calculation assumes the weights sum to 100%.
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter your grades and weights to calculate your required final exam grade.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Weighted Grade Calculator Tab */}
          <TabsContent value="weighted-grade">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Calculate Weighted Grade</CardTitle>
                  <CardDescription>
                    Calculate your final grade by weighting different categories (tests, quizzes, homework, etc.).
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...weightedGradeForm}>
                    <form onSubmit={weightedGradeForm.handleSubmit(onWeightedGradeSubmit)} className="space-y-6">
                      {weightedGradeForm.getValues().categories.map((category, index) => (
                        <div key={index} className="p-4 border rounded-md">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-medium">Category {index + 1}</h3>
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm" 
                              onClick={() => removeCategory(index)}
                            >
                              Remove
                            </Button>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-4">
                            <FormField
                              control={weightedGradeForm.control}
                              name={`categories.${index}.name`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category Name</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={weightedGradeForm.control}
                                name={`categories.${index}.weight`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Weight (%)</FormLabel>
                                    <FormControl>
                                      <Input 
                                        {...field} 
                                        type="number" 
                                        min="0" 
                                        max="100" 
                                        step="1" 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={weightedGradeForm.control}
                                name={`categories.${index}.score`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Score (%)</FormLabel>
                                    <FormControl>
                                      <Input 
                                        {...field} 
                                        type="number" 
                                        min="0" 
                                        max="100" 
                                        step="0.1" 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <div className="flex gap-4">
                        <Button type="button" variant="outline" onClick={addCategory} className="w-1/2">
                          Add Category
                        </Button>
                        <Button type="submit" className="w-1/2">Calculate Grade</Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Weighted Grade Results</CardTitle>
                  <CardDescription>
                    Your calculated weighted final grade.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {weightedGradeResults ? (
                    <div className="space-y-6">
                      <div className="text-center p-6 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500">Final Grade</div>
                        <div className="text-5xl font-bold text-primary">
                          {weightedGradeResults.finalGrade.toFixed(1)}%
                        </div>
                        <div className="text-2xl font-semibold mt-1">
                          {weightedGradeResults.letterGrade}
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="text-lg font-medium mb-3">Category Breakdown</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2">Category</th>
                                <th className="text-center py-2">Weight</th>
                                <th className="text-center py-2">Score</th>
                                <th className="text-right py-2">Contribution</th>
                              </tr>
                            </thead>
                            <tbody>
                              {weightedGradeForm.getValues().categories.map((category, index) => (
                                <tr key={index} className="border-b">
                                  <td className="py-2">{category.name}</td>
                                  <td className="text-center">{category.weight}%</td>
                                  <td className="text-center">{category.score.toFixed(1)}%</td>
                                  <td className="text-right">{(category.weight * category.score / 100).toFixed(1)} points</td>
                                </tr>
                              ))}
                              <tr className="font-semibold bg-gray-50">
                                <td className="py-2" colSpan={2}>Total Weight:</td>
                                <td className="text-center">{weightedGradeResults.weightSum}%</td>
                                <td className="text-right">{weightedGradeResults.finalGrade.toFixed(1)} points</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h3 className="font-medium text-blue-800 mb-2">About Weighted Grading</h3>
                        <div className="text-sm text-gray-600">
                          <p>
                            Your final grade is calculated by multiplying each category's score by its weight, 
                            then summing all of these weighted scores.
                          </p>
                          {Math.abs(weightedGradeResults.weightSum - 100) > 0.1 && (
                            <p className="mt-2 text-amber-600">
                              Warning: Your category weights sum to {weightedGradeResults.weightSum}%, not 100%. 
                              For accurate results, your weights should sum to exactly 100%.
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-8 text-gray-500">
                      Enter your categories, weights, and scores to calculate your weighted grade.
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Grade Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our grade calculator offers three primary functions:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>GPA Calculator</strong>: Calculate your grade point average based on your course grades and credit hours. We use a standard 4.0 scale.</li>
                  <li><strong>Final Grade Calculator</strong>: Determine what score you need on your final exam to achieve your desired overall grade.</li>
                  <li><strong>Weighted Grade Calculator</strong>: Calculate your overall grade when different components (exams, quizzes, etc.) have different weights.</li>
                </ul>
                <p>Key features of our calculator:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Support for multiple courses with varying credit hours</li>
                  <li>Conversion between percentage grades and letter grades</li>
                  <li>Weighted grade calculations for complex grading schemes</li>
                  <li>Goal-setting tools to determine required exam scores</li>
                </ul>
                <p className="text-gray-500">Note: Grade scales may vary by institution. This calculator uses a standard scale but your school might use different grade points or percentage cutoffs.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default GradeCalculator;
