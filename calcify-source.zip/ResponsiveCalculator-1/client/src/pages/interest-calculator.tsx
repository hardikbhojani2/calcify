import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Percent, DollarSign, PiggyBank, CalendarDays, LineChart } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for simple interest
const simpleInterestSchema = z.object({
  principal: z.coerce.number().positive("Principal must be positive"),
  rate: z.coerce.number().min(0, "Rate must be non-negative").max(100, "Rate cannot exceed 100%"),
  time: z.coerce.number().positive("Time must be positive"),
  timeUnit: z.enum(["years", "months", "days"]),
});

// Define the form schema for compound interest
const compoundInterestSchema = z.object({
  principal: z.coerce.number().positive("Principal must be positive"),
  rate: z.coerce.number().min(0, "Rate must be non-negative").max(100, "Rate cannot exceed 100%"),
  time: z.coerce.number().positive("Time must be positive"),
  compoundingFrequency: z.enum(["annually", "semiannually", "quarterly", "monthly", "daily"]),
  contributionAmount: z.coerce.number().min(0, "Contribution amount must be non-negative"),
  contributionFrequency: z.enum(["none", "monthly", "quarterly", "annually"]),
});

// Define the form schema for loan calculation
const loanSchema = z.object({
  loanAmount: z.coerce.number().positive("Loan amount must be positive"),
  rate: z.coerce.number().min(0, "Rate must be non-negative").max(100, "Rate cannot exceed 100%"),
  term: z.coerce.number().positive("Term must be positive"),
  termUnit: z.enum(["years", "months"]),
  paymentFrequency: z.enum(["monthly", "biweekly", "weekly"]),
});

type SimpleInterestFormValues = z.infer<typeof simpleInterestSchema>;
type CompoundInterestFormValues = z.infer<typeof compoundInterestSchema>;
type LoanFormValues = z.infer<typeof loanSchema>;

interface PaymentScheduleItem {
  period: number;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
}

const InterestCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("simple");
  const [simpleResult, setSimpleResult] = useState<{
    interest: number;
    totalAmount: number;
    dailyRate: number;
    steps: string[];
  } | null>(null);
  
  const [compoundResult, setCompoundResult] = useState<{
    interest: number;
    totalAmount: number;
    effectiveRate: number;
    contributionTotal: number;
    yearByYearGrowth: Array<{year: number; principal: number; interest: number; contributions: number; balance: number}>;
    steps: string[];
  } | null>(null);
  
  const [loanResult, setLoanResult] = useState<{
    payment: number;
    totalPayment: number;
    totalInterest: number;
    paymentSchedule: PaymentScheduleItem[];
    steps: string[];
  } | null>(null);
  
  // Initialize simple interest form
  const simpleForm = useForm<SimpleInterestFormValues>({
    resolver: zodResolver(simpleInterestSchema),
    defaultValues: {
      principal: 10000,
      rate: 5,
      time: 3,
      timeUnit: "years",
    },
  });
  
  // Initialize compound interest form
  const compoundForm = useForm<CompoundInterestFormValues>({
    resolver: zodResolver(compoundInterestSchema),
    defaultValues: {
      principal: 10000,
      rate: 7,
      time: 10,
      compoundingFrequency: "annually",
      contributionAmount: 0,
      contributionFrequency: "none",
    },
  });
  
  // Initialize loan payment form
  const loanForm = useForm<LoanFormValues>({
    resolver: zodResolver(loanSchema),
    defaultValues: {
      loanAmount: 30000,
      rate: 4.5,
      term: 5,
      termUnit: "years",
      paymentFrequency: "monthly",
    },
  });
  
  // Calculate simple interest
  const calculateSimpleInterest = (values: SimpleInterestFormValues) => {
    const steps: string[] = [];
    const { principal, rate, time, timeUnit } = values;
    
    // Convert time to years for calculation
    let timeInYears = time;
    if (timeUnit === "months") {
      timeInYears = time / 12;
      steps.push(`Converting ${time} months to years: ${time} / 12 = ${timeInYears.toFixed(4)} years`);
    } else if (timeUnit === "days") {
      timeInYears = time / 365;
      steps.push(`Converting ${time} days to years: ${time} / 365 = ${timeInYears.toFixed(4)} years`);
    } else {
      steps.push(`Time period: ${time} years`);
    }
    
    // Convert rate from percentage to decimal
    const rateDecimal = rate / 100;
    steps.push(`Converting interest rate from percentage to decimal: ${rate}% / 100 = ${rateDecimal}`);
    
    // Calculate daily interest rate
    const dailyRate = rateDecimal / 365;
    steps.push(`Daily interest rate: ${rateDecimal} / 365 = ${dailyRate.toFixed(8)}`);
    
    // Calculate interest using simple interest formula: I = P × r × t
    steps.push(`Principal amount: $${principal.toFixed(2)}`);
    
    // Simple interest formula: I = P × r × t
    const interest = principal * rateDecimal * timeInYears;
    steps.push(`Calculating simple interest: $${principal.toFixed(2)} × ${rateDecimal} × ${timeInYears.toFixed(4)} = $${interest.toFixed(2)}`);
    
    // Calculate total amount: A = P + I
    const totalAmount = principal + interest;
    steps.push(`Calculating total amount: $${principal.toFixed(2)} + $${interest.toFixed(2)} = $${totalAmount.toFixed(2)}`);
    
    return {
      interest,
      totalAmount,
      dailyRate,
      steps
    };
  };
  
  // Calculate compound interest
  const calculateCompoundInterest = (values: CompoundInterestFormValues) => {
    const { principal, rate, time, compoundingFrequency, contributionAmount, contributionFrequency } = values;
    const steps: string[] = [];
    
    // Convert rate from percentage to decimal
    const rateDecimal = rate / 100;
    steps.push(`Converting interest rate from percentage to decimal: ${rate}% / 100 = ${rateDecimal}`);
    
    // Determine number of compounds per year
    let compoundsPerYear: number;
    switch (compoundingFrequency) {
      case "annually":
        compoundsPerYear = 1;
        break;
      case "semiannually":
        compoundsPerYear = 2;
        break;
      case "quarterly":
        compoundsPerYear = 4;
        break;
      case "monthly":
        compoundsPerYear = 12;
        break;
      case "daily":
        compoundsPerYear = 365;
        break;
      default:
        compoundsPerYear = 1;
    }
    steps.push(`Compounding frequency: ${compoundingFrequency} (${compoundsPerYear} times per year)`);
    
    // Determine number of contributions per year
    let contributionsPerYear: number = 0;
    if (contributionFrequency !== "none") {
      switch (contributionFrequency) {
        case "annually":
          contributionsPerYear = 1;
          break;
        case "quarterly":
          contributionsPerYear = 4;
          break;
        case "monthly":
          contributionsPerYear = 12;
          break;
        default:
          contributionsPerYear = 0;
      }
      steps.push(`Contribution frequency: ${contributionFrequency} (${contributionsPerYear} times per year)`);
      steps.push(`Contribution amount: $${contributionAmount.toFixed(2)} per ${contributionFrequency.slice(0, -2)}`);
    } else {
      steps.push("No regular contributions added.");
    }
    
    steps.push(`Principal amount: $${principal.toFixed(2)}`);
    steps.push(`Investment period: ${time} years`);
    
    // Calculate compound interest with contributions
    let yearlyBalances: Array<{year: number; principal: number; interest: number; contributions: number; balance: number}> = [];
    let currentPrincipal = principal;
    let totalContributions = 0;
    
    for (let year = 1; year <= time; year++) {
      let startingPrincipal = currentPrincipal;
      let yearlyContribution = 0;
      
      // If there are contributions, account for them
      if (contributionFrequency !== "none" && contributionsPerYear > 0) {
        // Simplified approach - assuming contributions are made at the end of each period
        yearlyContribution = contributionAmount * contributionsPerYear;
        totalContributions += yearlyContribution;
      }
      
      // Calculate compound interest: A = P(1 + r/n)^(n*t)
      // For a single year with the current principal
      const compoundFactor = Math.pow(1 + rateDecimal / compoundsPerYear, compoundsPerYear);
      const withInterest = currentPrincipal * compoundFactor;
      const yearlyInterest = withInterest - currentPrincipal;
      
      // Add the yearly contribution
      currentPrincipal = withInterest + yearlyContribution;
      
      yearlyBalances.push({
        year, 
        principal: startingPrincipal, 
        interest: yearlyInterest, 
        contributions: yearlyContribution, 
        balance: currentPrincipal
      });
    }
    
    // Final calculations
    const totalAmount = currentPrincipal;
    const interest = totalAmount - principal - totalContributions;
    
    // Calculate effective annual rate
    const effectiveRate = Math.pow(1 + rateDecimal / compoundsPerYear, compoundsPerYear) - 1;
    steps.push(`Effective annual rate: ${(effectiveRate * 100).toFixed(2)}%`);
    
    // Final compound interest formula
    steps.push(`Compound interest formula: A = P(1 + r/n)^(nt) + contributions`);
    steps.push(`Final balance: $${totalAmount.toFixed(2)}`);
    steps.push(`Total interest earned: $${interest.toFixed(2)}`);
    steps.push(`Total contributions: $${totalContributions.toFixed(2)}`);
    
    return {
      interest,
      totalAmount,
      effectiveRate,
      contributionTotal: totalContributions,
      yearByYearGrowth: yearlyBalances,
      steps
    };
  };
  
  // Calculate loan payment
  const calculateLoanPayment = (values: LoanFormValues) => {
    const { loanAmount, rate, term, termUnit, paymentFrequency } = values;
    const steps: string[] = [];
    
    // Convert rate from percentage to decimal
    const rateDecimal = rate / 100;
    steps.push(`Converting interest rate from percentage to decimal: ${rate}% / 100 = ${rateDecimal}`);
    
    // Convert term to months if needed
    let termInMonths = term;
    if (termUnit === "years") {
      termInMonths = term * 12;
      steps.push(`Converting term to months: ${term} years × 12 = ${termInMonths} months`);
    } else {
      steps.push(`Term: ${termInMonths} months`);
    }
    
    // Calculate the number of payments based on frequency
    let paymentsPerYear: number;
    let paymentPeriods: number;
    
    switch (paymentFrequency) {
      case "biweekly":
        paymentsPerYear = 26;
        break;
      case "weekly":
        paymentsPerYear = 52;
        break;
      case "monthly":
      default:
        paymentsPerYear = 12;
    }
    
    paymentPeriods = (termInMonths / 12) * paymentsPerYear;
    steps.push(`Payment frequency: ${paymentFrequency} (${paymentsPerYear} payments per year)`);
    steps.push(`Total number of payments: ${paymentPeriods}`);
    
    // Calculate the periodic interest rate
    const periodicRate = rateDecimal / paymentsPerYear;
    steps.push(`Periodic interest rate: ${rateDecimal} / ${paymentsPerYear} = ${periodicRate.toFixed(6)}`);
    
    // Calculate the payment using the amortization formula
    // Payment = P × (r × (1 + r)^n) / ((1 + r)^n - 1)
    let payment: number;
    
    if (rateDecimal === 0) {
      // If interest rate is 0, payment is simply the loan amount divided by the number of periods
      payment = loanAmount / paymentPeriods;
      steps.push(`Since interest rate is 0, payment = Loan amount / Number of payments = $${loanAmount} / ${paymentPeriods} = $${payment.toFixed(2)}`);
    } else {
      const numerator = periodicRate * Math.pow(1 + periodicRate, paymentPeriods);
      const denominator = Math.pow(1 + periodicRate, paymentPeriods) - 1;
      payment = loanAmount * (numerator / denominator);
      
      steps.push(`Amortization formula: Payment = P × (r × (1 + r)^n) / ((1 + r)^n - 1)`);
      steps.push(`Payment = $${loanAmount.toFixed(2)} × (${periodicRate.toFixed(6)} × (1 + ${periodicRate.toFixed(6)})^${paymentPeriods}) / ((1 + ${periodicRate.toFixed(6)})^${paymentPeriods} - 1)`);
      steps.push(`Payment = $${payment.toFixed(2)}`);
    }
    
    // Calculate the total payment and total interest
    const totalPayment = payment * paymentPeriods;
    const totalInterest = totalPayment - loanAmount;
    
    steps.push(`Total payments: $${payment.toFixed(2)} × ${paymentPeriods} = $${totalPayment.toFixed(2)}`);
    steps.push(`Total interest: $${totalPayment.toFixed(2)} - $${loanAmount.toFixed(2)} = $${totalInterest.toFixed(2)}`);
    
    // Generate amortization schedule (monthly for simplicity)
    const paymentSchedule: PaymentScheduleItem[] = [];
    let balance = loanAmount;
    let monthlyRate = rateDecimal / 12;
    let monthlyPayment: number;
    
    if (paymentFrequency === "monthly") {
      monthlyPayment = payment;
    } else if (paymentFrequency === "biweekly") {
      // Convert bi-weekly to monthly equivalent
      monthlyPayment = payment * 26 / 12;
    } else { // weekly
      // Convert weekly to monthly equivalent
      monthlyPayment = payment * 52 / 12;
    }
    
    for (let period = 1; period <= termInMonths; period++) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      balance = Math.max(0, balance - principalPayment); // Prevent negative balance due to rounding
      
      paymentSchedule.push({
        period,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance
      });
      
      if (balance <= 0) {
        break;
      }
    }
    
    return {
      payment,
      totalPayment,
      totalInterest,
      paymentSchedule,
      steps
    };
  };
  
  // Form submission handlers
  const onSimpleSubmit = (values: SimpleInterestFormValues) => {
    try {
      const result = calculateSimpleInterest(values);
      setSimpleResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onCompoundSubmit = (values: CompoundInterestFormValues) => {
    try {
      const result = calculateCompoundInterest(values);
      setCompoundResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onLoanSubmit = (values: LoanFormValues) => {
    try {
      const result = calculateLoanPayment(values);
      setLoanResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Percent className="mr-2 h-8 w-8" /> Interest Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="simple" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="simple">Simple Interest</TabsTrigger>
                <TabsTrigger value="compound">Compound Interest</TabsTrigger>
                <TabsTrigger value="loan">Loan Payment</TabsTrigger>
              </TabsList>
              
              {/* Simple Interest Calculator */}
              <TabsContent value="simple">
                <Card>
                  <CardHeader>
                    <CardTitle>Simple Interest Calculator</CardTitle>
                    <CardDescription>
                      Calculate the interest earned on a principal amount at a fixed rate over time.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...simpleForm}>
                      <form onSubmit={simpleForm.handleSubmit(onSimpleSubmit)} className="space-y-6">
                        <FormField
                          control={simpleForm.control}
                          name="principal"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Principal Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The initial amount of money.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={simpleForm.control}
                          name="rate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Interest Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.01" min="0" max="100" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormDescription>
                                The annual interest rate as a percentage.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={simpleForm.control}
                            name="time"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time Period</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.01" min="0.01" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={simpleForm.control}
                            name="timeUnit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time Unit</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select time unit" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="years">Years</SelectItem>
                                    <SelectItem value="months">Months</SelectItem>
                                    <SelectItem value="days">Days</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Simple Interest</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Compound Interest Calculator */}
              <TabsContent value="compound">
                <Card>
                  <CardHeader>
                    <CardTitle>Compound Interest Calculator</CardTitle>
                    <CardDescription>
                      Calculate interest on an investment where the interest is reinvested.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...compoundForm}>
                      <form onSubmit={compoundForm.handleSubmit(onCompoundSubmit)} className="space-y-6">
                        <FormField
                          control={compoundForm.control}
                          name="principal"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Principal Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The initial investment amount.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={compoundForm.control}
                            name="rate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Interest Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.01" min="0" max="100" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={compoundForm.control}
                            name="time"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Investment Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="0.1" min="0.1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={compoundForm.control}
                          name="compoundingFrequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Compounding Frequency</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select compounding frequency" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="annually">Annually (1x per year)</SelectItem>
                                  <SelectItem value="semiannually">Semi-annually (2x per year)</SelectItem>
                                  <SelectItem value="quarterly">Quarterly (4x per year)</SelectItem>
                                  <SelectItem value="monthly">Monthly (12x per year)</SelectItem>
                                  <SelectItem value="daily">Daily (365x per year)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                How often the interest is calculated and added to the principal.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={compoundForm.control}
                            name="contributionAmount"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Regular Contribution</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={compoundForm.control}
                            name="contributionFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contribution Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select contribution frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="none">No regular contributions</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Compound Interest</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Loan Payment Calculator */}
              <TabsContent value="loan">
                <Card>
                  <CardHeader>
                    <CardTitle>Loan Payment Calculator</CardTitle>
                    <CardDescription>
                      Calculate loan payments and see your amortization schedule.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...loanForm}>
                      <form onSubmit={loanForm.handleSubmit(onLoanSubmit)} className="space-y-6">
                        <FormField
                          control={loanForm.control}
                          name="loanAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Loan Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loanForm.control}
                          name="rate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Interest Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.01" min="0" max="100" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={loanForm.control}
                            name="term"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Loan Term</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" min="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={loanForm.control}
                            name="termUnit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Term Unit</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select term unit" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="years">Years</SelectItem>
                                    <SelectItem value="months">Months</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={loanForm.control}
                          name="paymentFrequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Payment Frequency</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select payment frequency" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="monthly">Monthly</SelectItem>
                                  <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                  <SelectItem value="weekly">Weekly</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Loan Payment</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* Simple Interest Results */}
            {activeTab === "simple" && (
              <div className="space-y-6">
                {simpleResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Simple Interest Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Principal Amount</p>
                            <p className="text-2xl font-bold">${simpleForm.getValues().principal.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Interest Earned</p>
                            <p className="text-2xl font-bold">${simpleResult.interest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Amount</p>
                            <p className="text-2xl font-bold">${simpleResult.totalAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Daily Interest</p>
                            <p className="text-2xl font-bold">${(simpleResult.dailyRate * simpleForm.getValues().principal).toFixed(2)}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {simpleResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Simple Interest Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <DollarSign className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Simple Interest"</p>
                        <p className="text-sm mt-2">Simple interest is calculated with the formula: I = P × r × t</p>
                        <p className="text-sm mt-1">Where P is principal, r is rate, and t is time in years</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Compound Interest Results */}
            {activeTab === "compound" && (
              <div className="space-y-6">
                {compoundResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Compound Interest Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Initial Investment</p>
                            <p className="text-2xl font-bold">${compoundForm.getValues().principal.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Contributions</p>
                            <p className="text-2xl font-bold">${compoundResult.contributionTotal.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Interest Earned</p>
                            <p className="text-2xl font-bold">${compoundResult.interest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Final Balance</p>
                            <p className="text-2xl font-bold">${compoundResult.totalAmount.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-4">
                          <p className="text-sm font-medium">Effective Annual Rate: {(compoundResult.effectiveRate * 100).toFixed(2)}%</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Growth</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-5 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Starting Balance</div>
                            <div>Interest</div>
                            <div>Contributions</div>
                            <div>Ending Balance</div>
                          </div>
                          
                          {compoundResult.yearByYearGrowth.map((year) => (
                            <div key={year.year} className="grid grid-cols-5 gap-2 p-3 text-xs md:text-sm">
                              <div>{year.year}</div>
                              <div>${year.principal.toFixed(2)}</div>
                              <div>${year.interest.toFixed(2)}</div>
                              <div>${year.contributions.toFixed(2)}</div>
                              <div>${year.balance.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {compoundResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Compound Interest Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <PiggyBank className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Compound Interest"</p>
                        <p className="text-sm mt-2">Compound interest formula: A = P(1 + r/n)^(nt)</p>
                        <p className="text-sm mt-1">Where P is principal, r is rate, n is compounds per year, and t is time</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Loan Payment Results */}
            {activeTab === "loan" && (
              <div className="space-y-6">
                {loanResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Loan Payment Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Loan Amount</p>
                            <p className="text-2xl font-bold">${loanForm.getValues().loanAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">
                              {loanForm.getValues().paymentFrequency === "monthly" ? "Monthly" : 
                               loanForm.getValues().paymentFrequency === "biweekly" ? "Bi-weekly" : 
                               "Weekly"} Payment
                            </p>
                            <p className="text-2xl font-bold">${loanResult.payment.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${loanResult.totalInterest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Payment</p>
                            <p className="text-2xl font-bold">${loanResult.totalPayment.toFixed(2)}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Amortization Schedule</CardTitle>
                        <CardDescription>
                          Monthly payment breakdown for your loan.
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-5 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Month</div>
                            <div>Payment</div>
                            <div>Principal</div>
                            <div>Interest</div>
                            <div>Remaining</div>
                          </div>
                          
                          {loanResult.paymentSchedule.map((period) => (
                            <div key={period.period} className="grid grid-cols-5 gap-2 p-3 text-xs md:text-sm">
                              <div>{period.period}</div>
                              <div>${period.payment.toFixed(2)}</div>
                              <div>${period.principal.toFixed(2)}</div>
                              <div>${period.interest.toFixed(2)}</div>
                              <div>${period.balance.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {loanResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Loan Payment Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <CalendarDays className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your loan details and click "Calculate Loan Payment"</p>
                        <p className="text-sm mt-2">Payment = P × (r × (1 + r)^n) / ((1 + r)^n - 1)</p>
                        <p className="text-sm mt-1">Where P is principal, r is periodic rate, and n is number of payments</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Educational Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Understanding Interest</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Simple vs. Compound Interest</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    <strong>Simple interest</strong> is calculated only on the initial principal, while <strong>compound interest</strong> is calculated on the 
                    principal plus accumulated interest. Compound interest grows exponentially over time, making it powerful for long-term investing.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">The Power of Compounding</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Compounding frequency matters. More frequent compounding (monthly vs. annually) results in more growth. 
                    Regular contributions dramatically increase your returns over time, especially with an early start.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Loan Amortization</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    In the early years of a loan, most of your payment goes toward interest rather than principal. As time passes, 
                    this ratio shifts, with more of each payment reducing the principal. Making extra payments toward principal 
                    can significantly reduce the total interest paid and the loan term.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default InterestCalculator;
