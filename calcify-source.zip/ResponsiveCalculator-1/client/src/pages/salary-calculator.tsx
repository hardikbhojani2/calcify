import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, ArrowRight, DollarSign, Briefcase, Clock, Calendar, Calculator } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for take-home pay calculator
const takeHomeSchema = z.object({
  salary: z.coerce.number().positive("Salary must be positive"),
  payFrequency: z.enum(["hourly", "weekly", "biweekly", "semimonthly", "monthly", "annually"]),
  hoursPerWeek: z.coerce.number().min(1, "Hours per week must be at least 1").max(168, "Hours per week cannot exceed 168").optional(),
  federalTaxRate: z.coerce.number().min(0, "Federal tax rate cannot be negative").max(100, "Federal tax rate cannot exceed 100%"),
  stateTaxRate: z.coerce.number().min(0, "State tax rate cannot be negative").max(100, "State tax rate cannot exceed 100%"),
  medicareTaxRate: z.coerce.number().min(0, "Medicare tax rate cannot be negative").max(100, "Medicare tax rate cannot exceed 100%"),
  socialSecurityRate: z.coerce.number().min(0, "Social security rate cannot be negative").max(100, "Social security rate cannot exceed 100%"),
  otherDeductions: z.coerce.number().min(0, "Other deductions cannot be negative"),
  retirement401k: z.coerce.number().min(0, "401(k) contribution cannot be negative").max(100, "401(k) contribution cannot exceed 100%"),
  healthInsurance: z.coerce.number().min(0, "Health insurance cannot be negative"),
  otherBenefits: z.coerce.number().min(0, "Other benefits cannot be negative"),
});

// Define the form schema for salary conversion calculator
const conversionSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  fromFrequency: z.enum(["hourly", "weekly", "biweekly", "semimonthly", "monthly", "annually"]),
  toFrequency: z.enum(["hourly", "weekly", "biweekly", "semimonthly", "monthly", "annually"]),
  hoursPerWeek: z.coerce.number().min(1, "Hours per week must be at least 1").max(168, "Hours per week cannot exceed 168"),
  weeksPerYear: z.coerce.number().min(1, "Weeks per year must be at least 1").max(52, "Weeks per year cannot exceed 52"),
});

// Define the form schema for hourly to salary calculator
const hourlySchema = z.object({
  hourlyRate: z.coerce.number().positive("Hourly rate must be positive"),
  hoursPerWeek: z.coerce.number().min(1, "Hours per week must be at least 1").max(168, "Hours per week cannot exceed 168"),
  weeksPerYear: z.coerce.number().min(1, "Weeks per year must be at least 1").max(52, "Weeks per year cannot exceed 52"),
  overtime: z.boolean().default(false),
  overtimeRate: z.coerce.number().min(1, "Overtime rate must be at least 1").max(10, "Overtime rate is unusually high").optional(),
  overtimeHours: z.coerce.number().min(0, "Overtime hours cannot be negative").max(168, "Overtime hours cannot exceed 168").optional(),
});

type TakeHomeFormValues = z.infer<typeof takeHomeSchema>;
type ConversionFormValues = z.infer<typeof conversionSchema>;
type HourlyFormValues = z.infer<typeof hourlySchema>;

interface TaxBreakdown {
  federalTax: number;
  stateTax: number;
  medicareTax: number;
  socialSecurity: number;
  retirement401k: number;
  healthInsurance: number;
  otherDeductions: number;
  otherBenefits: number;
  totalDeductions: number;
  takeHomePay: number;
}

const SalaryCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("takehome");
  const [takeHomeResult, setTakeHomeResult] = useState<{
    grossIncome: { annual: number; monthly: number; biweekly: number; weekly: number; hourly: number; };
    netIncome: { annual: number; monthly: number; biweekly: number; weekly: number; hourly: number; };
    taxBreakdown: TaxBreakdown;
    steps: string[];
  } | null>(null);
  
  const [conversionResult, setConversionResult] = useState<{
    originalAmount: number;
    originalFrequency: string;
    convertedAmount: number;
    convertedFrequency: string;
    hourlyEquivalent: number;
    weeklyEquivalent: number;
    biweeklyEquivalent: number;
    monthlyEquivalent: number;
    annualEquivalent: number;
    steps: string[];
  } | null>(null);
  
  const [hourlyResult, setHourlyResult] = useState<{
    hourlyRate: number;
    regularHours: number;
    overtimeHours: number;
    overtimeRate: number;
    weeklyPay: number;
    monthlyPay: number;
    annualPay: number;
    steps: string[];
  } | null>(null);
  
  // Initialize take-home pay calculator form
  const takeHomeForm = useForm<TakeHomeFormValues>({
    resolver: zodResolver(takeHomeSchema),
    defaultValues: {
      salary: 50000,
      payFrequency: "annually",
      hoursPerWeek: 40,
      federalTaxRate: 15,
      stateTaxRate: 5,
      medicareTaxRate: 1.45,
      socialSecurityRate: 6.2,
      otherDeductions: 0,
      retirement401k: 3,
      healthInsurance: 150,
      otherBenefits: 0,
    },
  });
  
  // Watch form values for real-time updates
  const payFrequency = takeHomeForm.watch("payFrequency");
  
  // Initialize salary conversion calculator form
  const conversionForm = useForm<ConversionFormValues>({
    resolver: zodResolver(conversionSchema),
    defaultValues: {
      amount: 25,
      fromFrequency: "hourly",
      toFrequency: "annually",
      hoursPerWeek: 40,
      weeksPerYear: 52,
    },
  });
  
  // Initialize hourly to salary calculator form
  const hourlyForm = useForm<HourlyFormValues>({
    resolver: zodResolver(hourlySchema),
    defaultValues: {
      hourlyRate: 25,
      hoursPerWeek: 40,
      weeksPerYear: 52,
      overtime: false,
      overtimeRate: 1.5,
      overtimeHours: 0,
    },
  });
  
  // Watch form value for real-time updates
  const overtimeChecked = hourlyForm.watch("overtime");
  
  // Calculate take-home pay
  const calculateTakeHome = (values: TakeHomeFormValues) => {
    const steps: string[] = [];
    const { 
      salary, 
      payFrequency, 
      hoursPerWeek = 40, 
      federalTaxRate, 
      stateTaxRate, 
      medicareTaxRate, 
      socialSecurityRate,
      otherDeductions,
      retirement401k,
      healthInsurance,
      otherBenefits
    } = values;
    
    steps.push(`Starting with ${payFrequency} salary/wage of $${salary.toFixed(2)}`);
    
    // Convert to annual salary first
    let annualSalary: number;
    switch (payFrequency) {
      case "hourly":
        annualSalary = salary * hoursPerWeek * 52;
        steps.push(`Converting hourly wage to annual salary: $${salary.toFixed(2)} × ${hoursPerWeek} hours/week × 52 weeks = $${annualSalary.toFixed(2)}`);
        break;
      case "weekly":
        annualSalary = salary * 52;
        steps.push(`Converting weekly salary to annual salary: $${salary.toFixed(2)} × 52 weeks = $${annualSalary.toFixed(2)}`);
        break;
      case "biweekly":
        annualSalary = salary * 26;
        steps.push(`Converting biweekly salary to annual salary: $${salary.toFixed(2)} × 26 pay periods = $${annualSalary.toFixed(2)}`);
        break;
      case "semimonthly":
        annualSalary = salary * 24;
        steps.push(`Converting semi-monthly salary to annual salary: $${salary.toFixed(2)} × 24 pay periods = $${annualSalary.toFixed(2)}`);
        break;
      case "monthly":
        annualSalary = salary * 12;
        steps.push(`Converting monthly salary to annual salary: $${salary.toFixed(2)} × 12 months = $${annualSalary.toFixed(2)}`);
        break;
      case "annually":
      default:
        annualSalary = salary;
        steps.push(`Using annual salary directly: $${annualSalary.toFixed(2)}`);
    }
    
    // Calculate different tax amounts
    const federalTax = annualSalary * (federalTaxRate / 100);
    steps.push(`Federal income tax (${federalTaxRate}%): $${annualSalary.toFixed(2)} × ${federalTaxRate}% = $${federalTax.toFixed(2)}`);
    
    const stateTax = annualSalary * (stateTaxRate / 100);
    steps.push(`State income tax (${stateTaxRate}%): $${annualSalary.toFixed(2)} × ${stateTaxRate}% = $${stateTax.toFixed(2)}`);
    
    const medicareTax = annualSalary * (medicareTaxRate / 100);
    steps.push(`Medicare tax (${medicareTaxRate}%): $${annualSalary.toFixed(2)} × ${medicareTaxRate}% = $${medicareTax.toFixed(2)}`);
    
    const socialSecurity = annualSalary * (socialSecurityRate / 100);
    steps.push(`Social Security tax (${socialSecurityRate}%): $${annualSalary.toFixed(2)} × ${socialSecurityRate}% = $${socialSecurity.toFixed(2)}`);
    
    // Calculate deductions and benefits
    const retirement = annualSalary * (retirement401k / 100);
    steps.push(`401(k) contribution (${retirement401k}%): $${annualSalary.toFixed(2)} × ${retirement401k}% = $${retirement.toFixed(2)}`);
    
    const annualHealthInsurance = healthInsurance * 12; // Assuming monthly health insurance
    steps.push(`Health insurance: $${healthInsurance.toFixed(2)} per month × 12 months = $${annualHealthInsurance.toFixed(2)}`);
    
    const annualOtherDeductions = payFrequency === "monthly" ? otherDeductions * 12 :
                                  payFrequency === "biweekly" ? otherDeductions * 26 :
                                  payFrequency === "weekly" ? otherDeductions * 52 :
                                  payFrequency === "hourly" ? otherDeductions * 52 : otherDeductions;
    steps.push(`Other deductions: $${otherDeductions.toFixed(2)} per ${payFrequency === "annually" ? "year" : payFrequency.includes("month") ? "month" : "pay period"} = $${annualOtherDeductions.toFixed(2)} per year`);
    
    const annualOtherBenefits = payFrequency === "monthly" ? otherBenefits * 12 :
                               payFrequency === "biweekly" ? otherBenefits * 26 :
                               payFrequency === "weekly" ? otherBenefits * 52 :
                               payFrequency === "hourly" ? otherBenefits * 52 : otherBenefits;
    steps.push(`Other benefits: $${otherBenefits.toFixed(2)} per ${payFrequency === "annually" ? "year" : payFrequency.includes("month") ? "month" : "pay period"} = $${annualOtherBenefits.toFixed(2)} per year`);
    
    // Calculate total deductions
    const totalDeductions = federalTax + stateTax + medicareTax + socialSecurity + retirement + annualHealthInsurance + annualOtherDeductions - annualOtherBenefits;
    steps.push(`Total deductions: $${federalTax.toFixed(2)} + $${stateTax.toFixed(2)} + $${medicareTax.toFixed(2)} + $${socialSecurity.toFixed(2)} + $${retirement.toFixed(2)} + $${annualHealthInsurance.toFixed(2)} + $${annualOtherDeductions.toFixed(2)} - $${annualOtherBenefits.toFixed(2)} = $${totalDeductions.toFixed(2)}`);
    
    // Calculate take-home pay (annual)
    const annualTakeHomePay = annualSalary - totalDeductions;
    steps.push(`Annual take-home pay: $${annualSalary.toFixed(2)} - $${totalDeductions.toFixed(2)} = $${annualTakeHomePay.toFixed(2)}`);
    
    // Calculate monthly, biweekly, weekly, and hourly equivalents
    const monthlyGross = annualSalary / 12;
    const biweeklyGross = annualSalary / 26;
    const weeklyGross = annualSalary / 52;
    const hourlyGross = annualSalary / (hoursPerWeek * 52);
    
    const monthlyNet = annualTakeHomePay / 12;
    const biweeklyNet = annualTakeHomePay / 26;
    const weeklyNet = annualTakeHomePay / 52;
    const hourlyNet = annualTakeHomePay / (hoursPerWeek * 52);
    
    steps.push(`Monthly gross income: $${annualSalary.toFixed(2)} ÷ 12 = $${monthlyGross.toFixed(2)}`);
    steps.push(`Biweekly gross income: $${annualSalary.toFixed(2)} ÷ 26 = $${biweeklyGross.toFixed(2)}`);
    steps.push(`Weekly gross income: $${annualSalary.toFixed(2)} ÷ 52 = $${weeklyGross.toFixed(2)}`);
    steps.push(`Hourly gross income: $${annualSalary.toFixed(2)} ÷ (${hoursPerWeek} × 52) = $${hourlyGross.toFixed(2)}`);
    
    steps.push(`Monthly take-home pay: $${annualTakeHomePay.toFixed(2)} ÷ 12 = $${monthlyNet.toFixed(2)}`);
    steps.push(`Biweekly take-home pay: $${annualTakeHomePay.toFixed(2)} ÷ 26 = $${biweeklyNet.toFixed(2)}`);
    steps.push(`Weekly take-home pay: $${annualTakeHomePay.toFixed(2)} ÷ 52 = $${weeklyNet.toFixed(2)}`);
    steps.push(`Hourly take-home pay: $${annualTakeHomePay.toFixed(2)} ÷ (${hoursPerWeek} × 52) = $${hourlyNet.toFixed(2)}`);
    
    // Prepare tax breakdown
    const taxBreakdown: TaxBreakdown = {
      federalTax,
      stateTax,
      medicareTax,
      socialSecurity,
      retirement401k: retirement,
      healthInsurance: annualHealthInsurance,
      otherDeductions: annualOtherDeductions,
      otherBenefits: annualOtherBenefits,
      totalDeductions,
      takeHomePay: annualTakeHomePay
    };
    
    return {
      grossIncome: {
        annual: annualSalary,
        monthly: monthlyGross,
        biweekly: biweeklyGross,
        weekly: weeklyGross,
        hourly: hourlyGross
      },
      netIncome: {
        annual: annualTakeHomePay,
        monthly: monthlyNet,
        biweekly: biweeklyNet,
        weekly: weeklyNet,
        hourly: hourlyNet
      },
      taxBreakdown,
      steps
    };
  };
  
  // Calculate salary conversion
  const calculateConversion = (values: ConversionFormValues) => {
    const { amount, fromFrequency, toFrequency, hoursPerWeek, weeksPerYear } = values;
    const steps: string[] = [];
    
    steps.push(`Starting with ${fromFrequency} amount of $${amount.toFixed(2)}`);
    steps.push(`Converting to ${toFrequency} amount`);
    steps.push(`Using ${hoursPerWeek} hours per week and ${weeksPerYear} weeks per year for calculations`);
    
    // Convert to annual amount first
    let annualAmount: number;
    switch (fromFrequency) {
      case "hourly":
        annualAmount = amount * hoursPerWeek * weeksPerYear;
        steps.push(`Converting hourly to annual: $${amount.toFixed(2)} × ${hoursPerWeek} hours/week × ${weeksPerYear} weeks = $${annualAmount.toFixed(2)}`);
        break;
      case "weekly":
        annualAmount = amount * weeksPerYear;
        steps.push(`Converting weekly to annual: $${amount.toFixed(2)} × ${weeksPerYear} weeks = $${annualAmount.toFixed(2)}`);
        break;
      case "biweekly":
        annualAmount = amount * (weeksPerYear / 2);
        steps.push(`Converting biweekly to annual: $${amount.toFixed(2)} × ${weeksPerYear / 2} pay periods = $${annualAmount.toFixed(2)}`);
        break;
      case "semimonthly":
        annualAmount = amount * 24;
        steps.push(`Converting semi-monthly to annual: $${amount.toFixed(2)} × 24 pay periods = $${annualAmount.toFixed(2)}`);
        break;
      case "monthly":
        annualAmount = amount * 12;
        steps.push(`Converting monthly to annual: $${amount.toFixed(2)} × 12 months = $${annualAmount.toFixed(2)}`);
        break;
      case "annually":
      default:
        annualAmount = amount;
        steps.push(`Using annual amount directly: $${annualAmount.toFixed(2)}`);
    }
    
    // Convert from annual to target frequency
    let convertedAmount: number;
    switch (toFrequency) {
      case "hourly":
        convertedAmount = annualAmount / (hoursPerWeek * weeksPerYear);
        steps.push(`Converting annual to hourly: $${annualAmount.toFixed(2)} ÷ (${hoursPerWeek} hours/week × ${weeksPerYear} weeks) = $${convertedAmount.toFixed(2)}`);
        break;
      case "weekly":
        convertedAmount = annualAmount / weeksPerYear;
        steps.push(`Converting annual to weekly: $${annualAmount.toFixed(2)} ÷ ${weeksPerYear} weeks = $${convertedAmount.toFixed(2)}`);
        break;
      case "biweekly":
        convertedAmount = annualAmount / (weeksPerYear / 2);
        steps.push(`Converting annual to biweekly: $${annualAmount.toFixed(2)} ÷ ${weeksPerYear / 2} pay periods = $${convertedAmount.toFixed(2)}`);
        break;
      case "semimonthly":
        convertedAmount = annualAmount / 24;
        steps.push(`Converting annual to semi-monthly: $${annualAmount.toFixed(2)} ÷ 24 pay periods = $${convertedAmount.toFixed(2)}`);
        break;
      case "monthly":
        convertedAmount = annualAmount / 12;
        steps.push(`Converting annual to monthly: $${annualAmount.toFixed(2)} ÷ 12 months = $${convertedAmount.toFixed(2)}`);
        break;
      case "annually":
      default:
        convertedAmount = annualAmount;
        steps.push(`Keeping annual amount: $${convertedAmount.toFixed(2)}`);
    }
    
    // Calculate all equivalents for comparison
    const hourlyEquivalent = annualAmount / (hoursPerWeek * weeksPerYear);
    const weeklyEquivalent = annualAmount / weeksPerYear;
    const biweeklyEquivalent = annualAmount / (weeksPerYear / 2);
    const monthlyEquivalent = annualAmount / 12;
    const annualEquivalent = annualAmount;
    
    steps.push(`Hourly equivalent: $${hourlyEquivalent.toFixed(2)}`);
    steps.push(`Weekly equivalent: $${weeklyEquivalent.toFixed(2)}`);
    steps.push(`Biweekly equivalent: $${biweeklyEquivalent.toFixed(2)}`);
    steps.push(`Monthly equivalent: $${monthlyEquivalent.toFixed(2)}`);
    steps.push(`Annual equivalent: $${annualEquivalent.toFixed(2)}`);
    
    return {
      originalAmount: amount,
      originalFrequency: fromFrequency,
      convertedAmount,
      convertedFrequency: toFrequency,
      hourlyEquivalent,
      weeklyEquivalent,
      biweeklyEquivalent,
      monthlyEquivalent,
      annualEquivalent,
      steps
    };
  };
  
  // Calculate hourly to salary
  const calculateHourly = (values: HourlyFormValues) => {
    const { hourlyRate, hoursPerWeek, weeksPerYear, overtime, overtimeRate = 1.5, overtimeHours = 0 } = values;
    const steps: string[] = [];
    
    steps.push(`Starting with hourly rate of $${hourlyRate.toFixed(2)}`);
    steps.push(`Working ${hoursPerWeek} regular hours per week`);
    steps.push(`Calculating for ${weeksPerYear} weeks per year`);
    
    // Calculate weekly pay
    const regularHours = overtime ? Math.min(hoursPerWeek, 40) : hoursPerWeek;
    const actualOvertimeHours = overtime ? (hoursPerWeek - 40 > 0 ? hoursPerWeek - 40 : 0) + overtimeHours : 0;
    
    if (overtime) {
      steps.push(`Overtime enabled:`);
      steps.push(`- Regular hours (capped at 40): ${regularHours}`);
      steps.push(`- Overtime hours beyond 40-hour workweek: ${Math.max(0, hoursPerWeek - 40)}`);
      steps.push(`- Additional overtime hours: ${overtimeHours}`);
      steps.push(`- Total overtime hours: ${actualOvertimeHours}`);
      steps.push(`- Overtime pay rate: ${overtimeRate}× regular rate`);
    }
    
    const regularPay = hourlyRate * regularHours;
    const overtimePay = overtime ? hourlyRate * overtimeRate * actualOvertimeHours : 0;
    const weeklyPay = regularPay + overtimePay;
    
    steps.push(`Regular weekly pay: $${hourlyRate.toFixed(2)} × ${regularHours} hours = $${regularPay.toFixed(2)}`);
    if (overtime && actualOvertimeHours > 0) {
      steps.push(`Overtime weekly pay: $${hourlyRate.toFixed(2)} × ${overtimeRate} × ${actualOvertimeHours} hours = $${overtimePay.toFixed(2)}`);
      steps.push(`Total weekly pay: $${regularPay.toFixed(2)} + $${overtimePay.toFixed(2)} = $${weeklyPay.toFixed(2)}`);
    } else {
      steps.push(`Total weekly pay: $${weeklyPay.toFixed(2)}`);
    }
    
    // Calculate monthly and annual pay
    const monthlyPay = weeklyPay * (weeksPerYear / 12);
    const annualPay = weeklyPay * weeksPerYear;
    
    steps.push(`Monthly pay: $${weeklyPay.toFixed(2)} × (${weeksPerYear} weeks ÷ 12 months) = $${monthlyPay.toFixed(2)}`);
    steps.push(`Annual pay: $${weeklyPay.toFixed(2)} × ${weeksPerYear} weeks = $${annualPay.toFixed(2)}`);
    
    return {
      hourlyRate,
      regularHours,
      overtimeHours: actualOvertimeHours,
      overtimeRate,
      weeklyPay,
      monthlyPay,
      annualPay,
      steps
    };
  };
  
  // Form submission handlers
  const onTakeHomeSubmit = (values: TakeHomeFormValues) => {
    try {
      const result = calculateTakeHome(values);
      setTakeHomeResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onConversionSubmit = (values: ConversionFormValues) => {
    try {
      const result = calculateConversion(values);
      setConversionResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onHourlySubmit = (values: HourlyFormValues) => {
    try {
      const result = calculateHourly(values);
      setHourlyResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <DollarSign className="mr-2 h-8 w-8" /> Salary Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="takehome" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="takehome">Take-Home Pay</TabsTrigger>
                <TabsTrigger value="conversion">Salary Conversion</TabsTrigger>
                <TabsTrigger value="hourly">Hourly to Salary</TabsTrigger>
              </TabsList>
              
              {/* Take-Home Pay Calculator */}
              <TabsContent value="takehome">
                <Card>
                  <CardHeader>
                    <CardTitle>Take-Home Pay Calculator</CardTitle>
                    <CardDescription>
                      Calculate your net pay after taxes and deductions.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...takeHomeForm}>
                      <form onSubmit={takeHomeForm.handleSubmit(onTakeHomeSubmit)} className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={takeHomeForm.control}
                            name="salary"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Salary/Wage</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={takeHomeForm.control}
                            name="payFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Pay Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="hourly">Hourly</SelectItem>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                    <SelectItem value="semimonthly">Semi-monthly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {payFrequency === "hourly" && (
                          <FormField
                            control={takeHomeForm.control}
                            name="hoursPerWeek"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Hours per Week</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="168" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                        
                        <div className="bg-slate-50 p-4 rounded-md">
                          <h3 className="text-sm font-medium mb-3">Taxes</h3>
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={takeHomeForm.control}
                              name="federalTaxRate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Federal Tax Rate (%)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                      <span className="absolute right-3 top-3 text-gray-500">%</span>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={takeHomeForm.control}
                              name="stateTaxRate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>State Tax Rate (%)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                      <span className="absolute right-3 top-3 text-gray-500">%</span>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <FormField
                              control={takeHomeForm.control}
                              name="medicareTaxRate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Medicare Tax Rate (%)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.01" min="0" max="100" className="pr-7" />
                                      <span className="absolute right-3 top-3 text-gray-500">%</span>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={takeHomeForm.control}
                              name="socialSecurityRate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Social Security Rate (%)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.01" min="0" max="100" className="pr-7" />
                                      <span className="absolute right-3 top-3 text-gray-500">%</span>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="bg-slate-50 p-4 rounded-md">
                          <h3 className="text-sm font-medium mb-3">Deductions & Benefits</h3>
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={takeHomeForm.control}
                              name="retirement401k"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>401(k) Contribution (%)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                      <span className="absolute right-3 top-3 text-gray-500">%</span>
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={takeHomeForm.control}
                              name="healthInsurance"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Health Insurance ($)</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <span className="absolute left-3 top-3 text-gray-500">$</span>
                                      <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                    </div>
                                  </FormControl>
                                  <FormDescription>Monthly premium</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <FormField
                              control={takeHomeForm.control}
                              name="otherDeductions"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Other Deductions</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <span className="absolute left-3 top-3 text-gray-500">$</span>
                                      <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={takeHomeForm.control}
                              name="otherBenefits"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Other Benefits</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <span className="absolute left-3 top-3 text-gray-500">$</span>
                                      <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Take-Home Pay</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Salary Conversion Calculator */}
              <TabsContent value="conversion">
                <Card>
                  <CardHeader>
                    <CardTitle>Salary Conversion Calculator</CardTitle>
                    <CardDescription>
                      Convert between different salary/wage frequencies.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...conversionForm}>
                      <form onSubmit={conversionForm.handleSubmit(onConversionSubmit)} className="space-y-6">
                        <FormField
                          control={conversionForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={conversionForm.control}
                            name="fromFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>From</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="hourly">Hourly</SelectItem>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                    <SelectItem value="semimonthly">Semi-monthly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={conversionForm.control}
                            name="toFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>To</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="hourly">Hourly</SelectItem>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                    <SelectItem value="semimonthly">Semi-monthly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={conversionForm.control}
                            name="hoursPerWeek"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Hours per Week</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="168" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={conversionForm.control}
                            name="weeksPerYear"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Weeks per Year</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="52" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Convert Salary</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Hourly to Salary Calculator */}
              <TabsContent value="hourly">
                <Card>
                  <CardHeader>
                    <CardTitle>Hourly to Salary Calculator</CardTitle>
                    <CardDescription>
                      Convert hourly wage to equivalent salary with overtime options.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...hourlyForm}>
                      <form onSubmit={hourlyForm.handleSubmit(onHourlySubmit)} className="space-y-6">
                        <FormField
                          control={hourlyForm.control}
                          name="hourlyRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Hourly Rate</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={hourlyForm.control}
                            name="hoursPerWeek"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Hours per Week</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="168" />
                                </FormControl>
                                <FormDescription>
                                  Regular scheduled hours
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={hourlyForm.control}
                            name="weeksPerYear"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Weeks per Year</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" max="52" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={hourlyForm.control}
                          name="overtime"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Include Overtime
                                </FormLabel>
                                <FormDescription>
                                  Calculate with overtime hours and rate
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        {overtimeChecked && (
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={hourlyForm.control}
                              name="overtimeRate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Overtime Rate Multiplier</FormLabel>
                                  <FormControl>
                                    <div className="relative">
                                      <Input {...field} type="number" step="0.1" min="1" max="10" />
                                      <span className="absolute right-3 top-3 text-gray-500">×</span>
                                    </div>
                                  </FormControl>
                                  <FormDescription>
                                    Typically 1.5× regular rate
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={hourlyForm.control}
                              name="overtimeHours"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Additional Overtime Hours</FormLabel>
                                  <FormControl>
                                    <Input {...field} type="number" min="0" max="168" />
                                  </FormControl>
                                  <FormDescription>
                                    Beyond regular hours
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        )}
                        
                        <Button type="submit" className="w-full">Calculate Salary Equivalent</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* Take-Home Pay Results */}
            {activeTab === "takehome" && (
              <div className="space-y-6">
                {takeHomeResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Take-Home Pay Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Gross Annual Salary</p>
                            <p className="text-2xl font-bold">${takeHomeResult.grossIncome.annual.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Net Annual Salary</p>
                            <p className="text-2xl font-bold">${takeHomeResult.netIncome.annual.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <h3 className="text-lg font-medium">Pay Breakdown</h3>
                          <div className="mt-2 grid grid-cols-4 gap-2">
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Monthly</p>
                              <p className="font-medium">${takeHomeResult.netIncome.monthly.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Biweekly</p>
                              <p className="font-medium">${takeHomeResult.netIncome.biweekly.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Weekly</p>
                              <p className="font-medium">${takeHomeResult.netIncome.weekly.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Hourly</p>
                              <p className="font-medium">${takeHomeResult.netIncome.hourly.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <h3 className="text-lg font-medium">Tax & Deduction Breakdown</h3>
                          <div className="mt-4 space-y-3">
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Federal Income Tax:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.federalTax.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">State Income Tax:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.stateTax.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Medicare Tax:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.medicareTax.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Social Security Tax:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.socialSecurity.toFixed(2)}</p>
                            </div>
                            <Separator />
                            <div className="flex justify-between items-center">
                              <p className="text-sm">401(k) Contribution:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.retirement401k.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Health Insurance:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.healthInsurance.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Other Deductions:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.otherDeductions.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm">Other Benefits:</p>
                              <p className="font-medium">${takeHomeResult.taxBreakdown.otherBenefits.toFixed(2)}</p>
                            </div>
                            <Separator />
                            <div className="flex justify-between items-center font-bold">
                              <p>Total Deductions:</p>
                              <p>${takeHomeResult.taxBreakdown.totalDeductions.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-blue-600 h-2.5 rounded-full" style={{ 
                              width: `${(takeHomeResult.netIncome.annual / takeHomeResult.grossIncome.annual) * 100}%` 
                            }}></div>
                          </div>
                          <div className="flex justify-between mt-2 text-sm">
                            <div>
                              <span className="font-medium">Take-Home Pay: </span>
                              <span className="text-blue-600">
                                {((takeHomeResult.netIncome.annual / takeHomeResult.grossIncome.annual) * 100).toFixed(1)}%
                              </span>
                            </div>
                            <div>
                              <span className="font-medium">Total Deductions: </span>
                              <span className="text-gray-500">
                                {((takeHomeResult.taxBreakdown.totalDeductions / takeHomeResult.grossIncome.annual) * 100).toFixed(1)}%
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {takeHomeResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Take-Home Pay Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Briefcase className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your salary information and click "Calculate Take-Home Pay"</p>
                        <p className="text-sm mt-2">See how taxes and deductions affect your paycheck</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Salary Conversion Results */}
            {activeTab === "conversion" && (
              <div className="space-y-6">
                {conversionResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Salary Conversion Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between bg-primary/10 p-4 rounded-lg mb-6">
                          <div className="text-center">
                            <p className="text-sm text-gray-500">
                              {conversionResult.originalFrequency.charAt(0).toUpperCase() + conversionResult.originalFrequency.slice(1)}
                            </p>
                            <p className="text-2xl font-bold">${conversionResult.originalAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="text-4xl text-gray-400">
                            <ArrowRight className="h-6 w-6" />
                          </div>
                          
                          <div className="text-center">
                            <p className="text-sm text-gray-500">
                              {conversionResult.convertedFrequency.charAt(0).toUpperCase() + conversionResult.convertedFrequency.slice(1)}
                            </p>
                            <p className="text-2xl font-bold">${conversionResult.convertedAmount.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <h3 className="text-lg font-medium mb-4">Equivalent Rates</h3>
                          <div className="grid grid-cols-5 gap-2">
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Hourly</p>
                              <p className="font-medium">${conversionResult.hourlyEquivalent.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Weekly</p>
                              <p className="font-medium">${conversionResult.weeklyEquivalent.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Biweekly</p>
                              <p className="font-medium">${conversionResult.biweeklyEquivalent.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Monthly</p>
                              <p className="font-medium">${conversionResult.monthlyEquivalent.toFixed(2)}</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-md text-center">
                              <p className="text-xs text-gray-500">Annual</p>
                              <p className="font-medium">${conversionResult.annualEquivalent.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6 bg-gray-50 p-4 rounded-md">
                          <p className="text-sm">
                            <span className="font-medium">Based on: </span>
                            {conversionForm.getValues().hoursPerWeek} hours per week, {conversionForm.getValues().weeksPerYear} weeks per year
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {conversionResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Salary Conversion Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Calculator className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter an amount and click "Convert Salary"</p>
                        <p className="text-sm mt-2">Convert between hourly, weekly, monthly, and annual rates</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Hourly to Salary Results */}
            {activeTab === "hourly" && (
              <div className="space-y-6">
                {hourlyResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Hourly to Salary Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-3 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Hourly Rate</p>
                            <p className="text-2xl font-bold">${hourlyResult.hourlyRate.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">Per hour</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Weekly Pay</p>
                            <p className="text-2xl font-bold">${hourlyResult.weeklyPay.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">Per week</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Monthly Pay</p>
                            <p className="text-2xl font-bold">${hourlyResult.monthlyPay.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">Per month</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg col-span-3">
                            <p className="text-sm text-gray-500">Annual Salary</p>
                            <p className="text-2xl font-bold">${hourlyResult.annualPay.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">Per year</p>
                          </div>
                        </div>
                        
                        {hourlyForm.getValues().overtime && (
                          <div className="mt-6 bg-gray-50 p-4 rounded-md">
                            <h3 className="text-sm font-medium mb-3">Overtime Breakdown</h3>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm">Regular Hours:</p>
                                <p className="font-medium">{hourlyResult.regularHours} hours @ ${hourlyResult.hourlyRate.toFixed(2)}/hr</p>
                                <p className="text-sm mt-1">Regular Pay:</p>
                                <p className="font-medium">${(hourlyResult.hourlyRate * hourlyResult.regularHours).toFixed(2)}</p>
                              </div>
                              
                              <div>
                                <p className="text-sm">Overtime Hours:</p>
                                <p className="font-medium">{hourlyResult.overtimeHours} hours @ ${(hourlyResult.hourlyRate * hourlyResult.overtimeRate).toFixed(2)}/hr</p>
                                <p className="text-sm mt-1">Overtime Pay:</p>
                                <p className="font-medium">${(hourlyResult.hourlyRate * hourlyResult.overtimeRate * hourlyResult.overtimeHours).toFixed(2)}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {hourlyResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Hourly to Salary Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Clock className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter hourly rate and click "Calculate Salary Equivalent"</p>
                        <p className="text-sm mt-2">Convert hourly wages to weekly, monthly, and annual equivalents</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Educational Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Understanding Salary Calculations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Pay Frequency Conversions</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Different pay frequencies are based on standard time periods:
                  </p>
                  <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-gray-600">
                    <li><strong>Hourly:</strong> Pay per hour worked</li>
                    <li><strong>Weekly:</strong> 52 pay periods per year</li>
                    <li><strong>Bi-weekly:</strong> 26 pay periods per year (every two weeks)</li>
                    <li><strong>Semi-monthly:</strong> 24 pay periods per year (twice a month)</li>
                    <li><strong>Monthly:</strong> 12 pay periods per year</li>
                    <li><strong>Annually:</strong> Total yearly compensation</li>
                  </ul>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Tax Considerations</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Remember that the take-home pay calculator provides an estimate. Actual taxes may vary based on 
                    filing status, deductions, exemptions, and local taxes. The calculator uses flat tax rates rather than 
                    progressive tax brackets for simplicity.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Overtime Rules</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    In many jurisdictions, hours worked beyond 40 hours per week are paid at an overtime rate, typically 1.5 times 
                    the regular hourly rate. Some positions and industries may be exempt from overtime regulations.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default SalaryCalculator;
