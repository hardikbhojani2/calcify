import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calculator, RefreshCw, CalendarDays, Settings, Clipboard } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for installment payment calculator
const installmentSchema = z.object({
  totalAmount: z.coerce.number().positive("Total amount must be positive"),
  numberOfPayments: z.coerce.number().int().positive("Number of payments must be a positive integer"),
  interestRate: z.coerce.number().min(0, "Interest rate cannot be negative").max(100, "Interest rate cannot exceed 100%"),
  paymentFrequency: z.enum(["weekly", "biweekly", "monthly", "quarterly", "annually"]),
  firstPaymentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
});

// Define the form schema for payment schedule
const scheduleSchema = z.object({
  loanAmount: z.coerce.number().positive("Loan amount must be positive"),
  annualInterestRate: z.coerce.number().min(0, "Interest rate cannot be negative").max(100, "Interest rate cannot exceed 100%"),
  loanTerm: z.coerce.number().positive("Loan term must be positive"),
  termUnit: z.enum(["months", "years"]),
  paymentFrequency: z.enum(["weekly", "biweekly", "monthly"]),
  extraPayment: z.coerce.number().min(0, "Extra payment cannot be negative"),
});

// Define the form schema for payment breakdown
const breakdownSchema = z.object({
  paymentAmount: z.coerce.number().positive("Payment amount must be positive"),
  principalAmount: z.coerce.number().positive("Principal amount must be positive"),
  interestRate: z.coerce.number().min(0, "Interest rate cannot be negative").max(100, "Interest rate cannot exceed 100%"),
  additionalFees: z.coerce.number().min(0, "Additional fees cannot be negative"),
  taxRate: z.coerce.number().min(0, "Tax rate cannot be negative").max(100, "Tax rate cannot exceed 100%"),
});

type InstallmentFormValues = z.infer<typeof installmentSchema>;
type ScheduleFormValues = z.infer<typeof scheduleSchema>;
type BreakdownFormValues = z.infer<typeof breakdownSchema>;

interface PaymentItem {
  number: number;
  date: string;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
}

interface PaymentBreakdown {
  principal: number;
  interest: number;
  fees: number;
  taxes: number;
  total: number;
}

const PaymentCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("installment");
  const [installmentResult, setInstallmentResult] = useState<{
    paymentAmount: number;
    totalPayments: number;
    totalInterest: number;
    paymentSchedule: PaymentItem[];
    steps: string[];
  } | null>(null);
  
  const [scheduleResult, setScheduleResult] = useState<{
    monthlyPayment: number;
    totalPayments: number;
    totalInterest: number;
    payoffDate: string;
    paymentSchedule: PaymentItem[];
    comparisonSchedule?: PaymentItem[];
    savings?: number;
    months?: number;
    steps: string[];
  } | null>(null);
  
  const [breakdownResult, setBreakdownResult] = useState<{
    breakdown: PaymentBreakdown;
    allocationChart: { label: string; value: number; percentage: number }[];
    steps: string[];
  } | null>(null);
  
  // Initialize installment payment calculator form
  const installmentForm = useForm<InstallmentFormValues>({
    resolver: zodResolver(installmentSchema),
    defaultValues: {
      totalAmount: 5000,
      numberOfPayments: 12,
      interestRate: 5,
      paymentFrequency: "monthly",
      firstPaymentDate: new Date().toISOString().split('T')[0],
    },
  });
  
  // Initialize payment schedule calculator form
  const scheduleForm = useForm<ScheduleFormValues>({
    resolver: zodResolver(scheduleSchema),
    defaultValues: {
      loanAmount: 200000,
      annualInterestRate: 4.5,
      loanTerm: 30,
      termUnit: "years",
      paymentFrequency: "monthly",
      extraPayment: 0,
    },
  });
  
  // Initialize payment breakdown calculator form
  const breakdownForm = useForm<BreakdownFormValues>({
    resolver: zodResolver(breakdownSchema),
    defaultValues: {
      paymentAmount: 1000,
      principalAmount: 800,
      interestRate: 4,
      additionalFees: 50,
      taxRate: 7,
    },
  });
  
  // Helper function to format dates
  const formatDate = (date: Date): string => {
    return date.toISOString().split('T')[0];
  };
  
  // Helper function to add days, weeks, months, or years to a date
  const addToDate = (date: Date, amount: number, unit: 'days' | 'weeks' | 'months' | 'years'): Date => {
    const newDate = new Date(date);
    
    switch (unit) {
      case 'days':
        newDate.setDate(newDate.getDate() + amount);
        break;
      case 'weeks':
        newDate.setDate(newDate.getDate() + (amount * 7));
        break;
      case 'months':
        newDate.setMonth(newDate.getMonth() + amount);
        break;
      case 'years':
        newDate.setFullYear(newDate.getFullYear() + amount);
        break;
    }
    
    return newDate;
  };
  
  // Calculate installment payment
  const calculateInstallment = (values: InstallmentFormValues) => {
    const { totalAmount, numberOfPayments, interestRate, paymentFrequency, firstPaymentDate } = values;
    const steps: string[] = [];
    
    steps.push(`Total amount: $${totalAmount.toFixed(2)}`);
    steps.push(`Number of payments: ${numberOfPayments}`);
    steps.push(`Interest rate: ${interestRate}%`);
    steps.push(`Payment frequency: ${paymentFrequency}`);
    steps.push(`First payment date: ${firstPaymentDate}`);
    
    // Convert interest rate to periodic rate
    let periodicRate: number;
    if (interestRate === 0) {
      periodicRate = 0;
      steps.push("Interest rate is 0, so periodic rate is also 0.");
    } else {
      const annualRate = interestRate / 100;
      
      // Determine periods per year based on payment frequency
      let periodsPerYear: number;
      switch (paymentFrequency) {
        case "weekly":
          periodsPerYear = 52;
          break;
        case "biweekly":
          periodsPerYear = 26;
          break;
        case "monthly":
          periodsPerYear = 12;
          break;
        case "quarterly":
          periodsPerYear = 4;
          break;
        case "annually":
          periodsPerYear = 1;
          break;
        default:
          periodsPerYear = 12; // Default to monthly
      }
      
      periodicRate = annualRate / periodsPerYear;
      steps.push(`Annual interest rate: ${interestRate}% = ${annualRate} as decimal`);
      steps.push(`Periods per year: ${periodsPerYear} (${paymentFrequency})`);
      steps.push(`Periodic interest rate: ${annualRate} / ${periodsPerYear} = ${periodicRate.toFixed(6)}`);
    }
    
    // Calculate payment amount
    let paymentAmount: number;
    if (periodicRate === 0) {
      // Simple division for zero interest
      paymentAmount = totalAmount / numberOfPayments;
      steps.push(`Payment amount (no interest): $${totalAmount.toFixed(2)} / ${numberOfPayments} = $${paymentAmount.toFixed(2)}`);
    } else {
      // Amortization formula: P = A * [r(1+r)^n] / [(1+r)^n - 1]
      const numerator = periodicRate * Math.pow(1 + periodicRate, numberOfPayments);
      const denominator = Math.pow(1 + periodicRate, numberOfPayments) - 1;
      paymentAmount = totalAmount * (numerator / denominator);
      
      steps.push(`Payment amount (using amortization formula):`);
      steps.push(`P = $${totalAmount.toFixed(2)} * [${periodicRate.toFixed(6)} * (1 + ${periodicRate.toFixed(6)})^${numberOfPayments}] / [(1 + ${periodicRate.toFixed(6)})^${numberOfPayments} - 1]`);
      steps.push(`P = $${paymentAmount.toFixed(2)}`);
    }
    
    // Calculate total payments and interest
    const totalPayments = paymentAmount * numberOfPayments;
    const totalInterest = totalPayments - totalAmount;
    
    steps.push(`Total payments: $${paymentAmount.toFixed(2)} * ${numberOfPayments} = $${totalPayments.toFixed(2)}`);
    steps.push(`Total interest: $${totalPayments.toFixed(2)} - $${totalAmount.toFixed(2)} = $${totalInterest.toFixed(2)}`);
    
    // Generate payment schedule
    const paymentSchedule: PaymentItem[] = [];
    let remainingBalance = totalAmount;
    let currentDate = new Date(firstPaymentDate);
    
    for (let i = 1; i <= numberOfPayments; i++) {
      // Calculate interest for this period
      const interestPayment = remainingBalance * periodicRate;
      // Calculate principal for this period
      const principalPayment = paymentAmount - interestPayment;
      // Update remaining balance
      remainingBalance -= principalPayment;
      
      // Ensure balance doesn't go below zero due to rounding
      if (remainingBalance < 0) {
        remainingBalance = 0;
      }
      
      // Add to payment schedule
      paymentSchedule.push({
        number: i,
        date: formatDate(currentDate),
        payment: paymentAmount,
        principal: principalPayment,
        interest: interestPayment,
        balance: remainingBalance
      });
      
      // Advance date for next payment
      switch (paymentFrequency) {
        case "weekly":
          currentDate = addToDate(currentDate, 1, "weeks");
          break;
        case "biweekly":
          currentDate = addToDate(currentDate, 2, "weeks");
          break;
        case "monthly":
          currentDate = addToDate(currentDate, 1, "months");
          break;
        case "quarterly":
          currentDate = addToDate(currentDate, 3, "months");
          break;
        case "annually":
          currentDate = addToDate(currentDate, 1, "years");
          break;
      }
    }
    
    return {
      paymentAmount,
      totalPayments,
      totalInterest,
      paymentSchedule,
      steps
    };
  };
  
  // Calculate loan payment schedule
  const calculateSchedule = (values: ScheduleFormValues) => {
    const { loanAmount, annualInterestRate, loanTerm, termUnit, paymentFrequency, extraPayment } = values;
    const steps: string[] = [];
    
    steps.push(`Loan amount: $${loanAmount.toFixed(2)}`);
    steps.push(`Annual interest rate: ${annualInterestRate}%`);
    steps.push(`Loan term: ${loanTerm} ${termUnit}`);
    steps.push(`Payment frequency: ${paymentFrequency}`);
    steps.push(`Extra payment: $${extraPayment.toFixed(2)}`);
    
    // Convert interest rate to decimal
    const annualRateDecimal = annualInterestRate / 100;
    steps.push(`Annual interest rate in decimal: ${annualRateDecimal}`);
    
    // Determine number of payments based on term and frequency
    let totalPaymentCount: number;
    let periodsPerYear: number;
    
    switch (paymentFrequency) {
      case "weekly":
        periodsPerYear = 52;
        break;
      case "biweekly":
        periodsPerYear = 26;
        break;
      case "monthly":
      default:
        periodsPerYear = 12;
    }
    
    if (termUnit === "years") {
      totalPaymentCount = loanTerm * periodsPerYear;
      steps.push(`Total number of payments: ${loanTerm} years * ${periodsPerYear} payments/year = ${totalPaymentCount}`);
    } else { // months
      totalPaymentCount = loanTerm;
      steps.push(`Total number of payments: ${totalPaymentCount}`);
    }
    
    // Calculate periodic interest rate
    const periodicRate = annualRateDecimal / periodsPerYear;
    steps.push(`Periodic interest rate: ${annualRateDecimal} / ${periodsPerYear} = ${periodicRate.toFixed(6)}`);
    
    // Calculate regular payment amount using amortization formula
    let regularPaymentAmount: number;
    if (periodicRate === 0) {
      regularPaymentAmount = loanAmount / totalPaymentCount;
      steps.push(`Regular payment amount (no interest): $${loanAmount.toFixed(2)} / ${totalPaymentCount} = $${regularPaymentAmount.toFixed(2)}`);
    } else {
      const numerator = periodicRate * Math.pow(1 + periodicRate, totalPaymentCount);
      const denominator = Math.pow(1 + periodicRate, totalPaymentCount) - 1;
      regularPaymentAmount = loanAmount * (numerator / denominator);
      
      steps.push(`Regular payment amount (using amortization formula): $${regularPaymentAmount.toFixed(2)}`);
    }
    
    // Generate payment schedule without extra payment
    const regularSchedule: PaymentItem[] = [];
    let regularBalance = loanAmount;
    let regularPaymentCount = 0;
    const currentDate = new Date();
    let regularPayoffDate = new Date();
    
    for (let i = 1; regularBalance > 0 && i <= totalPaymentCount; i++) {
      // Calculate interest for this period
      const interestPayment = regularBalance * periodicRate;
      // Calculate principal for this period
      const principalPayment = Math.min(regularPaymentAmount - interestPayment, regularBalance);
      // Update remaining balance
      regularBalance -= principalPayment;
      regularPaymentCount++;
      
      if (i === totalPaymentCount) {
        // Store the regular payoff date
        switch (paymentFrequency) {
          case "weekly":
            regularPayoffDate = addToDate(currentDate, i, "weeks");
            break;
          case "biweekly":
            regularPayoffDate = addToDate(currentDate, i * 2, "weeks");
            break;
          case "monthly":
            regularPayoffDate = addToDate(currentDate, i, "months");
            break;
        }
      }
    }
    
    // Calculate total payments without extra payment
    const regularTotalPayments = regularPaymentAmount * regularPaymentCount;
    const regularTotalInterest = regularTotalPayments - loanAmount;
    
    steps.push(`Regular total payments: $${regularPaymentAmount.toFixed(2)} * ${regularPaymentCount} = $${regularTotalPayments.toFixed(2)}`);
    steps.push(`Regular total interest: $${regularTotalPayments.toFixed(2)} - $${loanAmount.toFixed(2)} = $${regularTotalInterest.toFixed(2)}`);
    
    // Generate payment schedule with extra payment
    const paymentSchedule: PaymentItem[] = [];
    let remainingBalance = loanAmount;
    let paymentCount = 0;
    let payoffDate = new Date();
    let currentPaymentDate = new Date();
    
    for (let i = 1; remainingBalance > 0 && i <= totalPaymentCount; i++) {
      // Calculate interest for this period
      const interestPayment = remainingBalance * periodicRate;
      // Calculate total payment including extra payment
      const totalPayment = regularPaymentAmount + extraPayment;
      // Calculate principal for this period (including extra payment)
      const principalPayment = Math.min(totalPayment - interestPayment, remainingBalance);
      // Update remaining balance
      remainingBalance -= principalPayment;
      paymentCount++;
      
      // Calculate date for this payment
      switch (paymentFrequency) {
        case "weekly":
          currentPaymentDate = addToDate(currentDate, i, "weeks");
          break;
        case "biweekly":
          currentPaymentDate = addToDate(currentDate, i * 2, "weeks");
          break;
        case "monthly":
          currentPaymentDate = addToDate(currentDate, i, "months");
          break;
      }
      
      // Add to payment schedule
      paymentSchedule.push({
        number: i,
        date: formatDate(currentPaymentDate),
        payment: regularPaymentAmount + extraPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: remainingBalance
      });
      
      // If this is the last payment, store the date
      if (remainingBalance <= 0) {
        payoffDate = currentPaymentDate;
      }
    }
    
    // Calculate total payments with extra payment
    const totalPayments = regularPaymentAmount * paymentCount + extraPayment * paymentCount;
    const totalInterest = totalPayments - loanAmount;
    
    steps.push(`With extra payments:`);
    steps.push(`Total payments: $${(regularPaymentAmount + extraPayment).toFixed(2)} * ${paymentCount} = $${totalPayments.toFixed(2)}`);
    steps.push(`Total interest: $${totalPayments.toFixed(2)} - $${loanAmount.toFixed(2)} = $${totalInterest.toFixed(2)}`);
    
    // Calculate savings
    const interestSavings = regularTotalInterest - totalInterest;
    const monthsSaved = regularPaymentCount - paymentCount;
    
    steps.push(`Interest savings: $${regularTotalInterest.toFixed(2)} - $${totalInterest.toFixed(2)} = $${interestSavings.toFixed(2)}`);
    steps.push(`Months saved: ${regularPaymentCount} - ${paymentCount} = ${monthsSaved}`);
    steps.push(`Regular payoff date: ${formatDate(regularPayoffDate)}`);
    steps.push(`Accelerated payoff date: ${formatDate(payoffDate)}`);
    
    return {
      monthlyPayment: regularPaymentAmount,
      totalPayments,
      totalInterest,
      payoffDate: formatDate(payoffDate),
      paymentSchedule,
      comparisonSchedule: regularSchedule,
      savings: interestSavings,
      months: monthsSaved,
      steps
    };
  };
  
  // Calculate payment breakdown
  const calculateBreakdown = (values: BreakdownFormValues) => {
    const { paymentAmount, principalAmount, interestRate, additionalFees, taxRate } = values;
    const steps: string[] = [];
    
    steps.push(`Payment amount: $${paymentAmount.toFixed(2)}`);
    steps.push(`Principal amount: $${principalAmount.toFixed(2)}`);
    steps.push(`Interest rate: ${interestRate}%`);
    steps.push(`Additional fees: $${additionalFees.toFixed(2)}`);
    steps.push(`Tax rate: ${taxRate}%`);
    
    // Calculate interest amount
    const interestAmount = principalAmount * (interestRate / 100);
    steps.push(`Interest amount: $${principalAmount.toFixed(2)} * ${interestRate}% = $${interestAmount.toFixed(2)}`);
    
    // Calculate tax amount
    const taxableAmount = principalAmount + interestAmount + additionalFees;
    const taxAmount = taxableAmount * (taxRate / 100);
    steps.push(`Taxable amount: $${principalAmount.toFixed(2)} + $${interestAmount.toFixed(2)} + $${additionalFees.toFixed(2)} = $${taxableAmount.toFixed(2)}`);
    steps.push(`Tax amount: $${taxableAmount.toFixed(2)} * ${taxRate}% = $${taxAmount.toFixed(2)}`);
    
    // Calculate total breakdown
    const totalWithoutTax = principalAmount + interestAmount + additionalFees;
    const total = totalWithoutTax + taxAmount;
    steps.push(`Total before tax: $${principalAmount.toFixed(2)} + $${interestAmount.toFixed(2)} + $${additionalFees.toFixed(2)} = $${totalWithoutTax.toFixed(2)}`);
    steps.push(`Total with tax: $${totalWithoutTax.toFixed(2)} + $${taxAmount.toFixed(2)} = $${total.toFixed(2)}`);
    
    // Payment breakdown
    const breakdown: PaymentBreakdown = {
      principal: principalAmount,
      interest: interestAmount,
      fees: additionalFees,
      taxes: taxAmount,
      total: total
    };
    
    // Calculate allocation percentages for chart
    const allocationChart = [
      {
        label: "Principal",
        value: principalAmount,
        percentage: (principalAmount / total) * 100
      },
      {
        label: "Interest",
        value: interestAmount,
        percentage: (interestAmount / total) * 100
      },
      {
        label: "Fees",
        value: additionalFees,
        percentage: (additionalFees / total) * 100
      },
      {
        label: "Taxes",
        value: taxAmount,
        percentage: (taxAmount / total) * 100
      }
    ];
    
    return {
      breakdown,
      allocationChart,
      steps
    };
  };
  
  // Form submission handlers
  const onInstallmentSubmit = (values: InstallmentFormValues) => {
    try {
      const result = calculateInstallment(values);
      setInstallmentResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onScheduleSubmit = (values: ScheduleFormValues) => {
    try {
      const result = calculateSchedule(values);
      setScheduleResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onBreakdownSubmit = (values: BreakdownFormValues) => {
    try {
      const result = calculateBreakdown(values);
      setBreakdownResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Calculator className="mr-2 h-8 w-8" /> Payment Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="installment" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="installment">Installment Payment</TabsTrigger>
                <TabsTrigger value="schedule">Payment Schedule</TabsTrigger>
                <TabsTrigger value="breakdown">Payment Breakdown</TabsTrigger>
              </TabsList>
              
              {/* Installment Payment Calculator */}
              <TabsContent value="installment">
                <Card>
                  <CardHeader>
                    <CardTitle>Installment Payment Calculator</CardTitle>
                    <CardDescription>
                      Calculate equal payments over time with interest.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...installmentForm}>
                      <form onSubmit={installmentForm.handleSubmit(onInstallmentSubmit)} className="space-y-6">
                        <FormField
                          control={installmentForm.control}
                          name="totalAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Total Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The total amount to be financed.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={installmentForm.control}
                            name="numberOfPayments"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Number of Payments</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={installmentForm.control}
                            name="interestRate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Interest Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={installmentForm.control}
                            name="paymentFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Payment Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={installmentForm.control}
                            name="firstPaymentDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>First Payment Date</FormLabel>
                                <FormControl>
                                  <Input {...field} type="date" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Installment Payment</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Payment Schedule Calculator */}
              <TabsContent value="schedule">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Schedule Calculator</CardTitle>
                    <CardDescription>
                      Calculate loan payment schedule with optional extra payments.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...scheduleForm}>
                      <form onSubmit={scheduleForm.handleSubmit(onScheduleSubmit)} className="space-y-6">
                        <FormField
                          control={scheduleForm.control}
                          name="loanAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Loan Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={scheduleForm.control}
                          name="annualInterestRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Annual Interest Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={scheduleForm.control}
                            name="loanTerm"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Loan Term</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="1" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={scheduleForm.control}
                            name="termUnit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Term Unit</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select unit" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="years">Years</SelectItem>
                                    <SelectItem value="months">Months</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={scheduleForm.control}
                            name="paymentFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Payment Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={scheduleForm.control}
                            name="extraPayment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Extra Payment (optional)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  Additional payment to make each period.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Payment Schedule</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Payment Breakdown Calculator */}
              <TabsContent value="breakdown">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Breakdown Calculator</CardTitle>
                    <CardDescription>
                      Calculate how your payment breaks down into components.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...breakdownForm}>
                      <form onSubmit={breakdownForm.handleSubmit(onBreakdownSubmit)} className="space-y-6">
                        <FormField
                          control={breakdownForm.control}
                          name="paymentAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Payment Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The total payment amount to analyze.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={breakdownForm.control}
                          name="principalAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Principal Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="0.01" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The portion of the payment going toward principal.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={breakdownForm.control}
                            name="interestRate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Interest Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={breakdownForm.control}
                            name="additionalFees"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Additional Fees</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="0.01" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={breakdownForm.control}
                          name="taxRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Tax Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" max="100" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormDescription>
                                Any applicable tax rate on the payment.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Payment Breakdown</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* Installment Payment Results */}
            {activeTab === "installment" && (
              <div className="space-y-6">
                {installmentResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Installment Payment Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Payment Amount</p>
                            <p className="text-2xl font-bold">${installmentResult.paymentAmount.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">
                              per {installmentForm.getValues().paymentFrequency.replace("ly", "")}
                            </p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${installmentResult.totalInterest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Payments</p>
                            <p className="text-2xl font-bold">${installmentResult.totalPayments.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Number of Payments</p>
                            <p className="text-2xl font-bold">{installmentForm.getValues().numberOfPayments}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Payment Schedule</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-6 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>No.</div>
                            <div>Date</div>
                            <div>Payment</div>
                            <div>Principal</div>
                            <div>Interest</div>
                            <div>Balance</div>
                          </div>
                          
                          {installmentResult.paymentSchedule.map((payment) => (
                            <div key={payment.number} className="grid grid-cols-6 gap-2 p-3 text-xs md:text-sm">
                              <div>{payment.number}</div>
                              <div>{payment.date}</div>
                              <div>${payment.payment.toFixed(2)}</div>
                              <div>${payment.principal.toFixed(2)}</div>
                              <div>${payment.interest.toFixed(2)}</div>
                              <div>${payment.balance.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {installmentResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Installment Payment Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <RefreshCw className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your details and click "Calculate Installment Payment"</p>
                        <p className="text-sm mt-2">Calculate equal payments over time with interest</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Payment Schedule Results */}
            {activeTab === "schedule" && (
              <div className="space-y-6">
                {scheduleResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Payment Schedule Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Monthly Payment</p>
                            <p className="text-2xl font-bold">${scheduleResult.monthlyPayment.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">
                              + ${scheduleForm.getValues().extraPayment.toFixed(2)} extra
                            </p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Payoff Date</p>
                            <p className="text-2xl font-bold">{scheduleResult.payoffDate}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${scheduleResult.totalInterest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Interest Savings</p>
                            <p className="text-2xl font-bold">${scheduleResult.savings?.toFixed(2) || "0.00"}</p>
                            <p className="text-xs text-gray-500">
                              {scheduleResult.months} months saved
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Payment Schedule</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-6 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>No.</div>
                            <div>Date</div>
                            <div>Payment</div>
                            <div>Principal</div>
                            <div>Interest</div>
                            <div>Balance</div>
                          </div>
                          
                          {scheduleResult.paymentSchedule.map((payment) => (
                            <div key={payment.number} className="grid grid-cols-6 gap-2 p-3 text-xs md:text-sm">
                              <div>{payment.number}</div>
                              <div>{payment.date}</div>
                              <div>${payment.payment.toFixed(2)}</div>
                              <div>${payment.principal.toFixed(2)}</div>
                              <div>${payment.interest.toFixed(2)}</div>
                              <div>${payment.balance.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {scheduleResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Schedule Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <CalendarDays className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your loan details and click "Calculate Payment Schedule"</p>
                        <p className="text-sm mt-2">See your complete loan payment schedule and how extra payments can save money</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Payment Breakdown Results */}
            {activeTab === "breakdown" && (
              <div className="space-y-6">
                {breakdownResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Payment Breakdown Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <div className="flex justify-between items-center">
                              <p className="text-sm text-gray-500">Original Payment:</p>
                              <p className="font-medium">${breakdownForm.getValues().paymentAmount.toFixed(2)}</p>
                            </div>
                            <div className="flex justify-between items-center mt-2">
                              <p className="text-sm text-gray-500">Calculated Total:</p>
                              <p className="font-medium">${breakdownResult.breakdown.total.toFixed(2)}</p>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <p className="text-sm font-medium">Principal:</p>
                              <div className="flex items-center">
                                <p className="font-medium">${breakdownResult.breakdown.principal.toFixed(2)}</p>
                                <p className="text-xs text-gray-500 ml-2">({breakdownResult.allocationChart[0].percentage.toFixed(1)}%)</p>
                              </div>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm font-medium">Interest:</p>
                              <div className="flex items-center">
                                <p className="font-medium">${breakdownResult.breakdown.interest.toFixed(2)}</p>
                                <p className="text-xs text-gray-500 ml-2">({breakdownResult.allocationChart[1].percentage.toFixed(1)}%)</p>
                              </div>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm font-medium">Fees:</p>
                              <div className="flex items-center">
                                <p className="font-medium">${breakdownResult.breakdown.fees.toFixed(2)}</p>
                                <p className="text-xs text-gray-500 ml-2">({breakdownResult.allocationChart[2].percentage.toFixed(1)}%)</p>
                              </div>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-sm font-medium">Taxes:</p>
                              <div className="flex items-center">
                                <p className="font-medium">${breakdownResult.breakdown.taxes.toFixed(2)}</p>
                                <p className="text-xs text-gray-500 ml-2">({breakdownResult.allocationChart[3].percentage.toFixed(1)}%)</p>
                              </div>
                            </div>
                            <Separator className="my-2" />
                            <div className="flex justify-between items-center font-medium">
                              <p>Total:</p>
                              <p>${breakdownResult.breakdown.total.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <h3 className="text-sm font-medium mb-2">Payment Allocation</h3>
                          <div className="w-full h-8 flex rounded-full overflow-hidden">
                            {breakdownResult.allocationChart.map((item, index) => (
                              <div 
                                key={index}
                                className={`h-full flex items-center justify-center text-xs text-white ${index === 0 ? 'bg-blue-500' : index === 1 ? 'bg-green-500' : index === 2 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                style={{ width: `${item.percentage}%`, minWidth: item.percentage > 3 ? 'auto' : '3%' }}
                              >
                                {item.percentage > 5 ? `${item.percentage.toFixed(0)}%` : ''}
                              </div>
                            ))}
                          </div>
                          <div className="flex justify-between mt-2 text-xs">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
                              <span>Principal</span>
                            </div>
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                              <span>Interest</span>
                            </div>
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
                              <span>Fees</span>
                            </div>
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                              <span>Taxes</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {breakdownResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Breakdown Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Clipboard className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter payment details and click "Calculate Payment Breakdown"</p>
                        <p className="text-sm mt-2">Analyze how your payment is allocated between principal, interest, fees, and taxes</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Educational Information */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Understanding Payment Calculations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Installment Payments</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Installment payments divide a total amount into equal periodic payments that include both principal and interest. 
                    The amortization formula ensures that each payment contains the right proportion of principal and interest 
                    so that the loan is paid off exactly at the end of the term.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">The Impact of Extra Payments</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Making extra payments on a loan can significantly reduce the total interest paid and shorten the loan term. 
                    Even small additional amounts applied directly to the principal can save thousands over the life of a loan.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Payment Breakdown Components</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Understanding how your payment breaks down helps you see where your money is going:
                  </p>
                  <ul className="list-disc pl-5 mt-1 space-y-1 text-sm text-gray-600">
                    <li><strong>Principal:</strong> Reduces the loan balance</li>
                    <li><strong>Interest:</strong> Cost of borrowing the money</li>
                    <li><strong>Fees:</strong> Additional charges for services</li>
                    <li><strong>Taxes:</strong> Government-imposed charges on transactions</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default PaymentCalculator;
