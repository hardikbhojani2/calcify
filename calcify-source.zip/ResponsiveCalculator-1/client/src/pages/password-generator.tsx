import React, { useState, useEffect } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Key, Copy, RefreshCw, Shield, AlertCircle } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for password generator
const passwordFormSchema = z.object({
  length: z.coerce.number().min(4, "Password must be at least 4 characters").max(128, "Password must be at most 128 characters"),
  includeUppercase: z.boolean().default(true),
  includeLowercase: z.boolean().default(true),
  includeNumbers: z.boolean().default(true),
  includeSymbols: z.boolean().default(true),
  excludeSimilar: z.boolean().default(false),
  excludeAmbiguous: z.boolean().default(false),
});

// Define the form schema for passphrase generator
const passphraseFormSchema = z.object({
  wordCount: z.coerce.number().min(2, "Must have at least 2 words").max(12, "Must have at most 12 words"),
  separator: z.string().max(5, "Separator must be at most 5 characters"),
  capitalize: z.boolean().default(false),
  includeNumber: z.boolean().default(false),
});

type PasswordFormValues = z.infer<typeof passwordFormSchema>;
type PassphraseFormValues = z.infer<typeof passphraseFormSchema>;

const PasswordGenerator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("password");
  const [generatedPassword, setGeneratedPassword] = useState("");
  const [generatedPassphrase, setGeneratedPassphrase] = useState("");
  const [passwordStrength, setPasswordStrength] = useState({
    score: 0,
    crackTime: "",
    label: "",
    color: ""
  });

  // Initialize the form for password generator
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      length: 16,
      includeUppercase: true,
      includeLowercase: true,
      includeNumbers: true,
      includeSymbols: true,
      excludeSimilar: false,
      excludeAmbiguous: false,
    },
  });
  
  // Initialize the form for passphrase generator
  const passphraseForm = useForm<PassphraseFormValues>({
    resolver: zodResolver(passphraseFormSchema),
    defaultValues: {
      wordCount: 4,
      separator: "-",
      capitalize: true,
      includeNumber: true,
    },
  });

  // Character sets for password generation
  const charSets = {
    uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    lowercase: 'abcdefghijklmnopqrstuvwxyz',
    numbers: '0123456789',
    symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?',
    similar: 'il1Lo0O',
    ambiguous: '{}[]()/\\\'"",;:.<>'
  };
  
  // Word list for passphrase generation (common English words)
  const commonWords = [
    "about", "above", "across", "actor", "active", "activity", "add", "afraid", "after", "again",
    "age", "ago", "agree", "air", "all", "alone", "along", "already", "always", "amount",
    "anger", "angry", "animal", "answer", "any", "anyone", "appear", "apple", "area", "arm",
    "army", "around", "arrive", "art", "artist", "ask", "attack", "aunt", "autumn", "away",
    "baby", "back", "bad", "bag", "ball", "bank", "base", "basket", "bath", "bear",
    "beat", "beauty", "bed", "beer", "begin", "behind", "bell", "below", "best", "better",
    "between", "big", "bird", "birth", "bit", "bite", "black", "bleed", "block", "blood",
    "blow", "blue", "board", "boat", "body", "boil", "bone", "book", "border", "born",
    "both", "bowl", "box", "boy", "branch", "brave", "bread", "break", "breakfast", "breath",
    "bridge", "bright", "bring", "brother", "brown", "brush", "build", "burn", "bus", "busy",
    "cake", "call", "can", "candle", "cap", "car", "card", "care", "carry", "case",
    "cat", "catch", "central", "century", "chair", "chance", "change", "chase", "cheap", "cheese",
    "chicken", "child", "choice", "choose", "circle", "city", "class", "clean", "clear", "climb",
    "clock", "close", "cloth", "cloud", "coat", "coffee", "coin", "cold", "collect", "color",
    "come", "common", "compare", "complete", "computer", "condition", "contain", "continue", "control", "cook",
    "cool", "copper", "corn", "corner", "correct", "cost", "count", "country", "course", "cover",
    "crash", "cross", "cry", "cup", "cupboard", "cut", "dance", "danger", "dark", "date",
    "day", "dead", "decide", "deep", "deer", "depend", "desk", "destroy", "develop", "die",
    "different", "difficult", "dinner", "direction", "dirty", "discover", "dish", "do", "dog",
    "door", "double", "down", "draw", "dream", "dress", "drink", "drive", "drop", "dry",
    "duck", "dust", "duty", "each", "ear", "early", "earn", "earth", "east", "easy",
    "eat", "edge", "egg", "eight", "either", "elephant", "else", "empty", "end", "enemy",
    "enjoy", "enough", "enter", "equal", "event", "ever", "every", "exact", "except", "excite",
    "exit", "expect", "expensive", "explain", "extremely", "eye", "face", "fact", "fail", "fall",
    "false", "family", "famous", "far", "farm", "fast", "fat", "father", "fault", "fear"
  ];

  // Function to generate a random password based on form values
  const generatePassword = (values: PasswordFormValues): string => {
    let charset = '';
    if (values.includeLowercase) charset += charSets.lowercase;
    if (values.includeUppercase) charset += charSets.uppercase;
    if (values.includeNumbers) charset += charSets.numbers;
    if (values.includeSymbols) charset += charSets.symbols;
    
    // Remove similar characters if requested
    if (values.excludeSimilar) {
      for (const char of charSets.similar) {
        charset = charset.replace(char, '');
      }
    }
    
    // Remove ambiguous characters if requested
    if (values.excludeAmbiguous) {
      for (const char of charSets.ambiguous) {
        charset = charset.replace(char, '');
      }
    }
    
    // Ensure at least one character set is selected
    if (charset.length === 0) {
      throw new Error("Please select at least one character type (lowercase, uppercase, numbers, or symbols).");
    }
    
    // Generate the password
    let password = '';
    const length = values.length;
    
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      password += charset[randomIndex];
    }
    
    return password;
  };
  
  // Function to generate a random passphrase based on form values
  const generatePassphrase = (values: PassphraseFormValues): string => {
    let passphrase = [];
    
    // Generate random words
    for (let i = 0; i < values.wordCount; i++) {
      const randomIndex = Math.floor(Math.random() * commonWords.length);
      let word = commonWords[randomIndex];
      
      // Capitalize if requested
      if (values.capitalize) {
        word = word.charAt(0).toUpperCase() + word.slice(1);
      }
      
      passphrase.push(word);
    }
    
    // Add a random number to the end if requested
    if (values.includeNumber) {
      const randomNumber = Math.floor(Math.random() * 1000);
      passphrase.push(randomNumber.toString());
    }
    
    return passphrase.join(values.separator);
  };

  // Function to estimate password strength
  const estimatePasswordStrength = (password: string): void => {
    // Basic entropy calculation
    const length = password.length;
    let charset = 0;
    const hasLower = /[a-z]/.test(password);
    const hasUpper = /[A-Z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSymbol = /[^A-Za-z0-9]/.test(password);
    
    if (hasLower) charset += 26;
    if (hasUpper) charset += 26;
    if (hasNumber) charset += 10;
    if (hasSymbol) charset += 33;
    
    // Entropy in bits
    const entropy = Math.log2(Math.pow(charset, length));
    
    // Score from 0-4 based on entropy
    let score = 0;
    let crackTime = '';
    let label = '';
    let color = '';
    
    if (entropy < 28) {
      score = 0;
      crackTime = "Instant";
      label = "Very Weak";
      color = "text-red-600";
    } else if (entropy < 36) {
      score = 1;
      crackTime = "Minutes";
      label = "Weak";
      color = "text-orange-600";
    } else if (entropy < 60) {
      score = 2;
      crackTime = "Hours to Days";
      label = "Moderate";
      color = "text-yellow-600";
    } else if (entropy < 80) {
      score = 3;
      crackTime = "Months to Years";
      label = "Strong";
      color = "text-lime-600";
    } else {
      score = 4;
      crackTime = "Centuries";
      label = "Very Strong";
      color = "text-green-600";
    }
    
    setPasswordStrength({ score, crackTime, label, color });
  };

  // Generate initial password on component mount
  useEffect(() => {
    try {
      if (activeTab === "password") {
        const newPassword = generatePassword(passwordForm.getValues());
        setGeneratedPassword(newPassword);
        estimatePasswordStrength(newPassword);
      } else {
        const newPassphrase = generatePassphrase(passphraseForm.getValues());
        setGeneratedPassphrase(newPassphrase);
        estimatePasswordStrength(newPassphrase);
      }
    } catch (error) {
      console.error('Generation error:', error);
    }
  }, [activeTab]);

  // Function to copy password to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: 'Copied!',
        description: 'Password copied to clipboard.',
      });
    }).catch(err => {
      toast({
        title: 'Copy Failed',
        description: 'Could not copy to clipboard.',
        variant: 'destructive',
      });
    });
  };

  // Form submission handlers
  const onPasswordSubmit = (values: PasswordFormValues) => {
    try {
      const newPassword = generatePassword(values);
      setGeneratedPassword(newPassword);
      estimatePasswordStrength(newPassword);
      toast({
        title: 'Password Generated',
        description: 'Your secure password has been generated successfully.',
      });
    } catch (error) {
      let errorMessage = 'There was an error generating your password.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Generation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };
  
  const onPassphraseSubmit = (values: PassphraseFormValues) => {
    try {
      const newPassphrase = generatePassphrase(values);
      setGeneratedPassphrase(newPassphrase);
      estimatePasswordStrength(newPassphrase);
      toast({
        title: 'Passphrase Generated',
        description: 'Your secure passphrase has been generated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error generating your passphrase.',
        variant: 'destructive',
      });
    }
  };

  // Function to quickly regenerate password/passphrase without form submission
  const quickRegenerate = () => {
    try {
      if (activeTab === "password") {
        const newPassword = generatePassword(passwordForm.getValues());
        setGeneratedPassword(newPassword);
        estimatePasswordStrength(newPassword);
      } else {
        const newPassphrase = generatePassphrase(passphraseForm.getValues());
        setGeneratedPassphrase(newPassphrase);
        estimatePasswordStrength(newPassphrase);
      }
      
      toast({
        title: 'Regenerated',
        description: activeTab === "password" ? 'Password regenerated.' : 'Passphrase regenerated.',
      });
    } catch (error) {
      toast({
        title: 'Generation Error',
        description: 'There was an error during regeneration.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Key className="mr-2 h-8 w-8" /> Password Generator
          </h1>
        </div>
        
        {/* Result Display */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{activeTab === "password" ? "Your Generated Password" : "Your Generated Passphrase"}</CardTitle>
            <CardDescription>
              {activeTab === "password" ? 
                "A strong, random password for your security needs." : 
                "A memorable passphrase that's both secure and easy to remember."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-md font-mono text-lg break-all">
                {activeTab === "password" ? generatedPassword : generatedPassphrase}
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2"
                  onClick={() => copyToClipboard(activeTab === "password" ? generatedPassword : generatedPassphrase)}
                >
                  <Copy className="h-4 w-4" /> Copy to Clipboard
                </Button>
                
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2"
                  onClick={quickRegenerate}
                >
                  <RefreshCw className="h-4 w-4" /> Regenerate
                </Button>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="text-sm font-medium">Strength:</div>
                <div className={`text-sm font-semibold ${passwordStrength.color}`}>
                  {passwordStrength.label}
                </div>
                <div className="flex-grow">
                  <div className="bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${passwordStrength.score === 0 ? "bg-red-500" :
                                  passwordStrength.score === 1 ? "bg-orange-500" :
                                  passwordStrength.score === 2 ? "bg-yellow-500" :
                                  passwordStrength.score === 3 ? "bg-lime-500" :
                                  "bg-green-500"}`}
                      style={{ width: `${(passwordStrength.score + 1) * 20}%` }}
                    ></div>
                  </div>
                </div>
                <div className="text-xs text-gray-500">
                  Est. crack time: {passwordStrength.crackTime}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="password" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="password">Password</TabsTrigger>
            <TabsTrigger value="passphrase">Passphrase</TabsTrigger>
          </TabsList>
          
          {/* Password Generator Tab */}
          <TabsContent value="password" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate a Secure Password</CardTitle>
                <CardDescription>
                  Customize your password settings according to your needs.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-6">
                    <FormField
                      control={passwordForm.control}
                      name="length"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password Length: {field.value} characters</FormLabel>
                          <FormControl>
                            <Slider
                              min={4}
                              max={128}
                              step={1}
                              defaultValue={[field.value]}
                              onValueChange={(value) => field.onChange(value[0])}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div>
                      <h3 className="text-sm font-medium mb-3">Character Types</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={passwordForm.control}
                          name="includeLowercase"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Lowercase Letters
                                </FormLabel>
                                <FormDescription>
                                  a-z
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="includeUppercase"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Uppercase Letters
                                </FormLabel>
                                <FormDescription>
                                  A-Z
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="includeNumbers"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Numbers
                                </FormLabel>
                                <FormDescription>
                                  0-9
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="includeSymbols"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Symbols
                                </FormLabel>
                                <FormDescription>
                                  !@#$%^&*()_+-={}[]|
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-3">Exclusions</h3>
                      <div className="grid grid-cols-1 gap-4">
                        <FormField
                          control={passwordForm.control}
                          name="excludeSimilar"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Exclude Similar Characters
                                </FormLabel>
                                <FormDescription>
                                  Exclude easily confused characters: i, l, 1, L, o, 0, O
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="excludeAmbiguous"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Exclude Ambiguous Characters
                                </FormLabel>
                                <FormDescription>
                                  Exclude special characters that can be hard to read
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full">Generate Password</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Password Security Tips</CardTitle>
                <CardDescription>
                  Best practices for creating and managing secure passwords.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Use Unique Passwords</h3>
                      <p className="text-sm text-gray-600">Use a different password for each of your accounts. This prevents all your accounts from being compromised if one password is leaked.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Password Length Matters</h3>
                      <p className="text-sm text-gray-600">Longer passwords are generally more secure. Aim for at least 12 characters, but 16+ is better for important accounts.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Use a Password Manager</h3>
                      <p className="text-sm text-gray-600">Use a reputable password manager to securely store all your unique passwords. This way, you only need to remember one master password.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Enable Two-Factor Authentication</h3>
                      <p className="text-sm text-gray-600">Whenever possible, enable two-factor authentication (2FA) for an extra layer of security beyond just your password.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Avoid Common Patterns</h3>
                      <p className="text-sm text-gray-600">Don't use predictable patterns like keyboard sequences (qwerty), repetitions (aaa), or simple substitutions (p@ssw0rd).</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-medium">Don't Share Passwords</h3>
                      <p className="text-sm text-gray-600">Never share your passwords with others, and don't send passwords via email, text messages, or other unsecured channels.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Passphrase Generator Tab */}
          <TabsContent value="passphrase" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate a Secure Passphrase</CardTitle>
                <CardDescription>
                  Create a memorable passphrase using random words.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...passphraseForm}>
                  <form onSubmit={passphraseForm.handleSubmit(onPassphraseSubmit)} className="space-y-6">
                    <FormField
                      control={passphraseForm.control}
                      name="wordCount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Number of Words: {field.value}</FormLabel>
                          <FormControl>
                            <Slider
                              min={2}
                              max={12}
                              step={1}
                              defaultValue={[field.value]}
                              onValueChange={(value) => field.onChange(value[0])}
                            />
                          </FormControl>
                          <FormMessage />
                          <FormDescription>
                            More words increase security but decrease memorability.
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passphraseForm.control}
                      name="separator"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Word Separator</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              placeholder="-" 
                              maxLength={5}
                            />
                          </FormControl>
                          <FormMessage />
                          <FormDescription>
                            Character(s) used to separate words. Common examples: "-", ".", "_", space
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 gap-4">
                      <FormField
                        control={passphraseForm.control}
                        name="capitalize"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Capitalize Words
                              </FormLabel>
                              <FormDescription>
                                Capitalize the first letter of each word for added security.
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={passphraseForm.control}
                        name="includeNumber"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Include Number
                              </FormLabel>
                              <FormDescription>
                                Add a random number at the end of the passphrase.
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">Generate Passphrase</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>About Passphrases</CardTitle>
                <CardDescription>
                  Why passphrases can be more secure and memorable than passwords.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium">What is a Passphrase?</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      A passphrase is a sequence of random words used for authentication, offering a balance between security and memorability. Example: "correct-horse-battery-staple".
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium">Advantages of Passphrases</h3>
                    <ul className="text-sm text-gray-600 mt-1 space-y-2">
                      <li className="flex items-start gap-2">
                        <Shield className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>High Entropy:</strong> Four random words provide more entropy (security) than most complex passwords.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Shield className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Memorability:</strong> Words are easier for humans to remember than random characters.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Shield className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Typing Ease:</strong> Easier to type on mobile and other devices than complex character combinations.</span>
                      </li>
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium">Effective Usage</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      For maximum security, use 4+ random words with a mix of capitalization, numbers, and separators. Don't use famous phrases or quotes, as these are vulnerable to dictionary attacks.
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Did You Know?</h3>
                    <p className="text-sm text-gray-600">
                      The concept of passphrases was popularized by the XKCD comic "Password Strength," which showed that "correct horse battery staple" would take 550 years to crack compared to just 3 days for "Tr0ub4dor&3" using modern computing methods.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Password Generation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our password generator offers two primary approaches to creating secure authentication:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Random Passwords</strong>: Create complex combinations of characters that are extremely difficult to guess or crack through brute force methods.</li>
                  <li><strong>Memorable Passphrases</strong>: Generate sequences of random words that are easier to remember while still maintaining high security.</li>
                </ul>
                <p>Key security features:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>All generation is done client-side in your browser - we never see or store your passwords</li>
                  <li>Password strength estimation based on entropy calculation</li>
                  <li>Option to exclude characters that might be confusing or problematic</li>
                  <li>Flexibility to customize based on your specific security requirements</li>
                </ul>
                <p className="text-gray-500">Note: While this tool creates strong passwords, always use a password manager to store them securely and enable two-factor authentication when available.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default PasswordGenerator;
