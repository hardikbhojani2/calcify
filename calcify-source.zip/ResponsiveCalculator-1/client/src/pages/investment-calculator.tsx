import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, TrendingUp, LineChart, PiggyBank, Sigma, BarChart } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for lump sum investment
const lumpSumSchema = z.object({
  initialInvestment: z.coerce.number().min(0, "Initial investment cannot be negative"),
  annualReturn: z.coerce.number().min(-100, "Annual return cannot be less than -100%").max(1000, "Annual return cannot exceed 1000%"),
  years: z.coerce.number().positive("Investment period must be positive").max(100, "Investment period cannot exceed 100 years"),
  compoundingFrequency: z.enum(["annually", "semiannually", "quarterly", "monthly", "daily", "continuous"]),
  inflation: z.coerce.number().min(0, "Inflation rate cannot be negative").max(1000, "Inflation rate cannot exceed 1000%"),
});

// Define the form schema for regular contributions
const contributionSchema = z.object({
  initialInvestment: z.coerce.number().min(0, "Initial investment cannot be negative"),
  contribution: z.coerce.number().min(0, "Contribution cannot be negative"),
  contributionFrequency: z.enum(["monthly", "quarterly", "annually"]),
  annualReturn: z.coerce.number().min(-100, "Annual return cannot be less than -100%").max(1000, "Annual return cannot exceed 1000%"),
  years: z.coerce.number().positive("Investment period must be positive").max(100, "Investment period cannot exceed 100 years"),
  compoundingFrequency: z.enum(["annually", "semiannually", "quarterly", "monthly", "daily", "continuous"]),
  inflation: z.coerce.number().min(0, "Inflation rate cannot be negative").max(1000, "Inflation rate cannot exceed 1000%"),
});

// Define the form schema for target goal
const targetSchema = z.object({
  initialInvestment: z.coerce.number().min(0, "Initial investment cannot be negative"),
  targetAmount: z.coerce.number().positive("Target amount must be positive"),
  contribution: z.coerce.number().min(0, "Contribution cannot be negative"),
  contributionFrequency: z.enum(["monthly", "quarterly", "annually"]),
  annualReturn: z.coerce.number().min(-100, "Annual return cannot be less than -100%").max(1000, "Annual return cannot exceed 1000%"),
  compoundingFrequency: z.enum(["annually", "semiannually", "quarterly", "monthly", "daily", "continuous"]),
  inflation: z.coerce.number().min(0, "Inflation rate cannot be negative").max(1000, "Inflation rate cannot exceed 1000%"),
});

type LumpSumFormValues = z.infer<typeof lumpSumSchema>;
type ContributionFormValues = z.infer<typeof contributionSchema>;
type TargetFormValues = z.infer<typeof targetSchema>;

interface InvestmentYearData {
  year: number;
  startingBalance: number;
  contribution: number;
  interest: number;
  endingBalance: number;
  endingBalanceInflationAdjusted?: number;
}

const InvestmentCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("lumpsum");
  const [lumpSumResult, setLumpSumResult] = useState<{
    finalBalance: number;
    totalInterest: number;
    inflationAdjustedBalance: number;
    yearlyData: InvestmentYearData[];
    steps: string[];
  } | null>(null);
  
  const [contributionResult, setContributionResult] = useState<{
    finalBalance: number;
    totalContributions: number;
    totalInterest: number;
    inflationAdjustedBalance: number;
    yearlyData: InvestmentYearData[];
    steps: string[];
  } | null>(null);
  
  const [targetResult, setTargetResult] = useState<{
    yearsToTarget: number;
    finalBalance: number;
    totalContributions: number;
    totalInterest: number;
    inflationAdjustedTarget: number;
    yearlyData: InvestmentYearData[];
    steps: string[];
  } | null>(null);
  
  // Initialize lump sum investment form
  const lumpSumForm = useForm<LumpSumFormValues>({
    resolver: zodResolver(lumpSumSchema),
    defaultValues: {
      initialInvestment: 10000,
      annualReturn: 7,
      years: 10,
      compoundingFrequency: "annually",
      inflation: 2.5,
    },
  });
  
  // Initialize regular contribution form
  const contributionForm = useForm<ContributionFormValues>({
    resolver: zodResolver(contributionSchema),
    defaultValues: {
      initialInvestment: 5000,
      contribution: 500,
      contributionFrequency: "monthly",
      annualReturn: 7,
      years: 20,
      compoundingFrequency: "monthly",
      inflation: 2.5,
    },
  });
  
  // Initialize target goal form
  const targetForm = useForm<TargetFormValues>({
    resolver: zodResolver(targetSchema),
    defaultValues: {
      initialInvestment: 10000,
      targetAmount: 100000,
      contribution: 500,
      contributionFrequency: "monthly",
      annualReturn: 7,
      compoundingFrequency: "monthly",
      inflation: 2.5,
    },
  });
  
  // Helper function to get compounding frequency per year
  const getCompoundsPerYear = (frequency: string): number => {
    switch (frequency) {
      case "annually": return 1;
      case "semiannually": return 2;
      case "quarterly": return 4;
      case "monthly": return 12;
      case "daily": return 365;
      case "continuous": return Infinity;
      default: return 1;
    }
  };
  
  // Helper function to get contributions per year
  const getContributionsPerYear = (frequency: string): number => {
    switch (frequency) {
      case "annually": return 1;
      case "quarterly": return 4;
      case "monthly": return 12;
      default: return 1;
    }
  };
  
  // Calculate lump sum investment
  const calculateLumpSum = (values: LumpSumFormValues) => {
    const { initialInvestment, annualReturn, years, compoundingFrequency, inflation } = values;
    const steps: string[] = [];
    
    // Convert percentages to decimals
    const returnRate = annualReturn / 100;
    const inflationRate = inflation / 100;
    
    steps.push(`Initial investment: $${initialInvestment.toFixed(2)}`);
    steps.push(`Annual return rate: ${annualReturn}% (${returnRate} as decimal)`);
    steps.push(`Investment period: ${years} years`);
    steps.push(`Inflation rate: ${inflation}% (${inflationRate} as decimal)`);
    
    // Get compounding frequency
    const compoundsPerYear = getCompoundsPerYear(compoundingFrequency);
    steps.push(`Compounding frequency: ${compoundingFrequency} (${compoundsPerYear === Infinity ? "continuous" : compoundsPerYear + " times per year"})`);
    
    // Calculate final balance
    let finalBalance: number;
    if (compoundsPerYear === Infinity) {
      // Continuous compounding: A = P * e^(rt)
      finalBalance = initialInvestment * Math.exp(returnRate * years);
      steps.push(`Using continuous compounding formula: A = P * e^(rt)`);
      steps.push(`A = $${initialInvestment.toFixed(2)} * e^(${returnRate} * ${years})`);
    } else {
      // Discrete compounding: A = P * (1 + r/n)^(nt)
      finalBalance = initialInvestment * Math.pow(1 + returnRate / compoundsPerYear, compoundsPerYear * years);
      steps.push(`Using discrete compounding formula: A = P * (1 + r/n)^(nt)`);
      steps.push(`A = $${initialInvestment.toFixed(2)} * (1 + ${returnRate}/${compoundsPerYear})^(${compoundsPerYear} * ${years})`);
    }
    
    steps.push(`Final balance: $${finalBalance.toFixed(2)}`);
    
    // Calculate total interest earned
    const totalInterest = finalBalance - initialInvestment;
    steps.push(`Total interest earned: $${finalBalance.toFixed(2)} - $${initialInvestment.toFixed(2)} = $${totalInterest.toFixed(2)}`);
    
    // Calculate inflation-adjusted final balance
    const inflationAdjustedBalance = finalBalance / Math.pow(1 + inflationRate, years);
    steps.push(`Inflation-adjusted final balance: $${finalBalance.toFixed(2)} / (1 + ${inflationRate})^${years} = $${inflationAdjustedBalance.toFixed(2)}`);
    
    // Generate yearly data
    const yearlyData: InvestmentYearData[] = [];
    let balance = initialInvestment;
    
    for (let year = 1; year <= years; year++) {
      const startingBalance = balance;
      let interestEarned: number;
      
      if (compoundsPerYear === Infinity) {
        // Continuous compounding for one year
        balance = startingBalance * Math.exp(returnRate);
        interestEarned = balance - startingBalance;
      } else {
        // Discrete compounding for one year
        balance = startingBalance * Math.pow(1 + returnRate / compoundsPerYear, compoundsPerYear);
        interestEarned = balance - startingBalance;
      }
      
      // Calculate inflation-adjusted balance
      const inflationAdjustedBalance = balance / Math.pow(1 + inflationRate, year);
      
      yearlyData.push({
        year,
        startingBalance,
        contribution: 0, // No contributions in lump sum
        interest: interestEarned,
        endingBalance: balance,
        endingBalanceInflationAdjusted: inflationAdjustedBalance
      });
    }
    
    return {
      finalBalance,
      totalInterest,
      inflationAdjustedBalance,
      yearlyData,
      steps
    };
  };
  
  // Calculate investment with regular contributions
  const calculateContribution = (values: ContributionFormValues) => {
    const { initialInvestment, contribution, contributionFrequency, annualReturn, years, compoundingFrequency, inflation } = values;
    const steps: string[] = [];
    
    // Convert percentages to decimals
    const returnRate = annualReturn / 100;
    const inflationRate = inflation / 100;
    
    steps.push(`Initial investment: $${initialInvestment.toFixed(2)}`);
    steps.push(`Regular contribution: $${contribution.toFixed(2)} ${contributionFrequency}`);
    steps.push(`Annual return rate: ${annualReturn}% (${returnRate} as decimal)`);
    steps.push(`Investment period: ${years} years`);
    steps.push(`Inflation rate: ${inflation}% (${inflationRate} as decimal)`);
    
    // Get compounding and contribution frequencies
    const compoundsPerYear = getCompoundsPerYear(compoundingFrequency);
    const contributionsPerYear = getContributionsPerYear(contributionFrequency);
    
    steps.push(`Compounding frequency: ${compoundingFrequency} (${compoundsPerYear === Infinity ? "continuous" : compoundsPerYear + " times per year"})`);
    steps.push(`Contribution frequency: ${contributionFrequency} (${contributionsPerYear} times per year)`);
    
    // Calculate annual contribution
    const annualContribution = contribution * contributionsPerYear;
    steps.push(`Annual contribution: $${contribution.toFixed(2)} * ${contributionsPerYear} = $${annualContribution.toFixed(2)}`);
    
    // Generate yearly data and calculate final results
    const yearlyData: InvestmentYearData[] = [];
    let balance = initialInvestment;
    let totalContributions = 0;
    
    for (let year = 1; year <= years; year++) {
      const startingBalance = balance;
      const yearlyContribution = annualContribution;
      totalContributions += yearlyContribution;
      
      let interestEarned: number;
      let endingBalance: number;
      
      // Calculate interest and ending balance
      // This is a simplified model that adds contributions at the beginning of each year
      if (compoundsPerYear === Infinity) {
        // Continuous compounding for one year with contribution
        endingBalance = (startingBalance + yearlyContribution) * Math.exp(returnRate);
        interestEarned = endingBalance - (startingBalance + yearlyContribution);
      } else {
        // Discrete compounding for one year with contribution
        endingBalance = (startingBalance + yearlyContribution) * Math.pow(1 + returnRate / compoundsPerYear, compoundsPerYear);
        interestEarned = endingBalance - (startingBalance + yearlyContribution);
      }
      
      balance = endingBalance;
      
      // Calculate inflation-adjusted balance
      const inflationAdjustedBalance = balance / Math.pow(1 + inflationRate, year);
      
      yearlyData.push({
        year,
        startingBalance,
        contribution: yearlyContribution,
        interest: interestEarned,
        endingBalance: balance,
        endingBalanceInflationAdjusted: inflationAdjustedBalance
      });
    }
    
    const finalBalance = balance;
    const totalInterest = finalBalance - initialInvestment - totalContributions;
    const inflationAdjustedBalance = finalBalance / Math.pow(1 + inflationRate, years);
    
    steps.push(`Final balance: $${finalBalance.toFixed(2)}`);
    steps.push(`Total contributions: $${totalContributions.toFixed(2)}`);
    steps.push(`Total interest earned: $${totalInterest.toFixed(2)}`);
    steps.push(`Inflation-adjusted final balance: $${inflationAdjustedBalance.toFixed(2)}`);
    
    return {
      finalBalance,
      totalContributions,
      totalInterest,
      inflationAdjustedBalance,
      yearlyData,
      steps
    };
  };
  
  // Calculate years needed to reach target amount
  const calculateTarget = (values: TargetFormValues) => {
    const { initialInvestment, targetAmount, contribution, contributionFrequency, annualReturn, compoundingFrequency, inflation } = values;
    const steps: string[] = [];
    
    // Convert percentages to decimals
    const returnRate = annualReturn / 100;
    const inflationRate = inflation / 100;
    
    steps.push(`Initial investment: $${initialInvestment.toFixed(2)}`);
    steps.push(`Target amount: $${targetAmount.toFixed(2)}`);
    steps.push(`Regular contribution: $${contribution.toFixed(2)} ${contributionFrequency}`);
    steps.push(`Annual return rate: ${annualReturn}% (${returnRate} as decimal)`);
    steps.push(`Inflation rate: ${inflation}% (${inflationRate} as decimal)`);
    
    // Get compounding and contribution frequencies
    const compoundsPerYear = getCompoundsPerYear(compoundingFrequency);
    const contributionsPerYear = getContributionsPerYear(contributionFrequency);
    
    steps.push(`Compounding frequency: ${compoundingFrequency} (${compoundsPerYear === Infinity ? "continuous" : compoundsPerYear + " times per year"})`);
    steps.push(`Contribution frequency: ${contributionFrequency} (${contributionsPerYear} times per year)`);
    
    // Calculate annual contribution
    const annualContribution = contribution * contributionsPerYear;
    steps.push(`Annual contribution: $${contribution.toFixed(2)} * ${contributionsPerYear} = $${annualContribution.toFixed(2)}`);
    
    // Calculate inflation-adjusted target amount over time
    const inflationAdjustedTarget = targetAmount;
    steps.push(`Inflation-adjusted target amount: $${inflationAdjustedTarget.toFixed(2)}`);
    
    // Iteratively calculate how many years needed to reach target
    const yearlyData: InvestmentYearData[] = [];
    let balance = initialInvestment;
    let year = 0;
    let totalContributions = 0;
    
    // Set maximum years to prevent infinite loops in case target is never reached
    const maxYears = 100;
    
    while (balance < targetAmount && year < maxYears) {
      year++;
      const startingBalance = balance;
      const yearlyContribution = annualContribution;
      totalContributions += yearlyContribution;
      
      let interestEarned: number;
      let endingBalance: number;
      
      // Calculate interest and ending balance
      if (compoundsPerYear === Infinity) {
        // Continuous compounding
        endingBalance = (startingBalance + yearlyContribution) * Math.exp(returnRate);
        interestEarned = endingBalance - (startingBalance + yearlyContribution);
      } else {
        // Discrete compounding
        endingBalance = (startingBalance + yearlyContribution) * Math.pow(1 + returnRate / compoundsPerYear, compoundsPerYear);
        interestEarned = endingBalance - (startingBalance + yearlyContribution);
      }
      
      balance = endingBalance;
      
      // Calculate inflation-adjusted balance
      const inflationAdjustedBalance = balance / Math.pow(1 + inflationRate, year);
      
      yearlyData.push({
        year,
        startingBalance,
        contribution: yearlyContribution,
        interest: interestEarned,
        endingBalance: balance,
        endingBalanceInflationAdjusted: inflationAdjustedBalance
      });
      
      if (balance >= targetAmount) {
        break;
      }
    }
    
    const finalBalance = balance;
    const totalInterest = finalBalance - initialInvestment - totalContributions;
    const yearsToTarget = year;
    
    if (year >= maxYears) {
      steps.push(`Target amount not reached within ${maxYears} years.`);
    } else {
      steps.push(`Years needed to reach target: ${yearsToTarget}`);
      steps.push(`Final balance: $${finalBalance.toFixed(2)}`);
      steps.push(`Total contributions: $${totalContributions.toFixed(2)}`);
      steps.push(`Total interest earned: $${totalInterest.toFixed(2)}`);
    }
    
    return {
      yearsToTarget,
      finalBalance,
      totalContributions,
      totalInterest,
      inflationAdjustedTarget,
      yearlyData,
      steps
    };
  };
  
  // Form submission handlers
  const onLumpSumSubmit = (values: LumpSumFormValues) => {
    try {
      const result = calculateLumpSum(values);
      setLumpSumResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onContributionSubmit = (values: ContributionFormValues) => {
    try {
      const result = calculateContribution(values);
      setContributionResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onTargetSubmit = (values: TargetFormValues) => {
    try {
      const result = calculateTarget(values);
      setTargetResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <TrendingUp className="mr-2 h-8 w-8" /> Investment Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="lumpsum" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="lumpsum">Lump Sum</TabsTrigger>
                <TabsTrigger value="contribution">Regular Contributions</TabsTrigger>
                <TabsTrigger value="target">Target Amount</TabsTrigger>
              </TabsList>
              
              {/* Lump Sum Calculator */}
              <TabsContent value="lumpsum">
                <Card>
                  <CardHeader>
                    <CardTitle>Lump Sum Investment</CardTitle>
                    <CardDescription>
                      Calculate how a one-time investment will grow over time.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...lumpSumForm}>
                      <form onSubmit={lumpSumForm.handleSubmit(onLumpSumSubmit)} className="space-y-6">
                        <FormField
                          control={lumpSumForm.control}
                          name="initialInvestment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Initial Investment</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                                  <Input {...field} type="number" step="100" min="0" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The amount you start with.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={lumpSumForm.control}
                            name="annualReturn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Return (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={lumpSumForm.control}
                            name="years"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Investment Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" min="1" max="100" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={lumpSumForm.control}
                            name="compoundingFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Compounding Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="annually">Annually</SelectItem>
                                    <SelectItem value="semiannually">Semi-annually</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="daily">Daily</SelectItem>
                                    <SelectItem value="continuous">Continuous</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={lumpSumForm.control}
                            name="inflation"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Inflation Rate (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" min="0" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full">Calculate Growth</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Regular Contributions Calculator */}
              <TabsContent value="contribution">
                <Card>
                  <CardHeader>
                    <CardTitle>Regular Contributions</CardTitle>
                    <CardDescription>
                      Calculate growth with regular contributions to your investment.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...contributionForm}>
                      <form onSubmit={contributionForm.handleSubmit(onContributionSubmit)} className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={contributionForm.control}
                            name="initialInvestment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Initial Investment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="100" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={contributionForm.control}
                            name="contribution"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Regular Contribution</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="10" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={contributionForm.control}
                            name="contributionFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contribution Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={contributionForm.control}
                            name="years"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Investment Period (years)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" step="1" min="1" max="100" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={contributionForm.control}
                            name="annualReturn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Return (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={contributionForm.control}
                            name="compoundingFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Compounding Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="annually">Annually</SelectItem>
                                    <SelectItem value="semiannually">Semi-annually</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="daily">Daily</SelectItem>
                                    <SelectItem value="continuous">Continuous</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={contributionForm.control}
                          name="inflation"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Inflation Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Growth</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Target Amount Calculator */}
              <TabsContent value="target">
                <Card>
                  <CardHeader>
                    <CardTitle>Target Amount</CardTitle>
                    <CardDescription>
                      Calculate how long it will take to reach your investment goal.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...targetForm}>
                      <form onSubmit={targetForm.handleSubmit(onTargetSubmit)} className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={targetForm.control}
                            name="initialInvestment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Initial Investment</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="100" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={targetForm.control}
                            name="targetAmount"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Target Amount</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="1000" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={targetForm.control}
                            name="contribution"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Regular Contribution</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3 text-gray-500">$</span>
                                    <Input {...field} type="number" step="10" min="0" className="pl-7" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={targetForm.control}
                            name="contributionFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contribution Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="annually">Annually</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={targetForm.control}
                            name="annualReturn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Annual Return (%)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input {...field} type="number" step="0.1" className="pr-7" />
                                    <span className="absolute right-3 top-3 text-gray-500">%</span>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={targetForm.control}
                            name="compoundingFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Compounding Frequency</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="annually">Annually</SelectItem>
                                    <SelectItem value="semiannually">Semi-annually</SelectItem>
                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                    <SelectItem value="monthly">Monthly</SelectItem>
                                    <SelectItem value="daily">Daily</SelectItem>
                                    <SelectItem value="continuous">Continuous</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={targetForm.control}
                          name="inflation"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Inflation Rate (%)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input {...field} type="number" step="0.1" min="0" className="pr-7" />
                                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Years to Target</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            {/* Lump Sum Results */}
            {activeTab === "lumpsum" && (
              <div className="space-y-6">
                {lumpSumResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Investment Growth Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Initial Investment</p>
                            <p className="text-2xl font-bold">${lumpSumForm.getValues().initialInvestment.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Final Balance</p>
                            <p className="text-2xl font-bold">${lumpSumResult.finalBalance.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${lumpSumResult.totalInterest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Inflation-Adjusted Balance</p>
                            <p className="text-2xl font-bold">${lumpSumResult.inflationAdjustedBalance.toFixed(2)}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Growth</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-5 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Starting Balance</div>
                            <div>Interest</div>
                            <div>Ending Balance</div>
                            <div>Infl. Adjusted</div>
                          </div>
                          
                          {lumpSumResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-5 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.startingBalance.toFixed(2)}</div>
                              <div>${data.interest.toFixed(2)}</div>
                              <div>${data.endingBalance.toFixed(2)}</div>
                              <div>${data.endingBalanceInflationAdjusted!.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {lumpSumResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Lump Sum Investment Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <LineChart className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Growth"</p>
                        <p className="text-sm mt-2">See how a one-time investment can grow over time</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Regular Contributions Results */}
            {activeTab === "contribution" && (
              <div className="space-y-6">
                {contributionResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Investment Growth Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Initial Investment</p>
                            <p className="text-2xl font-bold">${contributionForm.getValues().initialInvestment.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Contributions</p>
                            <p className="text-2xl font-bold">${contributionResult.totalContributions.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${contributionResult.totalInterest.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Final Balance</p>
                            <p className="text-2xl font-bold">${contributionResult.finalBalance.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm font-medium">Inflation-Adjusted Final Balance: ${contributionResult.inflationAdjustedBalance.toFixed(2)}</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Growth</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-6 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Starting</div>
                            <div>Contribution</div>
                            <div>Interest</div>
                            <div>Ending</div>
                            <div>Infl. Adj.</div>
                          </div>
                          
                          {contributionResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-6 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.startingBalance.toFixed(2)}</div>
                              <div>${data.contribution.toFixed(2)}</div>
                              <div>${data.interest.toFixed(2)}</div>
                              <div>${data.endingBalance.toFixed(2)}</div>
                              <div>${data.endingBalanceInflationAdjusted!.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {contributionResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Regular Contributions Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <PiggyBank className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Growth"</p>
                        <p className="text-sm mt-2">See how regular contributions compound over time</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Target Amount Results */}
            {activeTab === "target" && (
              <div className="space-y-6">
                {targetResult ? (
                  <div>
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Years to Target Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Target Amount</p>
                            <p className="text-2xl font-bold">${targetForm.getValues().targetAmount.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Years to Reach Target</p>
                            <p className="text-2xl font-bold">{targetResult.yearsToTarget}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Contributions</p>
                            <p className="text-2xl font-bold">${targetResult.totalContributions.toFixed(2)}</p>
                          </div>
                          
                          <div className="bg-primary/10 p-4 rounded-lg">
                            <p className="text-sm text-gray-500">Total Interest</p>
                            <p className="text-2xl font-bold">${targetResult.totalInterest.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm font-medium">Final Balance: ${targetResult.finalBalance.toFixed(2)}</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="mb-6">
                      <CardHeader>
                        <CardTitle>Year-by-Year Progress</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="border rounded-md divide-y max-h-[300px] overflow-auto">
                          <div className="grid grid-cols-6 gap-2 p-3 font-medium bg-gray-50 sticky top-0 text-xs md:text-sm">
                            <div>Year</div>
                            <div>Starting</div>
                            <div>Contribution</div>
                            <div>Interest</div>
                            <div>Ending</div>
                            <div>Infl. Adj.</div>
                          </div>
                          
                          {targetResult.yearlyData.map((data) => (
                            <div key={data.year} className="grid grid-cols-6 gap-2 p-3 text-xs md:text-sm">
                              <div>{data.year}</div>
                              <div>${data.startingBalance.toFixed(2)}</div>
                              <div>${data.contribution.toFixed(2)}</div>
                              <div>${data.interest.toFixed(2)}</div>
                              <div>${data.endingBalance.toFixed(2)}</div>
                              <div>${data.endingBalanceInflationAdjusted!.toFixed(2)}</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2 pl-5 list-decimal text-sm text-gray-600">
                          {targetResult.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Target Amount Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-12 flex flex-col items-center justify-center text-gray-500">
                        <Sigma className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg">Enter your values and click "Calculate Years to Target"</p>
                        <p className="text-sm mt-2">Find out how long it will take to reach your investment goal</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {/* Educational Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Investment Growth Basics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">The Power of Compound Interest</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Compound interest is often called the "eighth wonder of the world" because it allows your money to grow 
                    exponentially over time. The earlier you start investing, the more time your money has to compound 
                    and grow.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Regular Contributions Matter</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Even small, regular contributions can lead to significant wealth over time. Consistent investing, 
                    regardless of market conditions, can be a powerful strategy called "dollar-cost averaging" which 
                    helps reduce the impact of market volatility.
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Understanding Inflation</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Inflation erodes purchasing power over time, so it's important to consider its impact on your 
                    long-term financial goals. The "real return" of an investment is the nominal return minus the 
                    inflation rate, showing the actual increase in purchasing power.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default InvestmentCalculator;
