import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Calculator, DollarSign, Calendar, Percent } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema with zod
const formSchema = z.object({
  loanAmount: z.coerce.number().positive("Loan amount must be positive"),
  interestRate: z.coerce.number().min(0.1, "Interest rate must be positive").max(25, "Interest rate too high"),
  loanTerm: z.coerce.number().int().min(1, "Loan term must be at least 1 year"),
  paymentFrequency: z.enum(["monthly", "biweekly", "weekly"]),
});

type FormValues = z.infer<typeof formSchema>;

const LoanCalculator: React.FC = () => {
  const { toast } = useToast();
  const [results, setResults] = useState<{
    regularPayment: number;
    totalPayment: number;
    totalInterest: number;
    numberOfPayments: number;
    amortizationSchedule: Array<{
      period: number;
      payment: number;
      principal: number;
      interest: number;
      remainingBalance: number;
    }>;
  } | null>(null);

  // Initialize the form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      loanAmount: 20000,
      interestRate: 5.5,
      loanTerm: 5,
      paymentFrequency: "monthly",
    },
  });

  // Watch form values for real-time updates
  const loanAmount = form.watch('loanAmount');
  const interestRate = form.watch('interestRate');
  const loanTerm = form.watch('loanTerm');
  const paymentFrequency = form.watch('paymentFrequency');

  // Function to calculate loan payments
  const calculateLoan = (values: FormValues) => {
    const principal = values.loanAmount;
    let periodicRate: number;
    let numberOfPayments: number;
    
    switch (values.paymentFrequency) {
      case "weekly":
        periodicRate = values.interestRate / 100 / 52;
        numberOfPayments = values.loanTerm * 52;
        break;
      case "biweekly":
        periodicRate = values.interestRate / 100 / 26;
        numberOfPayments = values.loanTerm * 26;
        break;
      case "monthly":
      default:
        periodicRate = values.interestRate / 100 / 12;
        numberOfPayments = values.loanTerm * 12;
        break;
    }

    // Regular payment formula: P * (r * (1 + r)^n) / ((1 + r)^n - 1)
    let regularPayment = 0;
    if (periodicRate > 0) {
      regularPayment = principal * (periodicRate * Math.pow(1 + periodicRate, numberOfPayments)) / 
        (Math.pow(1 + periodicRate, numberOfPayments) - 1);
    } else {
      regularPayment = principal / numberOfPayments; // If interest rate is 0, simple division
    }
    
    const totalPayment = regularPayment * numberOfPayments;
    const totalInterest = totalPayment - principal;
    
    // Generate amortization schedule
    const amortizationSchedule = [];
    let remainingBalance = principal;
    
    for (let period = 1; period <= Math.min(numberOfPayments, 500); period++) { // Limit to 500 periods for performance
      const interestPayment = remainingBalance * periodicRate;
      const principalPayment = regularPayment - interestPayment;
      remainingBalance -= principalPayment;
      
      amortizationSchedule.push({
        period,
        payment: regularPayment,
        principal: principalPayment,
        interest: interestPayment,
        remainingBalance: Math.max(0, remainingBalance) // Ensure it doesn't go negative due to rounding
      });
    }
    
    return {
      regularPayment,
      totalPayment,
      totalInterest,
      numberOfPayments,
      amortizationSchedule
    };
  };
  
  // Update results in real-time when form values change
  React.useEffect(() => {
    if (form.formState.isValid) {
      const currentValues = form.getValues();
      try {
        const results = calculateLoan(currentValues);
        setResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [loanAmount, interestRate, loanTerm, paymentFrequency, form]);

  const onSubmit = (values: FormValues) => {
    try {
      const results = calculateLoan(values);
      setResults(results);
      toast({
        title: 'Loan calculated',
        description: 'Your loan has been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating your loan.',
        variant: 'destructive',
      });
    }
  };

  // Helper function to format payment frequency as text
  const formatFrequency = (freq: string): string => {
    switch (freq) {
      case "weekly": return "Weekly";
      case "biweekly": return "Bi-weekly";
      case "monthly": return "Monthly";
      default: return freq;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <DollarSign className="mr-2 h-8 w-8" /> Loan Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Form Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calculator className="mr-2 h-5 w-5" />
                Calculate Your Loan
              </CardTitle>
              <CardDescription>
                Enter your loan details to calculate payments and interest.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="loanAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Amount ($)</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                            <Input {...field} type="number" className="pl-10" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="interestRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Interest Rate (%)</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Percent className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                            <Input {...field} type="number" step="0.1" className="pl-10" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="loanTerm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loan Term (Years)</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                              <Input {...field} type="number" className="pl-10" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="paymentFrequency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Frequency</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select frequency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="biweekly">Bi-weekly</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit" className="w-full">Calculate</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Results Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="mr-2 h-5 w-5" />
                Loan Summary
              </CardTitle>
              <CardDescription>
                Based on your inputs, here's your loan breakdown.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results ? (
                <div className="space-y-6">
                  <div className="text-center p-6 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-500">{formatFrequency(paymentFrequency)} Payment</div>
                    <div className="text-4xl font-bold text-primary">
                      ${results.regularPayment.toFixed(2)}
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Loan Amount</div>
                      <div className="text-xl font-semibold">${loanAmount.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Interest Rate</div>
                      <div className="text-xl font-semibold">{interestRate.toFixed(2)}%</div>
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Total Payments</div>
                      <div className="text-xl font-semibold">${results.totalPayment.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Total Interest</div>
                      <div className="text-xl font-semibold">${results.totalInterest.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Payment Schedule</h3>
                    <div className="text-sm text-gray-600">
                      <div className="flex justify-between mb-1">
                        <span>Number of Payments:</span>
                        <span>{results.numberOfPayments}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span>Payment Frequency:</span>
                        <span>{formatFrequency(paymentFrequency)}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Amortization Table Preview */}
                  <div>
                    <h3 className="font-medium text-gray-800 mb-2">Amortization Preview</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Payment</th>
                            <th className="text-right py-2">Amount</th>
                            <th className="text-right py-2">Principal</th>
                            <th className="text-right py-2">Interest</th>
                            <th className="text-right py-2">Balance</th>
                          </tr>
                        </thead>
                        <tbody>
                          {results.amortizationSchedule.slice(0, 5).map((payment) => (
                            <tr key={payment.period} className="border-b">
                              <td className="py-2">{payment.period}</td>
                              <td className="text-right">${payment.payment.toFixed(2)}</td>
                              <td className="text-right">${payment.principal.toFixed(2)}</td>
                              <td className="text-right">${payment.interest.toFixed(2)}</td>
                              <td className="text-right">${payment.remainingBalance.toFixed(2)}</td>
                            </tr>
                          ))}
                          {results.amortizationSchedule.length > 5 && (
                            <tr>
                              <td colSpan={5} className="text-center py-2 text-gray-500">
                                ... {results.numberOfPayments - 5} more payments
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 text-gray-500">
                  Enter your loan details to see the results here.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Loan Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our loan calculator uses the standard amortization formula to calculate your regular payments:
                </p>
                <div className="bg-gray-50 p-4 rounded font-mono text-sm">
                  P = L × (r × (1 + r)^n) / ((1 + r)^n - 1)
                </div>
                <p>Where:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>P</strong> = Regular payment amount</li>
                  <li><strong>L</strong> = Loan amount (principal)</li>
                  <li><strong>r</strong> = Periodic interest rate (annual rate divided by payment periods per year)</li>
                  <li><strong>n</strong> = Total number of payments</li>
                </ul>
                <p className="text-gray-500">Note: This calculator provides estimates only and does not account for possible loan fees or variable interest rates.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default LoanCalculator;
