import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Percent, Calculator, TrendingUp } from 'lucide-react';
import { Link } from 'wouter';

// Define the rate calculator form schema
const rateSchema = z.object({
  principal: z.coerce.number().positive("Principal must be positive"),
  futureValue: z.coerce.number().positive("Future value must be positive"),
  periods: z.coerce.number().positive("Number of periods must be positive"),
  compoundingFrequency: z.enum(["annually", "semiannually", "quarterly", "monthly", "daily"]),
  calculationType: z.enum(["effective", "nominal"]),
});

type RateFormValues = z.infer<typeof rateSchema>;

// Define the loan rate calculator form schema
const loanRateSchema = z.object({
  loanAmount: z.coerce.number().positive("Loan amount must be positive"),
  payment: z.coerce.number().positive("Payment amount must be positive"),
  loanTerm: z.coerce.number().positive("Loan term must be positive"),
  paymentFrequency: z.enum(["monthly", "biweekly", "weekly"]),
});

type LoanRateFormValues = z.infer<typeof loanRateSchema>;

const InterestRateCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("investment");
  const [result, setResult] = useState<{
    interestRate: number;
    effectiveRate: number;
    steps: string[];
  } | null>(null);
  
  // Initialize form for rate calculation
  const rateForm = useForm<RateFormValues>({
    resolver: zodResolver(rateSchema),
    defaultValues: {
      principal: 1000,
      futureValue: 1500,
      periods: 5,
      compoundingFrequency: "annually",
      calculationType: "effective",
    },
  });
  
  // Initialize form for loan rate calculation
  const loanRateForm = useForm<LoanRateFormValues>({
    resolver: zodResolver(loanRateSchema),
    defaultValues: {
      loanAmount: 10000,
      payment: 215,
      loanTerm: 60,
      paymentFrequency: "monthly",
    },
  });

  // Calculate investment interest rate
  const calculateInterestRate = (values: RateFormValues) => {
    const { principal, futureValue, periods, compoundingFrequency, calculationType } = values;
    
    const steps: string[] = [];
    
    // Get the number of compounding periods per year
    let compoundingsPerYear: number;
    switch (compoundingFrequency) {
      case "annually":
        compoundingsPerYear = 1;
        break;
      case "semiannually":
        compoundingsPerYear = 2;
        break;
      case "quarterly":
        compoundingsPerYear = 4;
        break;
      case "monthly":
        compoundingsPerYear = 12;
        break;
      case "daily":
        compoundingsPerYear = 365;
        break;
      default:
        compoundingsPerYear = 1;
    }
    
    steps.push(`Principal (P): ${principal.toFixed(2)}`);
    steps.push(`Future Value (FV): ${futureValue.toFixed(2)}`);
    steps.push(`Time Periods (t): ${periods} years`);
    steps.push(`Compounding Frequency: ${compoundingFrequency} (${compoundingsPerYear} times per year)`);
    
    // Calculate total number of compounding periods
    const n = compoundingsPerYear * periods;
    steps.push(`Total Number of Compounding Periods (n): ${compoundingsPerYear} × ${periods} = ${n}`);
    
    // Calculate the compound interest rate per period
    // Using the formula: FV = P(1 + r)^n
    // Solving for r: r = (FV/P)^(1/n) - 1
    const ratePerPeriod = Math.pow(futureValue / principal, 1 / n) - 1;
    steps.push(`Rate per compounding period (r): (${futureValue} / ${principal})^(1/${n}) - 1 = ${(ratePerPeriod * 100).toFixed(6)}%`);
    
    // Calculate the nominal annual rate
    const nominalRate = ratePerPeriod * compoundingsPerYear;
    steps.push(`Nominal Annual Rate: ${(ratePerPeriod * 100).toFixed(6)}% × ${compoundingsPerYear} = ${(nominalRate * 100).toFixed(4)}%`);
    
    // Calculate the effective annual rate
    const effectiveRate = Math.pow(1 + ratePerPeriod, compoundingsPerYear) - 1;
    steps.push(`Effective Annual Rate: (1 + ${(ratePerPeriod * 100).toFixed(6)}%)^${compoundingsPerYear} - 1 = ${(effectiveRate * 100).toFixed(4)}%`);
    
    // Return the requested rate type
    if (calculationType === "nominal") {
      steps.push(`Requested Rate Type: Nominal Annual Rate`);
      return {
        interestRate: nominalRate,
        effectiveRate: effectiveRate,
        steps
      };
    } else {
      steps.push(`Requested Rate Type: Effective Annual Rate`);
      return {
        interestRate: effectiveRate,
        effectiveRate: effectiveRate,
        steps
      };
    }
  };

  // Calculate loan interest rate using iterative approach
  const calculateLoanRate = (values: LoanRateFormValues) => {
    const { loanAmount, payment, loanTerm, paymentFrequency } = values;
    
    const steps: string[] = [];
    
    steps.push(`Loan Amount: ${loanAmount.toFixed(2)}`);
    steps.push(`Payment Amount: ${payment.toFixed(2)}`);
    steps.push(`Loan Term: ${loanTerm} ${paymentFrequency === "monthly" ? "months" : paymentFrequency === "biweekly" ? "bi-weekly payments" : "weekly payments"}`);
    
    // Convert payment frequency to number of payments per year
    let paymentsPerYear: number;
    switch (paymentFrequency) {
      case "monthly":
        paymentsPerYear = 12;
        break;
      case "biweekly":
        paymentsPerYear = 26;
        break;
      case "weekly":
        paymentsPerYear = 52;
        break;
      default:
        paymentsPerYear = 12;
    }
    
    // Calculate total number of payments
    const numberOfPayments = loanTerm;
    steps.push(`Total Number of Payments: ${numberOfPayments}`);
    
    // Calculate loan term in years
    const loanTermYears = loanTerm / paymentsPerYear;
    steps.push(`Loan Term in Years: ${loanTerm} / ${paymentsPerYear} = ${loanTermYears.toFixed(2)} years`);
    
    // Check if payment is sufficient to cover the loan
    const totalPayments = payment * numberOfPayments;
    if (totalPayments <= loanAmount) {
      steps.push(`Error: The payment amount is insufficient to repay the loan with interest.`);
      steps.push(`Total Payments (${payment} × ${numberOfPayments} = ${totalPayments}) must be greater than the Loan Amount (${loanAmount}).`);
      throw new Error("Payment amount is too low to calculate an interest rate. The total of all payments must exceed the loan amount.");
    }
    
    steps.push(`Using iterative approach to find the interest rate...`);
    
    // Use iterative approach to find the interest rate
    // We'll try different rates until we find one that gives the correct payment amount
    let rate = 0.1; // Start with a 10% guess
    let minRate = 0;
    let maxRate = 1; // 100%
    const maxIterations = 100;
    const tolerance = 0.0001; // Acceptable error in payment amount
    
    let calculatedPayment: number;
    let iteration = 0;
    
    // Newton-Raphson method for finding interest rate
    while (iteration < maxIterations) {
      // Calculate payment at current rate
      const ratePerPeriod = rate / paymentsPerYear;
      
      // Calculate present value factor
      const pvFactor = (Math.pow(1 + ratePerPeriod, numberOfPayments) - 1) / (ratePerPeriod * Math.pow(1 + ratePerPeriod, numberOfPayments));
      
      // Calculate payment using amortization formula
      calculatedPayment = loanAmount / pvFactor;
      
      // Check if we're close enough
      const difference = calculatedPayment - payment;
      if (Math.abs(difference) < tolerance) {
        break;
      }
      
      // Adjust rate based on whether payment is too high or too low
      if (difference > 0) {
        maxRate = rate;
        rate = (minRate + rate) / 2;
      } else {
        minRate = rate;
        rate = (rate + maxRate) / 2;
      }
      
      iteration++;
    }
    
    steps.push(`Found approximate interest rate after ${iteration} iterations.`);
    
    // Convert to annual rates
    const nominalRate = rate;
    steps.push(`Nominal Annual Interest Rate: ${(nominalRate * 100).toFixed(4)}%`);
    
    // Calculate effective annual rate
    const effectiveRate = Math.pow(1 + rate / paymentsPerYear, paymentsPerYear) - 1;
    steps.push(`Effective Annual Interest Rate: ${(effectiveRate * 100).toFixed(4)}%`);
    
    // Calculate total interest paid
    const totalInterest = (payment * numberOfPayments) - loanAmount;
    steps.push(`Total Interest Paid: ${payment} × ${numberOfPayments} - ${loanAmount} = ${totalInterest.toFixed(2)}`);
    
    return {
      interestRate: nominalRate,
      effectiveRate: effectiveRate,
      steps
    };
  };

  // Form submission handlers
  const onRateSubmit = (values: RateFormValues) => {
    try {
      const result = calculateInterestRate(values);
      setResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };
  
  const onLoanRateSubmit = (values: LoanRateFormValues) => {
    try {
      const result = calculateLoanRate(values);
      setResult(result);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(error.message);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Percent className="mr-2 h-8 w-8" /> Interest Rate Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="investment" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="investment">Investment Rate</TabsTrigger>
                <TabsTrigger value="loan">Loan Rate</TabsTrigger>
              </TabsList>
              
              {/* Investment Rate Tab */}
              <TabsContent value="investment">
                <Card>
                  <CardHeader>
                    <CardTitle>Calculate Investment Interest Rate</CardTitle>
                    <CardDescription>
                      Find the interest rate for an investment given the initial and final amounts.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...rateForm}>
                      <form onSubmit={rateForm.handleSubmit(onRateSubmit)} className="space-y-6">
                        <FormField
                          control={rateForm.control}
                          name="principal"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Principal Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-2 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="1" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The initial investment amount.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={rateForm.control}
                          name="futureValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Future Value</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-2 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="1" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The final value of the investment.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={rateForm.control}
                          name="periods"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Time Period (Years)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.5" min="0.5" />
                              </FormControl>
                              <FormDescription>
                                The duration of the investment in years.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={rateForm.control}
                          name="compoundingFrequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Compounding Frequency</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-wrap gap-4"
                                >
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="annually" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Annually</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="semiannually" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Semi-annually</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="quarterly" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Quarterly</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="monthly" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Monthly</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="daily" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Daily</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                How often the interest is compounded.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={rateForm.control}
                          name="calculationType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Rate Type</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="nominal" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Nominal Rate</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="effective" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Effective Rate</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                Nominal rate is the stated annual rate, while effective rate includes the effect of compounding.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Interest Rate</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Loan Rate Tab */}
              <TabsContent value="loan">
                <Card>
                  <CardHeader>
                    <CardTitle>Calculate Loan Interest Rate</CardTitle>
                    <CardDescription>
                      Find the interest rate for a loan given the amount, payment, and term.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...loanRateForm}>
                      <form onSubmit={loanRateForm.handleSubmit(onLoanRateSubmit)} className="space-y-6">
                        <FormField
                          control={loanRateForm.control}
                          name="loanAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Loan Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-2 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="1" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The original amount borrowed.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loanRateForm.control}
                          name="payment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Payment Amount</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <span className="absolute left-3 top-2 text-gray-500">$</span>
                                  <Input {...field} type="number" step="0.01" min="1" className="pl-7" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                The amount of each periodic payment.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loanRateForm.control}
                          name="loanTerm"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Number of Payments</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="1" min="1" />
                              </FormControl>
                              <FormDescription>
                                Total number of payments (e.g., 60 for a 5-year loan with monthly payments).
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loanRateForm.control}
                          name="paymentFrequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Payment Frequency</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-wrap gap-4"
                                >
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="monthly" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Monthly</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="biweekly" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Bi-weekly</FormLabel>
                                  </FormItem>
                                  
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="weekly" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Weekly</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                How often payments are made.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full">Calculate Interest Rate</Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Interest Rate Results</CardTitle>
                <CardDescription>
                  Calculated interest rates and details.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {result ? (
                  <div className="space-y-6">
                    <div className="p-6 bg-primary/10 rounded-lg text-center">
                      <h3 className="text-sm text-gray-500 mb-2">Interest Rate</h3>
                      <p className="text-4xl font-bold">{(result.interestRate * 100).toFixed(2)}%</p>
                      <p className="text-sm text-gray-500 mt-2">
                        {activeTab === "investment" ? 
                          (rateForm.getValues().calculationType === "nominal" ? "Nominal Annual Rate" : "Effective Annual Rate") : 
                          "Annual Percentage Rate (APR)"}
                      </p>
                    </div>
                    
                    {activeTab === "investment" && rateForm.getValues().calculationType === "nominal" && (
                      <div className="p-4 bg-blue-50 rounded-lg text-center">
                        <h3 className="text-sm text-blue-700 mb-1">Effective Annual Rate</h3>
                        <p className="text-xl font-semibold text-blue-900">{(result.effectiveRate * 100).toFixed(2)}%</p>
                        <p className="text-xs text-blue-600 mt-1">Includes the effect of compounding</p>
                      </div>
                    )}
                    
                    {activeTab === "loan" && (
                      <div className="p-4 bg-blue-50 rounded-lg text-center">
                        <h3 className="text-sm text-blue-700 mb-1">Effective Annual Rate (APY)</h3>
                        <p className="text-xl font-semibold text-blue-900">{(result.effectiveRate * 100).toFixed(2)}%</p>
                        <p className="text-xs text-blue-600 mt-1">Accounting for payment frequency</p>
                      </div>
                    )}
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-3">Calculation Steps</h3>
                      <ol className="list-decimal pl-5 space-y-1 text-sm">
                        {result.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 h-full flex flex-col items-center justify-center text-gray-500">
                    <Calculator className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-lg">Enter your details and click "Calculate Interest Rate"</p>
                    <p className="text-sm mt-2">Results will appear here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Interest Rate Calculations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                Interest rates are essential for understanding the cost of borrowing money or the return on investments. 
                This calculator helps you determine interest rates for various financial scenarios.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Investment Interest Rates</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Nominal Annual Rate:</strong> The stated interest rate without accounting for compounding. 
                      It's the annual rate that, when divided by the number of compounding periods per year, equals the periodic interest rate.
                    </li>
                    <li>
                      <strong>Effective Annual Rate:</strong> The actual interest rate earned or paid over a year, 
                      taking into account the effect of compounding. This is also known as Annual Percentage Yield (APY).
                    </li>
                    <li>
                      <strong>Compound Interest Formula:</strong> FV = P(1 + r/n)^(nt), where FV is the future value, 
                      P is the principal, r is the annual interest rate, n is the number of compounding periods per year, 
                      and t is the time in years.
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Loan Interest Rates</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Annual Percentage Rate (APR):</strong> The yearly cost of a loan, including interest and fees, 
                      expressed as a percentage. It doesn't account for compounding.
                    </li>
                    <li>
                      <strong>Amortization:</strong> The process of gradually paying off a loan through regular payments 
                      that include both principal and interest.
                    </li>
                    <li>
                      <strong>Loan Payment Formula:</strong> PMT = P × r × (1 + r)^n / ((1 + r)^n - 1), where PMT is the payment amount, 
                      P is the loan amount, r is the periodic interest rate, and n is the number of payments.
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4">
                <h3 className="text-lg font-medium text-gray-900">The Impact of Compound Interest</h3>
                <p className="text-sm mt-1">
                  Compound interest has a significant impact on long-term investments and loans. 
                  The more frequently interest is compounded, the higher the effective annual rate will be compared to the nominal rate. 
                  This effect becomes more pronounced over longer time periods, leading to the "magic" of compound interest for investments 
                  and the potential burden of high-interest debt.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default InterestRateCalculator;
