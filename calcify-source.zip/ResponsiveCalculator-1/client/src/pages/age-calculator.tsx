import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Calendar as CalendarIcon, Cake } from 'lucide-react';
import { Link } from 'wouter';
import { format, differenceInYears, differenceInMonths, differenceInDays, isValid } from 'date-fns';
import { cn } from '@/lib/utils';

// Define the form schema with zod
const formSchema = z.object({
  birthDate: z.date({
    required_error: "Please select your birth date.",
  }),
  todayDate: z.date({
    required_error: "Please select today's date.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const AgeCalculator: React.FC = () => {
  const { toast } = useToast();
  const [results, setResults] = useState<{
    years: number;
    months: number;
    days: number;
    totalMonths: number;
    totalWeeks: number;
    totalDays: number;
  } | null>(null);

  // Initialize the form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      birthDate: new Date(),
      todayDate: new Date(),
    },
  });

  // Function to calculate age
  const calculateAge = (values: FormValues) => {
    const birthDate = values.birthDate;
    const todayDate = values.todayDate;
    
    if (!isValid(birthDate) || !isValid(todayDate)) {
      throw new Error("Invalid date entered");
    }
    
    if (todayDate < birthDate) {
      throw new Error("Today's date cannot be before birth date");
    }
    
    const years = differenceInYears(todayDate, birthDate);
    
    // Calculate remaining months after subtracting full years
    const birthDatePlusYears = new Date(birthDate);
    birthDatePlusYears.setFullYear(birthDatePlusYears.getFullYear() + years);
    const months = differenceInMonths(todayDate, birthDatePlusYears);
    
    // Calculate remaining days after subtracting full years and months
    const birthDatePlusYearsAndMonths = new Date(birthDatePlusYears);
    birthDatePlusYearsAndMonths.setMonth(birthDatePlusYearsAndMonths.getMonth() + months);
    const days = differenceInDays(todayDate, birthDatePlusYearsAndMonths);
    
    // Calculate total values
    const totalMonths = differenceInMonths(todayDate, birthDate);
    const totalDays = differenceInDays(todayDate, birthDate);
    const totalWeeks = Math.floor(totalDays / 7);
    
    return {
      years,
      months,
      days,
      totalMonths,
      totalWeeks,
      totalDays
    };
  };

  // Update results when form values change
  React.useEffect(() => {
    if (form.formState.isValid) {
      const currentValues = form.getValues();
      try {
        const results = calculateAge(currentValues);
        setResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
        // Don't show toast on initial load or for validation errors
      }
    }
  }, [form.watch('birthDate'), form.watch('todayDate'), form]);

  const onSubmit = (values: FormValues) => {
    try {
      const results = calculateAge(values);
      setResults(results);
      toast({
        title: 'Age calculated',
        description: 'Your age has been calculated successfully.',
      });
    } catch (error) {
      let errorMessage = 'There was an error calculating your age.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Calculation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Cake className="mr-2 h-8 w-8" /> Age Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Form Card */}
          <Card>
            <CardHeader>
              <CardTitle>Calculate Your Age</CardTitle>
              <CardDescription>
                Enter your birth date and a target date to calculate your age.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="birthDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Birth Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) => date > new Date() }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="todayDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Today's Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full">Calculate Age</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Results Card */}
          <Card>
            <CardHeader>
              <CardTitle>Age Results</CardTitle>
              <CardDescription>
                Your age in years, months, days, and other units.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results ? (
                <div className="space-y-6">
                  <div className="text-center p-6 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-500">Your Age</div>
                    <div className="text-4xl font-bold text-primary">
                      {results.years} years, {results.months} months, {results.days} days
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Total Months</div>
                      <div className="text-xl font-semibold">{results.totalMonths} months</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Total Weeks</div>
                      <div className="text-xl font-semibold">{results.totalWeeks} weeks</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Total Days</div>
                      <div className="text-xl font-semibold">{results.totalDays} days</div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Next Birthday</h3>
                    <div className="text-sm text-gray-600">
                      {(() => {
                        const birthDate = form.getValues().birthDate;
                        const todayDate = form.getValues().todayDate;
                        
                        // Calculate next birthday
                        const nextBirthdayYear = results.months > 0 || (results.months === 0 && results.days > 0) 
                          ? todayDate.getFullYear() + 1 
                          : todayDate.getFullYear();
                          
                        const nextBirthday = new Date(birthDate);
                        nextBirthday.setFullYear(nextBirthdayYear);
                        
                        // If next birthday is already past this year, add a year
                        if (nextBirthday < todayDate) {
                          nextBirthday.setFullYear(nextBirthdayYear + 1);
                        }
                        
                        // Calculate days until next birthday
                        const daysUntilBirthday = differenceInDays(nextBirthday, todayDate);
                        
                        return (
                          <>
                            <div className="flex justify-between mb-1">
                              <span>Next Birthday Date:</span>
                              <span>{format(nextBirthday, "PPP")}</span>
                            </div>
                            <div className="flex justify-between mb-1">
                              <span>Days Until Next Birthday:</span>
                              <span>{daysUntilBirthday} days</span>
                            </div>
                          </>
                        );
                      })()} 
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 text-gray-500">
                  Enter your birth date to see your age breakdown here.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Age Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our age calculator provides you with accurate age calculations based on your birth date and any target date you choose. Here's how it works:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Years, Months, Days</strong>: We calculate the exact years, then remaining months, and finally remaining days between the two dates.</li>
                  <li><strong>Total Values</strong>: We also convert your age into total months, weeks, and days for additional perspective.</li>
                  <li><strong>Next Birthday</strong>: We calculate your upcoming birthday and how many days you have to wait.</li>
                </ul>
                <p>This calculator accounts for leap years and varying month lengths to give you the most accurate age calculation possible.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AgeCalculator;
