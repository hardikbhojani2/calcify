import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Baby, Calendar as CalendarIcon, CalendarDays } from 'lucide-react';
import { Link } from 'wouter';
import { format, addDays, subDays, addWeeks, differenceInDays, differenceInWeeks } from 'date-fns';

// Define the form schema
const dueDateSchema = z.object({
  calculationMethod: z.enum(["lmp", "conception", "ultrasound", "ivf"]),
  lastPeriodDate: z.date({
    required_error: "Please select a date",
  }).optional(),
  conceptionDate: z.date({
    required_error: "Please select a date",
  }).optional(),
  ultrasoundDate: z.date({
    required_error: "Please select a date",
  }).optional(),
  ultrasoundWeeks: z.coerce.number().int().min(0, "Must be at least 0").max(40, "Must be at most 40").optional(),
  ultrasoundDays: z.coerce.number().int().min(0, "Must be at least 0").max(6, "Must be at most 6").optional(),
  ivfTransferDate: z.date({
    required_error: "Please select a date",
  }).optional(),
  ivfDayNumber: z.coerce.number().int().min(2, "Must be at least 2").max(6, "Must be at most 6").default(3),
  cycleLength: z.coerce.number().int().min(20, "Cycle length must be at least 20 days").max(45, "Cycle length must be at most 45 days").default(28),
}).refine((data) => {
  if (data.calculationMethod === "lmp") {
    return data.lastPeriodDate !== undefined;
  }
  if (data.calculationMethod === "conception") {
    return data.conceptionDate !== undefined;
  }
  if (data.calculationMethod === "ultrasound") {
    return data.ultrasoundDate !== undefined && 
           data.ultrasoundWeeks !== undefined && 
           data.ultrasoundDays !== undefined;
  }
  if (data.calculationMethod === "ivf") {
    return data.ivfTransferDate !== undefined && 
           data.ivfDayNumber !== undefined;
  }
  return false;
}, {
  message: "Please provide the required information for your selected calculation method",
  path: ["calculationMethod"],
});

type FormValues = z.infer<typeof dueDateSchema>;

const DueDateCalculator: React.FC = () => {
  const [dueDate, setDueDate] = useState<Date | null>(null);
  const [conceptDate, setConceptDate] = useState<Date | null>(null);
  const [calculationDetails, setCalculationDetails] = useState<string>("");
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(dueDateSchema),
    defaultValues: {
      calculationMethod: "lmp",
      cycleLength: 28,
      ivfDayNumber: 3,
    },
  });

  // Watch the calculation method to show/hide relevant fields
  const calculationMethod = form.watch("calculationMethod");

  // Calculate due date based on different methods
  const calculateDueDate = (values: FormValues) => {
    let estimated: Date | null = null;
    let conception: Date | null = null;
    let details = "";
    
    switch (values.calculationMethod) {
      case "lmp":
        if (values.lastPeriodDate) {
          // Standard calculation: LMP + 280 days (40 weeks)
          estimated = addDays(values.lastPeriodDate, 280);
          
          // Estimate conception date (approximately 2 weeks after LMP for 28-day cycle)
          const ovulationDay = values.cycleLength - 14;
          conception = addDays(values.lastPeriodDate, ovulationDay);
          
          details = `Based on your last menstrual period (${format(values.lastPeriodDate, "MMMM d, yyyy")}), ` +
                   `with a ${values.cycleLength}-day cycle, your estimated due date is ${format(estimated, "MMMM d, yyyy")}.`;
        }
        break;
        
      case "conception":
        if (values.conceptionDate) {
          // Conception date + 266 days (38 weeks)
          estimated = addDays(values.conceptionDate, 266);
          conception = values.conceptionDate;
          
          details = `Based on your conception date (${format(values.conceptionDate, "MMMM d, yyyy")}), ` +
                   `your estimated due date is ${format(estimated, "MMMM d, yyyy")}.`;
        }
        break;
        
      case "ultrasound":
        if (values.ultrasoundDate && values.ultrasoundWeeks !== undefined && values.ultrasoundDays !== undefined) {
          // Calculate how many days pregnant at ultrasound
          const daysPregnant = (values.ultrasoundWeeks * 7) + values.ultrasoundDays;
          
          // Calculate LMP by subtracting days pregnant from ultrasound date
          const lmpFromUltrasound = subDays(values.ultrasoundDate, daysPregnant);
          
          // Calculate due date: LMP + 280 days
          estimated = addDays(lmpFromUltrasound, 280);
          
          // Estimate conception
          conception = addDays(lmpFromUltrasound, 14); // Assuming 28-day cycle
          
          details = `Based on your ultrasound on ${format(values.ultrasoundDate, "MMMM d, yyyy")} ` +
                   `showing ${values.ultrasoundWeeks} weeks and ${values.ultrasoundDays} days, ` +
                   `your estimated due date is ${format(estimated, "MMMM d, yyyy")}.`;
        }
        break;
        
      case "ivf":
        if (values.ivfTransferDate && values.ivfDayNumber) {
          // For IVF, calculate days from fertilization to transfer
          const daysFromFertilizationToTransfer = values.ivfDayNumber - 1;
          
          // Fertilization day
          const fertilizationDate = subDays(values.ivfTransferDate, daysFromFertilizationToTransfer);
          
          // Due date is fertilization date + 266 days
          estimated = addDays(fertilizationDate, 266);
          
          // Conception is the fertilization date for IVF
          conception = fertilizationDate;
          
          details = `Based on your IVF transfer date (${format(values.ivfTransferDate, "MMMM d, yyyy")}) ` +
                   `with a day ${values.ivfDayNumber} embryo, ` +
                   `your estimated due date is ${format(estimated, "MMMM d, yyyy")}.`;
        }
        break;
    }
    
    return { estimated, conception, details };
  };

  // Handler for form submission
  const onSubmit = (values: FormValues) => {
    const result = calculateDueDate(values);
    setDueDate(result.estimated);
    setConceptDate(result.conception);
    setCalculationDetails(result.details);
  };

  // Calculate weeks pregnant if due date is set
  const calculateCurrentProgress = () => {
    if (!dueDate || !conceptDate) return null;
    
    const today = new Date();
    
    // Estimate LMP (conception date minus 2 weeks)
    const lmp = subDays(conceptDate, 14);
    
    // Calculate days pregnant from LMP
    const daysSinceLMP = differenceInDays(today, lmp);
    
    // Calculate weeks and days
    const weeks = Math.floor(daysSinceLMP / 7);
    const days = daysSinceLMP % 7;
    
    // Calculate days remaining until due date
    const daysRemaining = differenceInDays(dueDate, today);
    const weeksRemaining = Math.floor(daysRemaining / 7);
    const remainingDays = daysRemaining % 7;
    
    return {
      weeks,
      days,
      daysRemaining,
      weeksRemaining,
      remainingDays
    };
  };

  const progress = calculateCurrentProgress();

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <CalendarDays className="mr-2 h-8 w-8" /> Due Date Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Your Due Date</CardTitle>
              <CardDescription>
                Estimate when your baby will arrive based on different calculation methods.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="calculationMethod"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Calculation Method</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="lmp" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                Last Menstrual Period (LMP)
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="conception" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                Known Conception Date
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="ultrasound" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                Ultrasound Dating
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="ivf" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                IVF Transfer Date
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Separator />
                  
                  {/* Conditional fields based on calculation method */}
                  {calculationMethod === "lmp" && (
                    <>
                      <FormField
                        control={form.control}
                        name="lastPeriodDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>First Day of Last Period</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The first day of your most recent menstrual period.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="cycleLength"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Average Cycle Length</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} min="20" max="45" />
                            </FormControl>
                            <FormDescription>
                              Average number of days from the first day of one period to the first day of the next.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}
                  
                  {calculationMethod === "conception" && (
                    <FormField
                      control={form.control}
                      name="conceptionDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Conception Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={"w-full pl-3 text-left font-normal"}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormDescription>
                            The date you believe conception occurred.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  {calculationMethod === "ultrasound" && (
                    <>
                      <FormField
                        control={form.control}
                        name="ultrasoundDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Ultrasound Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The date of your dating ultrasound.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="ultrasoundWeeks"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Weeks</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} min="0" max="40" />
                              </FormControl>
                              <FormDescription>
                                Weeks as measured by ultrasound.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="ultrasoundDays"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Days</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} min="0" max="6" />
                              </FormControl>
                              <FormDescription>
                                Additional days (0-6).
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </>
                  )}
                  
                  {calculationMethod === "ivf" && (
                    <>
                      <FormField
                        control={form.control}
                        name="ivfTransferDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Embryo Transfer Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The date of your embryo transfer.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="ivfDayNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Embryo Age at Transfer</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={(value) => field.onChange(parseInt(value))}
                                defaultValue={field.value.toString()}
                                className="flex space-x-4"
                              >
                                <FormItem className="flex items-center space-x-1 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="3" />
                                  </FormControl>
                                  <FormLabel className="font-normal">
                                    Day 3
                                  </FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-1 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="5" />
                                  </FormControl>
                                  <FormLabel className="font-normal">
                                    Day 5 (Blastocyst)
                                  </FormLabel>
                                </FormItem>
                              </RadioGroup>
                            </FormControl>
                            <FormDescription>
                              The day of embryo development at transfer.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}
                  
                  <Button type="submit" className="w-full">Calculate Due Date</Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Your Due Date Results</CardTitle>
              <CardDescription>
                Estimated due date and pregnancy information based on your input.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {dueDate ? (
                <div className="space-y-6">
                  <div className="p-6 bg-primary/10 rounded-lg text-center">
                    <h3 className="text-sm text-gray-500 mb-1">Estimated Due Date</h3>
                    <p className="text-3xl font-bold">{format(dueDate, "MMMM d, yyyy")}</p>
                  </div>
                  
                  <p className="text-gray-600">{calculationDetails}</p>
                  
                  {progress && progress.weeks >= 0 && (
                    <div className="space-y-4 mt-6">
                      <Separator />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-primary/10 p-4 rounded-lg text-center">
                          <p className="text-sm text-gray-500 mb-1">Current Progress</p>
                          <p className="text-xl font-bold">
                            {progress.weeks} weeks, {progress.days} days
                          </p>
                        </div>
                        
                        <div className="bg-primary/10 p-4 rounded-lg text-center">
                          <p className="text-sm text-gray-500 mb-1">Time Remaining</p>
                          <p className="text-xl font-bold">
                            {progress.weeksRemaining} weeks, {progress.remainingDays} days
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative pt-6">
                        <div className="absolute top-0 left-0 w-full h-2 bg-gray-200 rounded-full">
                          <div 
                            className="absolute top-0 left-0 h-2 bg-primary rounded-full" 
                            style={{ width: `${Math.min((progress.weeks / 40) * 100, 100)}%` }}
                          ></div>
                        </div>
                        
                        <div className="flex justify-between mt-4 text-xs text-gray-500">
                          <span>First Trimester</span>
                          <span>Second Trimester</span>
                          <span>Third Trimester</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Baby className="h-16 w-16 mx-auto text-gray-300 mb-6" />
                  <h3 className="text-xl font-medium mb-2">No Calculation Yet</h3>
                  <p className="text-gray-500 max-w-md mx-auto">
                    Fill out the form with your information to calculate your estimated due date.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Due Date Calculation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                Due date calculators provide an estimated date of delivery (EDD) based on different calculation methods. 
                It's important to remember that only about 5% of babies are born exactly on their due date, and
                it's normal to deliver 1-2 weeks before or after.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Calculation Methods</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Last Menstrual Period (LMP):</strong> The most common method, adding 280 days (40 weeks) to the
                      first day of your last period. This assumes a 28-day cycle with ovulation around day 14.
                    </li>
                    <li>
                      <strong>Conception Date:</strong> Adding 266 days (38 weeks) to the date of conception. This is more
                      accurate if you know when conception occurred.
                    </li>
                    <li>
                      <strong>Ultrasound Dating:</strong> Based on measurements taken during an ultrasound, which can be more
                      accurate, especially in the first trimester.
                    </li>
                    <li>
                      <strong>IVF Transfer:</strong> For IVF pregnancies, calculated based on the embryo transfer date and the
                      age of the embryo at transfer.
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Pregnancy Timeline</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li><strong>First Trimester:</strong> Weeks 1-13</li>
                    <li><strong>Second Trimester:</strong> Weeks 14-26</li>
                    <li><strong>Third Trimester:</strong> Weeks 27-40+</li>
                    <li><strong>Full Term:</strong> 39-40 weeks</li>
                    <li><strong>Early Term:</strong> 37-38 weeks</li>
                    <li><strong>Late Term:</strong> 41 weeks</li>
                    <li><strong>Post Term:</strong> 42 weeks or more</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg mt-6">
                <h3 className="text-lg font-medium text-blue-800 mb-2">Important Note</h3>
                <p className="text-sm text-blue-700">
                  This calculator provides estimates only. For accurate dating and pregnancy care, consult with a healthcare provider. 
                  An ultrasound in early pregnancy provides the most accurate due date estimation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default DueDateCalculator;
