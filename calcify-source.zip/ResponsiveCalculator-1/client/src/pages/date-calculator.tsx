import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Calendar as CalendarIcon, Plus, Calendar as CalendarIconSolid } from 'lucide-react';
import { Link } from 'wouter';
import { format, differenceInDays, differenceInWeeks, differenceInMonths, differenceInYears, addDays, addWeeks, addMonths, addYears, isValid } from 'date-fns';
import { cn } from '@/lib/utils';

// Define the form schema with zod for date difference
const dateDifferenceSchema = z.object({
  startDate: z.date({
    required_error: "Please select a start date.",
  }),
  endDate: z.date({
    required_error: "Please select an end date.",
  }),
});

// Define the form schema with zod for date addition/subtraction
const dateAddSubtractSchema = z.object({
  baseDate: z.date({
    required_error: "Please select a base date.",
  }),
  value: z.coerce.number().int().min(0, "Value must be positive"),
  unit: z.enum(["days", "weeks", "months", "years"]),
  operation: z.enum(["add", "subtract"]),
});

type DateDifferenceFormValues = z.infer<typeof dateDifferenceSchema>;
type DateAddSubtractFormValues = z.infer<typeof dateAddSubtractSchema>;

const DateCalculator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("difference");
  const [differenceResults, setDifferenceResults] = useState<{
    days: number;
    weeks: number;
    months: number;
    years: number;
  } | null>(null);
  
  const [addSubtractResults, setAddSubtractResults] = useState<{
    resultDate: Date;
    description: string;
  } | null>(null);

  // Initialize the form for date difference
  const differenceForm = useForm<DateDifferenceFormValues>({
    resolver: zodResolver(dateDifferenceSchema),
    defaultValues: {
      startDate: new Date(),
      endDate: new Date(),
    },
  });
  
  // Initialize the form for date addition/subtraction
  const addSubtractForm = useForm<DateAddSubtractFormValues>({
    resolver: zodResolver(dateAddSubtractSchema),
    defaultValues: {
      baseDate: new Date(),
      value: 1,
      unit: "days",
      operation: "add",
    },
  });

  // Function to calculate the difference between two dates
  const calculateDateDifference = (values: DateDifferenceFormValues) => {
    const { startDate, endDate } = values;
    
    if (!isValid(startDate) || !isValid(endDate)) {
      throw new Error("Invalid date entered");
    }
    
    // Note: differenceIn* functions handle negative differences automatically
    const days = Math.abs(differenceInDays(endDate, startDate));
    const weeks = Math.abs(differenceInWeeks(endDate, startDate));
    const months = Math.abs(differenceInMonths(endDate, startDate));
    const years = Math.abs(differenceInYears(endDate, startDate));
    
    return {
      days,
      weeks,
      months,
      years
    };
  };
  
  // Function to add or subtract time from a date
  const calculateDateAddSubtract = (values: DateAddSubtractFormValues) => {
    const { baseDate, value, unit, operation } = values;
    
    if (!isValid(baseDate)) {
      throw new Error("Invalid date entered");
    }
    
    let resultDate: Date;
    let description = "";
    
    if (operation === "add") {
      switch (unit) {
        case "days":
          resultDate = addDays(baseDate, value);
          description = `${format(baseDate, "PPP")} + ${value} day${value !== 1 ? 's' : ''}`;
          break;
        case "weeks":
          resultDate = addWeeks(baseDate, value);
          description = `${format(baseDate, "PPP")} + ${value} week${value !== 1 ? 's' : ''}`;
          break;
        case "months":
          resultDate = addMonths(baseDate, value);
          description = `${format(baseDate, "PPP")} + ${value} month${value !== 1 ? 's' : ''}`;
          break;
        case "years":
          resultDate = addYears(baseDate, value);
          description = `${format(baseDate, "PPP")} + ${value} year${value !== 1 ? 's' : ''}`;
          break;
        default:
          throw new Error("Invalid unit selected");
      }
    } else { // subtract
      switch (unit) {
        case "days":
          resultDate = addDays(baseDate, -value);
          description = `${format(baseDate, "PPP")} - ${value} day${value !== 1 ? 's' : ''}`;
          break;
        case "weeks":
          resultDate = addWeeks(baseDate, -value);
          description = `${format(baseDate, "PPP")} - ${value} week${value !== 1 ? 's' : ''}`;
          break;
        case "months":
          resultDate = addMonths(baseDate, -value);
          description = `${format(baseDate, "PPP")} - ${value} month${value !== 1 ? 's' : ''}`;
          break;
        case "years":
          resultDate = addYears(baseDate, -value);
          description = `${format(baseDate, "PPP")} - ${value} year${value !== 1 ? 's' : ''}`;
          break;
        default:
          throw new Error("Invalid unit selected");
      }
    }
    
    return {
      resultDate,
      description
    };
  };

  // Update difference results when form values change
  React.useEffect(() => {
    if (differenceForm.formState.isValid && activeTab === "difference") {
      const currentValues = differenceForm.getValues();
      try {
        const results = calculateDateDifference(currentValues);
        setDifferenceResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
        // Don't show toast on initial load or for validation errors
      }
    }
  }, [differenceForm.watch('startDate'), differenceForm.watch('endDate'), differenceForm, activeTab]);
  
  // Update add/subtract results when form values change
  React.useEffect(() => {
    if (addSubtractForm.formState.isValid && activeTab === "add-subtract") {
      const currentValues = addSubtractForm.getValues();
      try {
        const results = calculateDateAddSubtract(currentValues);
        setAddSubtractResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
        // Don't show toast on initial load or for validation errors
      }
    }
  }, [
    addSubtractForm.watch('baseDate'), 
    addSubtractForm.watch('value'), 
    addSubtractForm.watch('unit'), 
    addSubtractForm.watch('operation'), 
    addSubtractForm,
    activeTab
  ]);

  const onDifferenceSubmit = (values: DateDifferenceFormValues) => {
    try {
      const results = calculateDateDifference(values);
      setDifferenceResults(results);
      toast({
        title: 'Date difference calculated',
        description: 'The difference between the dates has been calculated successfully.',
      });
    } catch (error) {
      let errorMessage = 'There was an error calculating the date difference.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Calculation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };
  
  const onAddSubtractSubmit = (values: DateAddSubtractFormValues) => {
    try {
      const results = calculateDateAddSubtract(values);
      setAddSubtractResults(results);
      toast({
        title: 'Date calculation completed',
        description: `The ${values.operation === 'add' ? 'addition' : 'subtraction'} has been calculated successfully.`,
      });
    } catch (error) {
      let errorMessage = 'There was an error performing the date calculation.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: 'Calculation Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  // Helper function to capitalize first letter
  const capitalize = (str: string): string => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <CalendarIconSolid className="mr-2 h-8 w-8" /> Date Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="difference" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="difference">Date Difference</TabsTrigger>
            <TabsTrigger value="add-subtract">Add/Subtract Date</TabsTrigger>
          </TabsList>
          
          {/* Date Difference Tab */}
          <TabsContent value="difference" className="grid md:grid-cols-2 gap-6">
            {/* Form Card */}
            <Card>
              <CardHeader>
                <CardTitle>Calculate Date Difference</CardTitle>
                <CardDescription>
                  Find the exact time between two dates.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...differenceForm}>
                  <form onSubmit={differenceForm.handleSubmit(onDifferenceSubmit)} className="space-y-6">
                    <FormField
                      control={differenceForm.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Start Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={differenceForm.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>End Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full">Calculate Difference</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle>Date Difference Results</CardTitle>
                <CardDescription>
                  The time span between your selected dates.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {differenceResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Between Dates</div>
                      <div className="text-sm mt-1">
                        {format(differenceForm.getValues().startDate, "PPP")} and {format(differenceForm.getValues().endDate, "PPP")}
                      </div>
                      <div className="text-3xl font-bold text-primary mt-2">
                        {differenceResults.days} days
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">In Weeks</div>
                        <div className="text-xl font-semibold">{differenceResults.weeks} weeks</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">In Months</div>
                        <div className="text-xl font-semibold">{differenceResults.months} months</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">In Years</div>
                        <div className="text-xl font-semibold">{differenceResults.years} years</div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Detailed Breakdown</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Total Days:</span>
                          <span>{differenceResults.days} days</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>That's approximately:</span>
                          <span>{(differenceResults.days * 24).toLocaleString()} hours</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Or:</span>
                          <span>{(differenceResults.days * 24 * 60).toLocaleString()} minutes</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Or:</span>
                          <span>{(differenceResults.days * 24 * 60 * 60).toLocaleString()} seconds</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter two dates to see the difference between them.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Add/Subtract Date Tab */}
          <TabsContent value="add-subtract" className="grid md:grid-cols-2 gap-6">
            {/* Form Card */}
            <Card>
              <CardHeader>
                <CardTitle>Add or Subtract Date</CardTitle>
                <CardDescription>
                  Calculate a new date by adding or subtracting time.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...addSubtractForm}>
                  <form onSubmit={addSubtractForm.handleSubmit(onAddSubtractSubmit)} className="space-y-6">
                    <FormField
                      control={addSubtractForm.control}
                      name="baseDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Base Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addSubtractForm.control}
                        name="operation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Operation</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select operation" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="add">Add</SelectItem>
                                <SelectItem value="subtract">Subtract</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={addSubtractForm.control}
                        name="unit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Unit</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select unit" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="days">Days</SelectItem>
                                <SelectItem value="weeks">Weeks</SelectItem>
                                <SelectItem value="months">Months</SelectItem>
                                <SelectItem value="years">Years</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={addSubtractForm.control}
                      name="value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Value</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Plus className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                              <input
                                type="number"
                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pl-10 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                {...field}
                                onChange={(e) => {
                                  const value = e.target.value === "" ? "0" : e.target.value;
                                  field.onChange(value);
                                }}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full">Calculate New Date</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle>Date Calculation Results</CardTitle>
                <CardDescription>
                  Your new calculated date.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {addSubtractResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Result Date</div>
                      <div className="text-3xl font-bold text-primary">
                        {format(addSubtractResults.resultDate, "PPP")}
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Calculation</div>
                        <div className="text-xl font-semibold">{addSubtractResults.description}</div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Date Information</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Day of Week:</span>
                          <span>{format(addSubtractResults.resultDate, "EEEE")}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Month:</span>
                          <span>{format(addSubtractResults.resultDate, "MMMM")}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Quarter:</span>
                          <span>Q{Math.floor(addSubtractResults.resultDate.getMonth() / 3) + 1}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Week of Year:</span>
                          <span>{format(addSubtractResults.resultDate, "w")}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Set your date calculation parameters to see the result.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Date Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our date calculator offers two primary functions:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Date Difference</strong>: Calculate the exact time between two dates, with results in multiple time units (days, weeks, months, years).</li>
                  <li><strong>Add/Subtract Dates</strong>: Find a future or past date by adding or subtracting a specific time period from a base date.</li>
                </ul>
                <p>These calculations account for varying month lengths and leap years to provide accurate results for all your date-related needs.</p>
                <p className="text-gray-500">All date calculations are performed using the standard Gregorian calendar.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default DateCalculator;
