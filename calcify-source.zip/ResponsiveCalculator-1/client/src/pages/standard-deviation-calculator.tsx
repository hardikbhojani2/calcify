import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, BarChart3, XCircle, Calculator, ClipboardCheck } from 'lucide-react';
import { Link } from 'wouter';

// Define the data entry form schema
const dataEntrySchema = z.object({
  data: z.string().min(1, "Please enter data values"),
  dataType: z.enum(["sample", "population"]),
});

type DataEntryFormValues = z.infer<typeof dataEntrySchema>;

// Define the frequency table form schema
const frequencyTableSchema = z.object({
  values: z.string().min(1, "Please enter data values"),
  frequencies: z.string().min(1, "Please enter frequencies"),
  dataType: z.enum(["sample", "population"]),
});

type FrequencyTableFormValues = z.infer<typeof frequencyTableSchema>;

const StandardDeviationCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("data");
  
  const [results, setResults] = useState<{
    mean: number;
    median: number;
    mode: number[];
    range: number;
    variance: number;
    standardDeviation: number;
    dataPoints: number;
    sum: number;
    dataType: string;
    dataValues: number[];
    steps: string[];
  } | null>(null);
  
  // Initialize form for data entry
  const dataForm = useForm<DataEntryFormValues>({
    resolver: zodResolver(dataEntrySchema),
    defaultValues: {
      data: "5, 10, 15, 20, 25",
      dataType: "sample",
    },
  });
  
  // Initialize form for frequency table
  const frequencyForm = useForm<FrequencyTableFormValues>({
    resolver: zodResolver(frequencyTableSchema),
    defaultValues: {
      values: "10, 20, 30, 40, 50",
      frequencies: "5, 10, 15, 8, 2",
      dataType: "sample",
    },
  });

  // Parse string data into numeric array
  const parseData = (input: string): number[] => {
    const values = input.split(/\s*[,;\s]\s*/).filter(val => val.trim() !== '');
    return values.map(val => {
      const num = Number(val.trim());
      if (isNaN(num)) {
        throw new Error(`Invalid number: ${val}`);
      }
      return num;
    });
  };

  // Calculate statistical measures
  const calculateStatistics = (data: number[], isPopulation: boolean): Omit<typeof results, 'null'> => {
    const steps: string[] = [];
    
    // Sort data for calculations
    const sortedData = [...data].sort((a, b) => a - b);
    steps.push(`Sorted data: ${sortedData.join(", ")}`);
    
    // Calculate sum
    const sum = data.reduce((acc, val) => acc + val, 0);
    steps.push(`Sum of all values: ${sum}`);
    
    // Calculate mean
    const mean = sum / data.length;
    steps.push(`Mean = Sum / Count = ${sum} / ${data.length} = ${mean.toFixed(4)}`);
    
    // Calculate median
    let median: number;
    const middleIndex = Math.floor(sortedData.length / 2);
    if (sortedData.length % 2 === 0) {
      median = (sortedData[middleIndex - 1] + sortedData[middleIndex]) / 2;
      steps.push(`Median (even number of values) = (${sortedData[middleIndex - 1]} + ${sortedData[middleIndex]}) / 2 = ${median}`);
    } else {
      median = sortedData[middleIndex];
      steps.push(`Median (odd number of values) = ${median}`);
    }
    
    // Calculate mode
    const countMap = new Map<number, number>();
    sortedData.forEach(val => {
      countMap.set(val, (countMap.get(val) || 0) + 1);
    });
    
    let maxFrequency = 0;
    let modes: number[] = [];
    
    countMap.forEach((frequency, value) => {
      if (frequency > maxFrequency) {
        maxFrequency = frequency;
        modes = [value];
      } else if (frequency === maxFrequency) {
        modes.push(value);
      }
    });
    
    if (modes.length === sortedData.length) {
      // If all values appear with the same frequency, there's no mode
      modes = [];
      steps.push(`Mode: No mode (all values occur with the same frequency)`);
    } else {
      steps.push(`Mode: ${modes.join(", ")} (appears ${maxFrequency} times)`);
    }
    
    // Calculate range
    const range = sortedData[sortedData.length - 1] - sortedData[0];
    steps.push(`Range = Max value - Min value = ${sortedData[sortedData.length - 1]} - ${sortedData[0]} = ${range}`);
    
    // Calculate variance
    const squaredDifferences = data.map(val => (val - mean) ** 2);
    steps.push(`Calculate squared differences from the mean:`);
    squaredDifferences.forEach((val, idx) => {
      steps.push(`  (${data[idx]} - ${mean.toFixed(4)})² = ${val.toFixed(4)}`);
    });
    
    const sumOfSquaredDifferences = squaredDifferences.reduce((acc, val) => acc + val, 0);
    steps.push(`Sum of squared differences: ${sumOfSquaredDifferences.toFixed(4)}`);
    
    let variance: number;
    if (isPopulation) {
      variance = sumOfSquaredDifferences / data.length;
      steps.push(`Population Variance = Sum of squared differences / N = ${sumOfSquaredDifferences.toFixed(4)} / ${data.length} = ${variance.toFixed(4)}`);
    } else {
      variance = sumOfSquaredDifferences / (data.length - 1);
      steps.push(`Sample Variance = Sum of squared differences / (n - 1) = ${sumOfSquaredDifferences.toFixed(4)} / ${data.length - 1} = ${variance.toFixed(4)}`);
    }
    
    // Calculate standard deviation
    const standardDeviation = Math.sqrt(variance);
    steps.push(`Standard Deviation = √Variance = √${variance.toFixed(4)} = ${standardDeviation.toFixed(4)}`);
    
    return {
      mean,
      median,
      mode: modes,
      range,
      variance,
      standardDeviation,
      dataPoints: data.length,
      sum,
      dataType: isPopulation ? "Population" : "Sample",
      dataValues: data,
      steps
    };
  };

  // Calculate statistics from frequency table
  const calculateFromFrequencyTable = (values: number[], frequencies: number[], isPopulation: boolean): Omit<typeof results, 'null'> => {
    const steps: string[] = [];
    
    // Validate input
    if (values.length !== frequencies.length) {
      throw new Error("The number of values must match the number of frequencies");
    }
    
    // Expand the data based on frequencies
    let expandedData: number[] = [];
    for (let i = 0; i < values.length; i++) {
      for (let j = 0; j < frequencies[i]; j++) {
        expandedData.push(values[i]);
      }
    }
    
    steps.push(`Expanding frequency table to data set:`);
    steps.push(`Values: ${values.join(", ")}`);
    steps.push(`Frequencies: ${frequencies.join(", ")}`);
    steps.push(`Total data points: ${expandedData.length}`);
    
    // Calculate total count
    const totalCount = frequencies.reduce((acc, val) => acc + val, 0);
    
    // Calculate sum
    let sum = 0;
    for (let i = 0; i < values.length; i++) {
      sum += values[i] * frequencies[i];
    }
    steps.push(`Sum = Σ(Value × Frequency) = ${sum}`);
    
    // Calculate mean
    const mean = sum / totalCount;
    steps.push(`Mean = Sum / Total count = ${sum} / ${totalCount} = ${mean.toFixed(4)}`);
    
    // Calculate variance
    let sumOfSquaredDifferences = 0;
    for (let i = 0; i < values.length; i++) {
      const squaredDiff = ((values[i] - mean) ** 2) * frequencies[i];
      sumOfSquaredDifferences += squaredDiff;
      steps.push(`  (${values[i]} - ${mean.toFixed(4)})² × ${frequencies[i]} = ${squaredDiff.toFixed(4)}`);
    }
    
    steps.push(`Sum of squared differences: ${sumOfSquaredDifferences.toFixed(4)}`);
    
    let variance: number;
    if (isPopulation) {
      variance = sumOfSquaredDifferences / totalCount;
      steps.push(`Population Variance = Sum of squared differences / N = ${sumOfSquaredDifferences.toFixed(4)} / ${totalCount} = ${variance.toFixed(4)}`);
    } else {
      variance = sumOfSquaredDifferences / (totalCount - 1);
      steps.push(`Sample Variance = Sum of squared differences / (n - 1) = ${sumOfSquaredDifferences.toFixed(4)} / ${totalCount - 1} = ${variance.toFixed(4)}`);
    }
    
    // Calculate standard deviation
    const standardDeviation = Math.sqrt(variance);
    steps.push(`Standard Deviation = √Variance = √${variance.toFixed(4)} = ${standardDeviation.toFixed(4)}`);
    
    // Calculate median from expanded data
    const sortedData = [...expandedData].sort((a, b) => a - b);
    let median: number;
    const middleIndex = Math.floor(sortedData.length / 2);
    if (sortedData.length % 2 === 0) {
      median = (sortedData[middleIndex - 1] + sortedData[middleIndex]) / 2;
    } else {
      median = sortedData[middleIndex];
    }
    steps.push(`Median = ${median}`);
    
    // Calculate mode from frequency table
    let maxFrequency = Math.max(...frequencies);
    let modes: number[] = [];
    for (let i = 0; i < frequencies.length; i++) {
      if (frequencies[i] === maxFrequency) {
        modes.push(values[i]);
      }
    }
    
    if (modes.length === values.length) {
      // If all values appear with the same frequency, there's no mode
      modes = [];
      steps.push(`Mode: No mode (all values occur with the same frequency)`);
    } else {
      steps.push(`Mode: ${modes.join(", ")} (appears ${maxFrequency} times)`);
    }
    
    // Calculate range
    const range = Math.max(...values) - Math.min(...values);
    steps.push(`Range = Max value - Min value = ${Math.max(...values)} - ${Math.min(...values)} = ${range}`);
    
    return {
      mean,
      median,
      mode: modes,
      range,
      variance,
      standardDeviation,
      dataPoints: totalCount,
      sum,
      dataType: isPopulation ? "Population" : "Sample",
      dataValues: expandedData,
      steps
    };
  };

  // Form submission handlers
  const onDataSubmit = (values: DataEntryFormValues) => {
    try {
      // Parse the data
      const data = parseData(values.data);
      if (data.length === 0) {
        throw new Error("Please enter at least one valid number");
      }
      
      // Calculate statistics
      const isPopulation = values.dataType === "population";
      const result = calculateStatistics(data, isPopulation);
      setResults(result as any);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };
  
  const onFrequencySubmit = (values: FrequencyTableFormValues) => {
    try {
      // Parse the values and frequencies
      const dataValues = parseData(values.values);
      const frequencies = parseData(values.frequencies);
      
      if (dataValues.length === 0 || frequencies.length === 0) {
        throw new Error("Please enter at least one valid number for both values and frequencies");
      }
      
      if (dataValues.length !== frequencies.length) {
        throw new Error("The number of values must match the number of frequencies");
      }
      
      // Ensure all frequencies are positive integers
      for (const freq of frequencies) {
        if (freq <= 0 || !Number.isInteger(freq)) {
          throw new Error("All frequencies must be positive integers");
        }
      }
      
      // Calculate statistics
      const isPopulation = values.dataType === "population";
      const result = calculateFromFrequencyTable(dataValues, frequencies, isPopulation);
      setResults(result as any);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        alert(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <BarChart3 className="mr-2 h-8 w-8" /> Standard Deviation Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Tabs defaultValue="data" onValueChange={setActiveTab} value={activeTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="data">Data Entry</TabsTrigger>
                <TabsTrigger value="frequency">Frequency Table</TabsTrigger>
              </TabsList>
              
              {/* Data Entry Tab */}
              <TabsContent value="data">
                <Card>
                  <CardHeader>
                    <CardTitle>Data Entry</CardTitle>
                    <CardDescription>
                      Enter your data points to calculate statistical measures.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...dataForm}>
                      <form onSubmit={dataForm.handleSubmit(onDataSubmit)} className="space-y-6">
                        <FormField
                          control={dataForm.control}
                          name="data"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Data Values</FormLabel>
                              <FormControl>
                                <Textarea 
                                  {...field} 
                                  placeholder="Enter comma or space separated values (e.g., 5, 10, 15, 20, 25)" 
                                  rows={4}
                                />
                              </FormControl>
                              <FormDescription>
                                Enter numeric values separated by commas, spaces, or line breaks.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={dataForm.control}
                          name="dataType"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Data Type</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-col space-y-1"
                                >
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="sample" />
                                    </FormControl>
                                    <FormLabel className="font-normal">
                                      Sample (n-1 denominator)
                                    </FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="population" />
                                    </FormControl>
                                    <FormLabel className="font-normal">
                                      Population (n denominator)
                                    </FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                Choose "Sample" if your data represents a subset of the population.
                                Choose "Population" if your data includes every member of the population.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex items-center space-x-4">
                          <Button type="submit" className="flex-1">Calculate</Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            className="flex items-center" 
                            onClick={() => {
                              dataForm.reset({
                                data: "",
                                dataType: "sample"
                              });
                              setResults(null);
                            }}
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Clear
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Frequency Table Tab */}
              <TabsContent value="frequency">
                <Card>
                  <CardHeader>
                    <CardTitle>Frequency Table</CardTitle>
                    <CardDescription>
                      Enter values and their frequencies to calculate statistical measures.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...frequencyForm}>
                      <form onSubmit={frequencyForm.handleSubmit(onFrequencySubmit)} className="space-y-6">
                        <FormField
                          control={frequencyForm.control}
                          name="values"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Values</FormLabel>
                              <FormControl>
                                <Textarea 
                                  {...field} 
                                  placeholder="Enter data values (e.g., 10, 20, 30, 40, 50)" 
                                  rows={2}
                                />
                              </FormControl>
                              <FormDescription>
                                Enter the unique values in your data set.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={frequencyForm.control}
                          name="frequencies"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Frequencies</FormLabel>
                              <FormControl>
                                <Textarea 
                                  {...field} 
                                  placeholder="Enter frequencies (e.g., 5, 10, 15, 8, 2)" 
                                  rows={2}
                                />
                              </FormControl>
                              <FormDescription>
                                Enter how many times each value appears in your data set.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={frequencyForm.control}
                          name="dataType"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Data Type</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-col space-y-1"
                                >
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="sample" />
                                    </FormControl>
                                    <FormLabel className="font-normal">
                                      Sample (n-1 denominator)
                                    </FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="population" />
                                    </FormControl>
                                    <FormLabel className="font-normal">
                                      Population (n denominator)
                                    </FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormDescription>
                                Choose "Sample" if your data represents a subset of the population.
                                Choose "Population" if your data includes every member of the population.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex items-center space-x-4">
                          <Button type="submit" className="flex-1">Calculate</Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            className="flex items-center" 
                            onClick={() => {
                              frequencyForm.reset({
                                values: "",
                                frequencies: "",
                                dataType: "sample"
                              });
                              setResults(null);
                            }}
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Clear
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Results</CardTitle>
                <CardDescription>
                  Statistical measures and calculations.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {results ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-primary/10 rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Standard Deviation</p>
                        <p className="text-2xl font-bold">{results.standardDeviation.toFixed(4)}</p>
                        <p className="text-xs text-gray-500 mt-1">{results.dataType}</p>
                      </div>
                      
                      <div className="p-4 bg-primary/10 rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Variance</p>
                        <p className="text-2xl font-bold">{results.variance.toFixed(4)}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Mean:</p>
                        <p className="text-sm font-medium">{results.mean.toFixed(4)}</p>
                      </div>
                      
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Median:</p>
                        <p className="text-sm font-medium">{results.median.toFixed(4)}</p>
                      </div>
                      
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Mode:</p>
                        <p className="text-sm font-medium">
                          {results.mode.length > 0 ? results.mode.map(m => m.toFixed(2)).join(", ") : "No mode"}
                        </p>
                      </div>
                      
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Range:</p>
                        <p className="text-sm font-medium">{results.range.toFixed(4)}</p>
                      </div>
                      
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Sum:</p>
                        <p className="text-sm font-medium">{results.sum.toFixed(4)}</p>
                      </div>
                      
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-500">Count:</p>
                        <p className="text-sm font-medium">{results.dataPoints}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-2">
                      <h3 className="text-md font-medium">Calculation Steps</h3>
                      <div className="space-y-1 text-xs max-h-60 overflow-y-auto p-2 bg-gray-50 rounded-md">
                        {results.steps.map((step, idx) => (
                          <p key={idx} className="whitespace-pre-wrap">{step}</p>
                        ))}
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      className="w-full flex items-center justify-center"
                      onClick={() => {
                        const resultText = [
                          `Standard Deviation: ${results.standardDeviation.toFixed(4)}`,
                          `Variance: ${results.variance.toFixed(4)}`,
                          `Mean: ${results.mean.toFixed(4)}`,
                          `Median: ${results.median.toFixed(4)}`,
                          `Mode: ${results.mode.length > 0 ? results.mode.map(m => m.toFixed(2)).join(", ") : "No mode"}`,
                          `Range: ${results.range.toFixed(4)}`,
                          `Sum: ${results.sum.toFixed(4)}`,
                          `Count: ${results.dataPoints}`,
                          `Data type: ${results.dataType}`
                        ].join('\n');
                        navigator.clipboard.writeText(resultText);
                        alert("Results copied to clipboard");
                      }}
                    >
                      <ClipboardCheck className="w-4 h-4 mr-2" /> Copy Results
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-12 h-full flex flex-col items-center justify-center text-gray-500">
                    <Calculator className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-lg">Enter your data and click "Calculate"</p>
                    <p className="text-sm mt-2">Results will appear here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Standard Deviation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                Standard deviation is a statistical measure that quantifies the amount of variation or dispersion in a set of values. 
                A low standard deviation indicates that the values tend to be close to the mean, while a high standard deviation 
                indicates that the values are spread out over a wider range.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Formulas</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Population Standard Deviation (σ):</strong>
                      <p>σ = √(Σ(x - μ)² / N)</p>
                      <p className="text-xs">Where μ is the population mean and N is the population size</p>
                    </li>
                    <li>
                      <strong>Sample Standard Deviation (s):</strong>
                      <p>s = √(Σ(x - x̄)² / (n - 1))</p>
                      <p className="text-xs">Where x̄ is the sample mean and n is the sample size</p>
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">When to Use</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                    <li>
                      <strong>Population Standard Deviation:</strong> Use when you have data for the entire population you're studying.
                    </li>
                    <li>
                      <strong>Sample Standard Deviation:</strong> Use when you have data from a sample of the population.
                    </li>
                    <li>
                      <strong>Data Analysis:</strong> Used in statistical inference, quality control, climate studies, finance, etc.
                    </li>
                    <li>
                      <strong>Normal Distribution:</strong> In a normal distribution, about 68% of values fall within one standard deviation of the mean, 95% within two, and 99.7% within three.
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4">
                <h3 className="text-lg font-medium text-gray-900">Terms</h3>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                  <li>
                    <strong>Mean:</strong> The average of all values in the dataset.
                  </li>
                  <li>
                    <strong>Median:</strong> The middle value when the data is arranged in order (or the average of the two middle values for an even number of observations).
                  </li>
                  <li>
                    <strong>Mode:</strong> The value(s) that appear most frequently in the dataset.
                  </li>
                  <li>
                    <strong>Range:</strong> The difference between the largest and smallest values.
                  </li>
                  <li>
                    <strong>Variance:</strong> The average of the squared differences from the mean. Standard deviation is the square root of variance.
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default StandardDeviationCalculator;
