import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import NavBar from '@/components/nav-bar';
import Footer from '@/components/footer';
import { ArrowLeft, Clock, DollarSign, Calendar } from 'lucide-react';
import { Link } from 'wouter';

// Define the form schema for work hours
const workHoursSchema = z.object({
  hoursPerDay: z.coerce.number().min(0, "Hours must be positive").max(24, "Hours cannot exceed 24"),
  daysPerWeek: z.coerce.number().min(1, "Days must be at least 1").max(7, "Days cannot exceed 7"),
  hourlyRate: z.coerce.number().min(0, "Hourly rate must be positive"),
  weekCount: z.coerce.number().min(1, "Week count must be at least 1"),
});

// Define the form schema for time tracking
const timeTrackingSchema = z.object({
  entries: z.array(
    z.object({
      day: z.string().min(1, "Day is required"),
      startHour: z.coerce.number().min(0, "Hours must be between 0-23").max(23, "Hours must be between 0-23"),
      startMinute: z.coerce.number().min(0, "Minutes must be between 0-59").max(59, "Minutes must be between 0-59"),
      endHour: z.coerce.number().min(0, "Hours must be between 0-23").max(23, "Hours must be between 0-23"),
      endMinute: z.coerce.number().min(0, "Minutes must be between 0-59").max(59, "Minutes must be between 0-59"),
      breakMinutes: z.coerce.number().min(0, "Break minutes must be positive"),
      hourlyRate: z.coerce.number().min(0, "Hourly rate must be positive"),
    })
  ),
});

type WorkHoursFormValues = z.infer<typeof workHoursSchema>;
type TimeTrackingFormValues = z.infer<typeof timeTrackingSchema>;
type TimeEntry = TimeTrackingFormValues['entries'][0];

const HoursCalculator: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("work-hours");
  
  const [workResults, setWorkResults] = useState<{
    totalHours: number;
    totalPay: number;
    weeklyHours: number;
    weeklyPay: number;
  } | null>(null);
  
  const [timeTrackingResults, setTimeTrackingResults] = useState<{
    entries: Array<{
      day: string;
      hours: number;
      pay: number;
    }>;
    totalHours: number;
    totalPay: number;
  } | null>(null);

  // Initialize the form for work hours
  const workHoursForm = useForm<WorkHoursFormValues>({
    resolver: zodResolver(workHoursSchema),
    defaultValues: {
      hoursPerDay: 8,
      daysPerWeek: 5,
      hourlyRate: 15,
      weekCount: 4,
    },
  });
  
  // Initialize the form for time tracking with default entries for a work week
  const defaultEntries: TimeEntry[] = [
    { day: "Monday", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 },
    { day: "Tuesday", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 },
    { day: "Wednesday", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 },
    { day: "Thursday", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 },
    { day: "Friday", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 },
  ];
  
  const timeTrackingForm = useForm<TimeTrackingFormValues>({
    resolver: zodResolver(timeTrackingSchema),
    defaultValues: {
      entries: defaultEntries,
    },
  });

  // Function to calculate work hours and pay
  const calculateWorkHours = (values: WorkHoursFormValues) => {
    const weeklyHours = values.hoursPerDay * values.daysPerWeek;
    const totalHours = weeklyHours * values.weekCount;
    const weeklyPay = weeklyHours * values.hourlyRate;
    const totalPay = totalHours * values.hourlyRate;
    
    return {
      totalHours,
      totalPay,
      weeklyHours,
      weeklyPay
    };
  };
  
  // Function to calculate time tracking hours and pay
  const calculateTimeTracking = (values: TimeTrackingFormValues) => {
    const entries = values.entries.map(entry => {
      // Calculate minutes for start and end times
      const startMinutes = entry.startHour * 60 + entry.startMinute;
      const endMinutes = entry.endHour * 60 + entry.endMinute;
      
      // Calculate total minutes worked (end - start - break)
      let minutesWorked: number;
      if (endMinutes >= startMinutes) {
        minutesWorked = endMinutes - startMinutes - entry.breakMinutes;
      } else {
        // Handle overnight shifts (end time on next day)
        minutesWorked = (24 * 60 - startMinutes) + endMinutes - entry.breakMinutes;
      }
      
      // Ensure minutesWorked is not negative
      minutesWorked = Math.max(0, minutesWorked);
      
      // Convert to hours and calculate pay
      const hours = minutesWorked / 60;
      const pay = hours * entry.hourlyRate;
      
      return {
        day: entry.day,
        hours,
        pay
      };
    });
    
    // Calculate totals
    const totalHours = entries.reduce((sum, entry) => sum + entry.hours, 0);
    const totalPay = entries.reduce((sum, entry) => sum + entry.pay, 0);
    
    return {
      entries,
      totalHours,
      totalPay
    };
  };

  // Update work results when form values change
  React.useEffect(() => {
    if (workHoursForm.formState.isValid && activeTab === "work-hours") {
      const currentValues = workHoursForm.getValues();
      try {
        const results = calculateWorkHours(currentValues);
        setWorkResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    workHoursForm.watch('hoursPerDay'),
    workHoursForm.watch('daysPerWeek'),
    workHoursForm.watch('hourlyRate'),
    workHoursForm.watch('weekCount'),
    workHoursForm,
    activeTab
  ]);
  
  // Update time tracking results when form values change
  React.useEffect(() => {
    if (timeTrackingForm.formState.isValid && activeTab === "time-tracking") {
      const currentValues = timeTrackingForm.getValues();
      try {
        const results = calculateTimeTracking(currentValues);
        setTimeTrackingResults(results);
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [timeTrackingForm, activeTab]);

  // Form submission handlers
  const onWorkHoursSubmit = (values: WorkHoursFormValues) => {
    try {
      const results = calculateWorkHours(values);
      setWorkResults(results);
      toast({
        title: 'Work hours calculated',
        description: 'Your work hours and pay have been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating your work hours and pay.',
        variant: 'destructive',
      });
    }
  };
  
  const onTimeTrackingSubmit = (values: TimeTrackingFormValues) => {
    try {
      const results = calculateTimeTracking(values);
      setTimeTrackingResults(results);
      toast({
        title: 'Time tracking calculated',
        description: 'Your work hours and pay have been calculated successfully.',
      });
    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'There was an error calculating your time tracking.',
        variant: 'destructive',
      });
    }
  };
  
  // Function to add a new time entry
  const addTimeEntry = () => {
    const currentEntries = timeTrackingForm.getValues().entries;
    timeTrackingForm.setValue('entries', [
      ...currentEntries,
      { day: "", startHour: 9, startMinute: 0, endHour: 17, endMinute: 0, breakMinutes: 60, hourlyRate: 15 }
    ]);
  };
  
  // Function to remove a time entry
  const removeTimeEntry = (index: number) => {
    const currentEntries = timeTrackingForm.getValues().entries;
    if (currentEntries.length > 1) {
      const newEntries = [...currentEntries];
      newEntries.splice(index, 1);
      timeTrackingForm.setValue('entries', newEntries);
    } else {
      toast({
        title: 'Cannot Remove Entry',
        description: 'You must have at least one time entry.',
        variant: 'destructive',
      });
    }
  };

  // Helper function to format time string
  const formatTime = (hour: number, minute: number): string => {
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  };
  
  // Helper function to format currency
  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };
  
  // Helper function to format hours
  const formatHours = (hours: number): string => {
    const wholeHours = Math.floor(hours);
    const minutes = Math.round((hours - wholeHours) * 60);
    return `${wholeHours}h ${minutes}m`;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Clock className="mr-2 h-8 w-8" /> Hours Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="work-hours" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="work-hours">Work Hours & Pay</TabsTrigger>
            <TabsTrigger value="time-tracking">Time Tracking</TabsTrigger>
          </TabsList>
          
          {/* Work Hours Tab */}
          <TabsContent value="work-hours" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Work Hours & Pay</CardTitle>
                <CardDescription>
                  Calculate total hours worked and earnings over a period.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...workHoursForm}>
                  <form onSubmit={workHoursForm.handleSubmit(onWorkHoursSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={workHoursForm.control}
                        name="hoursPerDay"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hours Per Day</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Clock className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                                <Input {...field} type="number" min="0" max="24" step="0.5" className="pl-10" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workHoursForm.control}
                        name="daysPerWeek"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Days Per Week</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                                <Input {...field} type="number" min="1" max="7" className="pl-10" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={workHoursForm.control}
                        name="hourlyRate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hourly Rate ($)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                                <Input {...field} type="number" min="0" step="0.01" className="pl-10" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workHoursForm.control}
                        name="weekCount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Number of Weeks</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" min="1" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">Calculate</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Work Hours & Pay Results</CardTitle>
                <CardDescription>
                  Your calculated working hours and earnings.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {workResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Total Earnings</div>
                      <div className="text-3xl font-bold text-primary">
                        {formatCurrency(workResults.totalPay)}
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Weekly Hours</div>
                        <div className="text-xl font-semibold">{workResults.weeklyHours} hours</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Weekly Pay</div>
                        <div className="text-xl font-semibold">{formatCurrency(workResults.weeklyPay)}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Total Hours</div>
                        <div className="text-xl font-semibold">{workResults.totalHours} hours</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Hourly Rate</div>
                        <div className="text-xl font-semibold">{formatCurrency(workHoursForm.getValues().hourlyRate)}/hr</div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Work Schedule</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Working:</span>
                          <span>{workHoursForm.getValues().hoursPerDay} hours/day</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Days per Week:</span>
                          <span>{workHoursForm.getValues().daysPerWeek} days</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Duration:</span>
                          <span>{workHoursForm.getValues().weekCount} weeks</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Enter your work details to calculate hours and pay.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Time Tracking Tab */}
          <TabsContent value="time-tracking">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Track Working Hours</CardTitle>
                <CardDescription>
                  Track your working hours for each day and calculate earnings.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...timeTrackingForm}>
                  <form onSubmit={timeTrackingForm.handleSubmit(onTimeTrackingSubmit)} className="space-y-6">
                    {timeTrackingForm.getValues().entries.map((entry, index) => (
                      <div key={index} className="p-4 border rounded-md">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="text-lg font-medium">Day {index + 1}</h3>
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="sm" 
                            onClick={() => removeTimeEntry(index)}
                          >
                            Remove
                          </Button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                          <FormField
                            control={timeTrackingForm.control}
                            name={`entries.${index}.day`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Day</FormLabel>
                                <Select 
                                  onValueChange={field.onChange} 
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select day" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Monday">Monday</SelectItem>
                                    <SelectItem value="Tuesday">Tuesday</SelectItem>
                                    <SelectItem value="Wednesday">Wednesday</SelectItem>
                                    <SelectItem value="Thursday">Thursday</SelectItem>
                                    <SelectItem value="Friday">Friday</SelectItem>
                                    <SelectItem value="Saturday">Saturday</SelectItem>
                                    <SelectItem value="Sunday">Sunday</SelectItem>
                                    <SelectItem value="Other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={timeTrackingForm.control}
                            name={`entries.${index}.hourlyRate`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Hourly Rate ($)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                                    <Input {...field} type="number" min="0" step="0.01" className="pl-10" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={timeTrackingForm.control}
                            name={`entries.${index}.breakMinutes`}
                            render={({ field }) => (
                              <FormItem className="md:col-span-2">
                                <FormLabel>Break Duration (minutes)</FormLabel>
                                <FormControl>
                                  <Input {...field} type="number" min="0" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="col-span-1 md:col-span-2">
                            <h4 className="text-sm font-medium mb-2">Start Time</h4>
                            <div className="grid grid-cols-2 gap-2">
                              <FormField
                                control={timeTrackingForm.control}
                                name={`entries.${index}.startHour`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Hour</FormLabel>
                                    <FormControl>
                                      <Input {...field} type="number" min="0" max="23" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={timeTrackingForm.control}
                                name={`entries.${index}.startMinute`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Minute</FormLabel>
                                    <FormControl>
                                      <Input {...field} type="number" min="0" max="59" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                          
                          <div className="col-span-1 md:col-span-2">
                            <h4 className="text-sm font-medium mb-2">End Time</h4>
                            <div className="grid grid-cols-2 gap-2">
                              <FormField
                                control={timeTrackingForm.control}
                                name={`entries.${index}.endHour`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Hour</FormLabel>
                                    <FormControl>
                                      <Input {...field} type="number" min="0" max="23" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={timeTrackingForm.control}
                                name={`entries.${index}.endMinute`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Minute</FormLabel>
                                    <FormControl>
                                      <Input {...field} type="number" min="0" max="59" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    <div className="flex gap-4">
                      <Button type="button" variant="outline" onClick={addTimeEntry} className="w-1/2">
                        Add Day
                      </Button>
                      <Button type="submit" className="w-1/2">Calculate</Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Time Tracking Results</CardTitle>
                <CardDescription>
                  Summary of your tracked hours and earnings.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {timeTrackingResults ? (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500">Total Hours</div>
                      <div className="text-3xl font-bold text-primary">
                        {formatHours(timeTrackingResults.totalHours)}
                      </div>
                      <div className="text-xl font-semibold mt-2">
                        {formatCurrency(timeTrackingResults.totalPay)}
                      </div>
                    </div>

                    <Separator />

                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Day</th>
                            <th className="text-right py-2">Hours</th>
                            <th className="text-right py-2">Pay</th>
                          </tr>
                        </thead>
                        <tbody>
                          {timeTrackingResults.entries.map((entry, index) => (
                            <tr key={index} className="border-b">
                              <td className="py-2">{entry.day}</td>
                              <td className="text-right">{formatHours(entry.hours)}</td>
                              <td className="text-right">{formatCurrency(entry.pay)}</td>
                            </tr>
                          ))}
                          <tr className="font-semibold bg-gray-50">
                            <td className="py-2">Total</td>
                            <td className="text-right">{formatHours(timeTrackingResults.totalHours)}</td>
                            <td className="text-right">{formatCurrency(timeTrackingResults.totalPay)}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800 mb-2">Work Summary</h3>
                      <div className="text-sm text-gray-600">
                        <div className="flex justify-between mb-1">
                          <span>Days Worked:</span>
                          <span>{timeTrackingResults.entries.length}</span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Average Daily Hours:</span>
                          <span>{formatHours(timeTrackingResults.totalHours / timeTrackingResults.entries.length)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Average Daily Pay:</span>
                          <span>{formatCurrency(timeTrackingResults.totalPay / timeTrackingResults.entries.length)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    Track your hours to see a summary of your work and earnings.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>About Hours Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 space-y-4">
                <p>
                  Our hours calculator offers two primary functions:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Work Hours & Pay</strong>: Calculate your total working hours and earnings based on a regular schedule over a specified period.</li>
                  <li><strong>Time Tracking</strong>: Track specific working hours for individual days with customized start/end times, breaks, and pay rates.</li>
                </ul>
                <p>Key features of our calculator:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Support for breaks and lunch periods</li>
                  <li>Variable hourly rates for different days</li>
                  <li>Detailed breakdowns of hours and earnings</li>
                  <li>Support for both regular schedules and custom tracking</li>
                </ul>
                <p className="text-gray-500">Note: This calculator uses a 24-hour format (0-23 hours) for time inputs.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default HoursCalculator;
