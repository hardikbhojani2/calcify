import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Calendar as CalendarIcon, CalendarDays, Baby } from 'lucide-react';
import { Link } from 'wouter';
import { format, addDays, subDays, addWeeks, differenceInDays } from 'date-fns';

// Define the form schemas
const dueDateSchema = z.object({
  dueDate: z.date({
    required_error: "Please select a date",
  }),
});

const lastPeriodSchema = z.object({
  lastPeriodDate: z.date({
    required_error: "Please select a date",
  }),
  cycleLength: z.coerce.number().int().min(20, "Cycle length must be at least 20 days").max(45, "Cycle length must be at most 45 days").default(28),
});

const ivfSchema = z.object({
  ivfTransferDate: z.date({
    required_error: "Please select a date",
  }),
  ivfDayNumber: z.coerce.number().int().min(2, "Must be at least 2").max(6, "Must be at most 6").default(3),
});

type DueDateFormValues = z.infer<typeof dueDateSchema>;
type LastPeriodFormValues = z.infer<typeof lastPeriodSchema>;
type IVFFormValues = z.infer<typeof ivfSchema>;

const PregnancyConceptionCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("duedate");
  const [conceptionResult, setConceptionResult] = useState<{
    conceptionDate: Date;
    fertileWindow: { start: Date; end: Date };
    implantationDate: Date;
    firstTrimesterEnd: Date;
    secondTrimesterEnd: Date;
    dueDate: Date;
    method: string;
    ivfDayNumber?: number;
  } | null>(null);
  
  // Initialize forms
  const dueDateForm = useForm<DueDateFormValues>({
    resolver: zodResolver(dueDateSchema),
    defaultValues: {
      dueDate: new Date(),
    },
  });
  
  const lastPeriodForm = useForm<LastPeriodFormValues>({
    resolver: zodResolver(lastPeriodSchema),
    defaultValues: {
      lastPeriodDate: new Date(),
      cycleLength: 28,
    },
  });
  
  const ivfForm = useForm<IVFFormValues>({
    resolver: zodResolver(ivfSchema),
    defaultValues: {
      ivfTransferDate: new Date(),
      ivfDayNumber: 3,
    },
  });

  // Calculate conception date from due date
  const calculateFromDueDate = (values: DueDateFormValues) => {
    // Standard pregnancy is 40 weeks (280 days)
    // Conception is typically 266 days before due date (or 14 days after LMP)
    const conceptionDate = subDays(values.dueDate, 266);
    
    // Fertile window is approximately 5 days before and 1 day after expected ovulation
    const fertileWindowStart = subDays(conceptionDate, 5);
    const fertileWindowEnd = addDays(conceptionDate, 1);
    
    // Implantation occurs about 6-12 days after conception (using 9 days as average)
    const implantationDate = addDays(conceptionDate, 9);
    
    // First trimester ends at 13 weeks from LMP (LMP is 2 weeks before conception)
    const lmp = subDays(conceptionDate, 14);
    const firstTrimesterEnd = addWeeks(lmp, 13);
    
    // Second trimester ends at 26 weeks from LMP
    const secondTrimesterEnd = addWeeks(lmp, 26);
    
    // Due date is the input
    const dueDate = values.dueDate;
    
    return {
      conceptionDate,
      fertileWindow: { start: fertileWindowStart, end: fertileWindowEnd },
      implantationDate,
      firstTrimesterEnd,
      secondTrimesterEnd,
      dueDate,
      method: "Due Date"
    };
  };

  // Calculate conception date from last period
  const calculateFromLastPeriod = (values: LastPeriodFormValues) => {
    // Calculate ovulation/conception date (approximately 14 days before next period for 28-day cycle)
    const ovulationDay = values.cycleLength - 14;
    const conceptionDate = addDays(values.lastPeriodDate, ovulationDay);
    
    // Fertile window is approximately 5 days before and 1 day after expected ovulation
    const fertileWindowStart = subDays(conceptionDate, 5);
    const fertileWindowEnd = addDays(conceptionDate, 1);
    
    // Implantation occurs about 6-12 days after conception (using 9 days as average)
    const implantationDate = addDays(conceptionDate, 9);
    
    // First trimester ends at 13 weeks from LMP
    const firstTrimesterEnd = addWeeks(values.lastPeriodDate, 13);
    
    // Second trimester ends at 26 weeks from LMP
    const secondTrimesterEnd = addWeeks(values.lastPeriodDate, 26);
    
    // Calculate due date (280 days or 40 weeks from LMP)
    const dueDate = addDays(values.lastPeriodDate, 280);
    
    return {
      conceptionDate,
      fertileWindow: { start: fertileWindowStart, end: fertileWindowEnd },
      implantationDate,
      firstTrimesterEnd,
      secondTrimesterEnd,
      dueDate,
      method: "Last Menstrual Period"
    };
  };

  // Calculate conception date from IVF transfer
  const calculateFromIVF = (values: IVFFormValues) => {
    // Calculate the conception date (day of egg retrieval/fertilization)
    // For IVF, fertilization happens in the lab, and the embryo is transferred later
    const daysFromFertilizationToTransfer = values.ivfDayNumber - 1;
    const conceptionDate = subDays(values.ivfTransferDate, daysFromFertilizationToTransfer);
    
    // IVF doesn't have a traditional fertile window, but we'll calculate it for completeness
    // In this case, it would be the window around egg retrieval
    const fertileWindowStart = subDays(conceptionDate, 5);
    const fertileWindowEnd = addDays(conceptionDate, 1);
    
    // In IVF, implantation typically happens within a few days after transfer
    // Embryo is already developing when transferred, so implantation is soon after transfer
    const implantationDate = addDays(values.ivfTransferDate, 2);
    
    // To calculate LMP equivalent for trimesters, we need to subtract 2 weeks from conception
    const lmpEquivalent = subDays(conceptionDate, 14);
    
    // First trimester ends at 13 weeks from LMP equivalent
    const firstTrimesterEnd = addWeeks(lmpEquivalent, 13);
    
    // Second trimester ends at 26 weeks from LMP equivalent
    const secondTrimesterEnd = addWeeks(lmpEquivalent, 26);
    
    // Due date is 266 days from conception (or 280 days from LMP equivalent)
    const dueDate = addDays(conceptionDate, 266);
    
    return {
      conceptionDate,
      fertileWindow: { start: fertileWindowStart, end: fertileWindowEnd },
      implantationDate,
      firstTrimesterEnd,
      secondTrimesterEnd,
      dueDate,
      method: "IVF Transfer",
      ivfDayNumber: values.ivfDayNumber
    };
  };

  // Form submission handlers
  const onDueDateSubmit = (values: DueDateFormValues) => {
    const result = calculateFromDueDate(values);
    setConceptionResult(result);
  };
  
  const onLastPeriodSubmit = (values: LastPeriodFormValues) => {
    const result = calculateFromLastPeriod(values);
    setConceptionResult(result);
  };
  
  const onIVFSubmit = (values: IVFFormValues) => {
    const result = calculateFromIVF(values);
    setConceptionResult(result);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <Baby className="mr-2 h-8 w-8" /> Conception Calculator
          </h1>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Conception Date</CardTitle>
              <CardDescription>
                Estimate when conception likely occurred based on different information.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="duedate" onValueChange={setActiveTab} value={activeTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-6">
                  <TabsTrigger value="duedate">Due Date</TabsTrigger>
                  <TabsTrigger value="period">Last Period</TabsTrigger>
                  <TabsTrigger value="ivf">IVF Transfer</TabsTrigger>
                </TabsList>
                
                {/* Due Date Tab */}
                <TabsContent value="duedate">
                  <Form {...dueDateForm}>
                    <form onSubmit={dueDateForm.handleSubmit(onDueDateSubmit)} className="space-y-6">
                      <FormField
                        control={dueDateForm.control}
                        name="dueDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Your Due Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The estimated date of delivery provided by your healthcare provider.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full">Calculate Conception</Button>
                    </form>
                  </Form>
                </TabsContent>
                
                {/* Last Period Tab */}
                <TabsContent value="period">
                  <Form {...lastPeriodForm}>
                    <form onSubmit={lastPeriodForm.handleSubmit(onLastPeriodSubmit)} className="space-y-6">
                      <FormField
                        control={lastPeriodForm.control}
                        name="lastPeriodDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>First Day of Last Period</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The first day of your most recent menstrual period.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={lastPeriodForm.control}
                        name="cycleLength"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Average Cycle Length</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} min="20" max="45" />
                            </FormControl>
                            <FormDescription>
                              Average number of days from the first day of one period to the first day of the next.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full">Calculate Conception</Button>
                    </form>
                  </Form>
                </TabsContent>
                
                {/* IVF Tab */}
                <TabsContent value="ivf">
                  <Form {...ivfForm}>
                    <form onSubmit={ivfForm.handleSubmit(onIVFSubmit)} className="space-y-6">
                      <FormField
                        control={ivfForm.control}
                        name="ivfTransferDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Embryo Transfer Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={"w-full pl-3 text-left font-normal"}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The date when the embryo was transferred during your IVF procedure.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={ivfForm.control}
                        name="ivfDayNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Embryo Age at Transfer</FormLabel>
                            <Tabs defaultValue={field.value.toString()} onValueChange={(v) => field.onChange(parseInt(v))}>
                              <TabsList className="grid w-full grid-cols-4">
                                <TabsTrigger value="2">Day 2</TabsTrigger>
                                <TabsTrigger value="3">Day 3</TabsTrigger>
                                <TabsTrigger value="5">Day 5</TabsTrigger>
                                <TabsTrigger value="6">Day 6</TabsTrigger>
                              </TabsList>
                            </Tabs>
                            <FormDescription>
                              The day of embryo development when transfer occurred. Day 3 transfers and Day 5 (blastocyst) transfers are most common.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full">Calculate Conception</Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          
          {/* Results */}
          <Card>
            <CardHeader>
              <CardTitle>Conception Results</CardTitle>
              <CardDescription>
                Estimated conception date and related milestones.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {conceptionResult ? (
                <div className="space-y-6">
                  <div>
                    <p className="text-sm text-gray-500">Calculation Method:</p>
                    <p className="font-medium">{conceptionResult.method}</p>
                  </div>
                  
                  <div className="grid gap-4">
                    <div className="p-4 bg-primary/10 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Estimated Conception Date</p>
                      <p className="text-2xl font-bold">{format(conceptionResult.conceptionDate, "MMMM d, yyyy")}</p>
                    </div>
                    
                    {activeTab !== "ivf" && (
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-700 mb-1">Fertile Window</p>
                        <p className="font-medium text-blue-900">
                          {format(conceptionResult.fertileWindow.start, "MMM d")} - {format(conceptionResult.fertileWindow.end, "MMM d, yyyy")}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Key Pregnancy Dates</h3>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">Implantation</p>
                        <p className="font-medium">{format(conceptionResult.implantationDate, "MMM d, yyyy")}</p>
                      </div>
                      
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">First Trimester Ends</p>
                        <p className="font-medium">{format(conceptionResult.firstTrimesterEnd, "MMM d, yyyy")}</p>
                      </div>
                      
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">Second Trimester Ends</p>
                        <p className="font-medium">{format(conceptionResult.secondTrimesterEnd, "MMM d, yyyy")}</p>
                      </div>
                      
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">Due Date</p>
                        <p className="font-medium">{format(conceptionResult.dueDate, "MMM d, yyyy")}</p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="text-sm text-gray-600">
                    {activeTab === "ivf" && conceptionResult.ivfDayNumber ? (
                      <p>
                        <strong>Note:</strong> For IVF pregnancies, "conception" refers to the day of egg retrieval and 
                        fertilization in the laboratory, which occurred approximately {conceptionResult.ivfDayNumber - 1} days 
                        before your embryo transfer.
                      </p>
                    ) : (
                      <p>
                        <strong>Note:</strong> Conception typically occurs around ovulation, which usually happens about 14 days 
                        before the start of your next menstrual period (for a 28-day cycle). The fertile window represents the days 
                        when pregnancy is most likely to occur with unprotected intercourse.
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <CalendarDays className="h-16 w-16 mx-auto text-gray-300 mb-6" />
                  <h3 className="text-xl font-medium mb-2">No Calculation Yet</h3>
                  <p className="text-gray-500 max-w-md mx-auto">
                    Fill out the form with your information to estimate your conception date and related milestones.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Conception Calculations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This calculator provides estimates of conception dates and related milestones based on different calculation methods. 
                It's important to understand that these are estimates and not precise dates, as many factors can affect conception timing.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Natural Conception</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Ovulation:</strong> Typically occurs about 14 days before the start of the next menstrual period 
                      (in a 28-day cycle). For longer or shorter cycles, ovulation timing varies.
                    </li>
                    <li>
                      <strong>Fertile Window:</strong> Sperm can survive up to 5 days in the female reproductive tract, and an egg 
                      lives for about 24 hours after ovulation. This creates a fertile window of about 6 days.
                    </li>
                    <li>
                      <strong>Conception:</strong> Occurs when sperm fertilizes the egg, usually within 24 hours of ovulation.
                    </li>
                    <li>
                      <strong>Implantation:</strong> The fertilized egg implants in the uterine lining about 6-12 days after ovulation.
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">IVF Conception</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2 text-sm">
                    <li>
                      <strong>Egg Retrieval:</strong> Eggs are retrieved from the ovaries and fertilized in the laboratory. This is 
                      considered the "conception date" for IVF pregnancies.
                    </li>
                    <li>
                      <strong>Embryo Development:</strong> Embryos develop in the laboratory for 2-6 days before transfer.
                    </li>
                    <li>
                      <strong>Embryo Transfer:</strong> Embryos are transferred to the uterus, typically on day 3 or day 5 of development.
                    </li>
                    <li>
                      <strong>Implantation:</strong> Implantation typically occurs 1-5 days after embryo transfer, depending on the 
                      embryo's stage of development at transfer.
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg mt-6">
                <h3 className="text-lg font-medium text-blue-800 mb-2">Important Note</h3>
                <p className="text-sm text-blue-700">
                  This calculator provides estimates only. For accurate dating and pregnancy care, consult with a healthcare provider. 
                  An ultrasound in early pregnancy provides the most accurate dating.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default PregnancyConceptionCalculator;
