import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import NavBar from "@/components/nav-bar";
import Footer from "@/components/footer";
import { ArrowLeft, Triangle as TriangleIcon } from 'lucide-react';
import { Link } from 'wouter';

// Define the forms schema
const sidesSchemaSSSOrAngles = z.object({
  side1: z.coerce.number().positive("Must be positive"),
  side2: z.coerce.number().positive("Must be positive"),
  side3: z.coerce.number().positive("Must be positive")
}).refine(data => {
  // Triangle inequality theorem: sum of lengths of any two sides must exceed the length of the third side
  return (data.side1 + data.side2 > data.side3 && 
          data.side1 + data.side3 > data.side2 && 
          data.side2 + data.side3 > data.side1);
}, {
  message: "Invalid triangle: sum of any two sides must be greater than the third side",
  path: ["side3"]
});

const sidesSchemaSAS = z.object({
  side1: z.coerce.number().positive("Must be positive"),
  angle: z.coerce.number().min(0, "Angle must be positive").max(180, "Angle must be less than 180 degrees"),
  side2: z.coerce.number().positive("Must be positive")
}).refine(data => {
  // Angle must not be 0 or 180 for a valid triangle
  return data.angle > 0 && data.angle < 180;
}, {
  message: "Angle must be between 0 and 180 degrees",
  path: ["angle"]
});

const sideSchemaSSA = z.object({
  side1: z.coerce.number().positive("Must be positive"),
  side2: z.coerce.number().positive("Must be positive"),
  angle: z.coerce.number().min(0, "Angle must be positive").max(180, "Angle must be less than 180 degrees")
}).refine(data => {
  // Ambiguous case handling happens in the calculation, not in the validation
  return data.angle > 0 && data.angle < 180;
}, {
  message: "Angle must be between 0 and 180 degrees",
  path: ["angle"]
});

const angleSchemaAAS = z.object({
  angle1: z.coerce.number().min(0, "Angle must be positive").max(180, "Angle must be less than 180 degrees"),
  angle2: z.coerce.number().min(0, "Angle must be positive").max(180, "Angle must be less than 180 degrees"),
  side: z.coerce.number().positive("Must be positive")
}).refine(data => {
  // Sum of angles in a triangle must be less than 180 degrees
  return data.angle1 + data.angle2 < 180;
}, {
  message: "Sum of two angles must be less than 180 degrees",
  path: ["angle2"]
});

type SSSSidesFormValues = z.infer<typeof sidesSchemaSSSOrAngles>;
type SASFormValues = z.infer<typeof sidesSchemaSAS>;
type SSAFormValues = z.infer<typeof sideSchemaSSA>;
type AASFormValues = z.infer<typeof angleSchemaAAS>;

interface TriangleResults {
  sides: { a: number; b: number; c: number };
  angles: { A: number; B: number; C: number };
  area: number;
  perimeter: number;
  height: { ha: number; hb: number; hc: number };
  inRadius: number;
  circumRadius: number;
}

const TriangleCalculator: React.FC = () => {
  const [activeTab, setActiveTab] = useState("sss");
  const [triangleResults, setTriangleResults] = useState<TriangleResults | null>(null);
  const [calculationMethod, setCalculationMethod] = useState<string>("");
  const [validityMessage, setValidityMessage] = useState<string | null>(null);
  
  // Initialize forms
  const sssForm = useForm<SSSSidesFormValues>({
    resolver: zodResolver(sidesSchemaSSSOrAngles),
    defaultValues: {
      side1: 3,
      side2: 4,
      side3: 5
    },
  });
  
  const sasForm = useForm<SASFormValues>({
    resolver: zodResolver(sidesSchemaSAS),
    defaultValues: {
      side1: 6,
      angle: 60,
      side2: 8
    },
  });
  
  const ssaForm = useForm<SSAFormValues>({
    resolver: zodResolver(sideSchemaSSA),
    defaultValues: {
      side1: 5,
      side2: 7,
      angle: 30
    },
  });
  
  const aasForm = useForm<AASFormValues>({
    resolver: zodResolver(angleSchemaAAS),
    defaultValues: {
      angle1: 30,
      angle2: 45,
      side: 10
    },
  });

  // Convert radians to degrees
  const toDegrees = (radians: number): number => {
    return radians * 180 / Math.PI;
  };

  // Convert degrees to radians
  const toRadians = (degrees: number): number => {
    return degrees * Math.PI / 180;
  };

  // SSS - Three sides
  const calculateSSS = (values: SSSSidesFormValues): TriangleResults => {
    const a = values.side1;
    const b = values.side2;
    const c = values.side3;
    
    // Calculate angles using the Law of Cosines
    const A = toDegrees(Math.acos((b*b + c*c - a*a) / (2 * b * c)));
    const B = toDegrees(Math.acos((a*a + c*c - b*b) / (2 * a * c)));
    const C = toDegrees(Math.acos((a*a + b*b - c*c) / (2 * a * b)));
    
    // Semi-perimeter
    const s = (a + b + c) / 2;
    
    // Area using Heron's formula
    const area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
    
    // Perimeter
    const perimeter = a + b + c;
    
    // Heights
    const ha = 2 * area / a;
    const hb = 2 * area / b;
    const hc = 2 * area / c;
    
    // Inradius - radius of inscribed circle
    const inRadius = area / s;
    
    // Circumradius - radius of circumscribed circle
    const circumRadius = (a * b * c) / (4 * area);
    
    return {
      sides: { a, b, c },
      angles: { A, B, C },
      area,
      perimeter,
      height: { ha, hb, hc },
      inRadius,
      circumRadius
    };
  };

  // SAS - Two sides and the included angle
  const calculateSAS = (values: SASFormValues): TriangleResults => {
    const a = values.side1;
    const b = values.side2;
    const C = values.angle;
    
    // Calculate the third side using the Law of Cosines
    const c = Math.sqrt(a*a + b*b - 2*a*b*Math.cos(toRadians(C)));
    
    // Calculate the other angles
    const A = toDegrees(Math.acos((b*b + c*c - a*a) / (2 * b * c)));
    const B = toDegrees(Math.acos((a*a + c*c - b*b) / (2 * a * c)));
    
    // Area using the sine formula
    const area = 0.5 * a * b * Math.sin(toRadians(C));
    
    // Perimeter
    const perimeter = a + b + c;
    
    // Heights
    const ha = 2 * area / a;
    const hb = 2 * area / b;
    const hc = 2 * area / c;
    
    // Semi-perimeter
    const s = perimeter / 2;
    
    // Inradius
    const inRadius = area / s;
    
    // Circumradius
    const circumRadius = (a * b * c) / (4 * area);
    
    return {
      sides: { a, b, c },
      angles: { A, B, C },
      area,
      perimeter,
      height: { ha, hb, hc },
      inRadius,
      circumRadius
    };
  };

  // SSA - Two sides and the non-included angle
  const calculateSSA = (values: SSAFormValues): TriangleResults | null => {
    // The ambiguous case - may have 0, 1, or 2 solutions
    const a = values.side1;
    const b = values.side2;
    const A = values.angle;
    
    // Convert angle to radians
    const A_rad = toRadians(A);
    
    // Check if a triangle is possible using the Law of Sines
    const sinB = (b * Math.sin(A_rad)) / a;
    
    if (sinB > 1) {
      // No triangle possible
      setValidityMessage("No triangle possible with these values. The side opposite to the angle must be longer.");
      return null;
    }
    
    // Calculate angle B
    const B = toDegrees(Math.asin(sinB));
    
    // Calculate angle C
    const C = 180 - A - B;
    
    // Calculate the third side using the Law of Sines
    const c = a * Math.sin(toRadians(C)) / Math.sin(A_rad);
    
    // Check if there's a potential ambiguous case (two triangles)
    let isAmbiguous = false;
    if (sinB < 1 && b > a * Math.sin(A_rad) && b < a) {
      isAmbiguous = true;
      setValidityMessage("Note: These inputs can form two different triangles (ambiguous case). Showing one solution.");
    } else {
      setValidityMessage(null);
    }
    
    // Area
    const area = 0.5 * a * c * Math.sin(toRadians(B));
    
    // Perimeter
    const perimeter = a + b + c;
    
    // Heights
    const ha = 2 * area / a;
    const hb = 2 * area / b;
    const hc = 2 * area / c;
    
    // Semi-perimeter
    const s = perimeter / 2;
    
    // Inradius
    const inRadius = area / s;
    
    // Circumradius
    const circumRadius = (a * b * c) / (4 * area);
    
    return {
      sides: { a, b, c },
      angles: { A, B, C },
      area,
      perimeter,
      height: { ha, hb, hc },
      inRadius,
      circumRadius
    };
  };

  // AAS - Two angles and the non-included side
  const calculateAAS = (values: AASFormValues): TriangleResults => {
    const A = values.angle1;
    const B = values.angle2;
    const a = values.side;
    
    // Calculate the third angle
    const C = 180 - A - B;
    
    // Calculate the other sides using the Law of Sines
    const b = a * Math.sin(toRadians(B)) / Math.sin(toRadians(A));
    const c = a * Math.sin(toRadians(C)) / Math.sin(toRadians(A));
    
    // Area using the sine formula
    const area = 0.5 * b * c * Math.sin(toRadians(A));
    
    // Perimeter
    const perimeter = a + b + c;
    
    // Heights
    const ha = 2 * area / a;
    const hb = 2 * area / b;
    const hc = 2 * area / c;
    
    // Semi-perimeter
    const s = perimeter / 2;
    
    // Inradius
    const inRadius = area / s;
    
    // Circumradius
    const circumRadius = (a * b * c) / (4 * area);
    
    return {
      sides: { a, b, c },
      angles: { A, B, C },
      area,
      perimeter,
      height: { ha, hb, hc },
      inRadius,
      circumRadius
    };
  };

  // AAA - Three angles (requires at least one side)
  const calculateAAA = (values: SSSSidesFormValues): TriangleResults => {
    // This actually calculates from 3 angles
    // In this implementation, we're reusing the SSS form but treating the inputs as angles
    // In a real implementation, we'd have a separate form for angles
    const A = values.side1;
    const B = values.side2;
    const C = values.side3;
    
    // Validate that angles sum to 180 degrees
    if (Math.abs(A + B + C - 180) > 0.01) {
      setValidityMessage("The sum of angles must be 180 degrees.");
      // Return a default triangle for demonstration
      return calculateSSS({ side1: 3, side2: 4, side3: 5 });
    }
    
    setValidityMessage("Note: With only angles, we can determine the shape but not the size of the triangle. Using a default size.");
    
    // Assume a default side length
    const a = 10; // Arbitrary size
    
    // Calculate the other sides using the Law of Sines
    const b = a * Math.sin(toRadians(B)) / Math.sin(toRadians(A));
    const c = a * Math.sin(toRadians(C)) / Math.sin(toRadians(A));
    
    // Area using the sine formula
    const area = 0.5 * b * c * Math.sin(toRadians(A));
    
    // Perimeter
    const perimeter = a + b + c;
    
    // Heights
    const ha = 2 * area / a;
    const hb = 2 * area / b;
    const hc = 2 * area / c;
    
    // Semi-perimeter
    const s = perimeter / 2;
    
    // Inradius
    const inRadius = area / s;
    
    // Circumradius
    const circumRadius = (a * b * c) / (4 * area);
    
    return {
      sides: { a, b, c },
      angles: { A, B, C },
      area,
      perimeter,
      height: { ha, hb, hc },
      inRadius,
      circumRadius
    };
  };

  // Round number to 4 decimal places for display
  const roundToFour = (num: number): number => {
    return Math.round(num * 10000) / 10000;
  };

  // Form submission handlers
  const onSSSSubmit = (values: SSSSidesFormValues) => {
    try {
      const result = calculateSSS(values);
      setTriangleResults(result);
      setCalculationMethod("SSS - three sides");
      setValidityMessage(null);
    } catch (error) {
      setValidityMessage("Error calculating triangle. Please check your inputs.");
    }
  };
  
  const onSASSubmit = (values: SASFormValues) => {
    try {
      const result = calculateSAS(values);
      setTriangleResults(result);
      setCalculationMethod("SAS - two sides and the included angle");
      setValidityMessage(null);
    } catch (error) {
      setValidityMessage("Error calculating triangle. Please check your inputs.");
    }
  };
  
  const onSSASubmit = (values: SSAFormValues) => {
    try {
      const result = calculateSSA(values);
      if (result) {
        setTriangleResults(result);
        setCalculationMethod("SSA - two sides and a non-included angle");
      }
    } catch (error) {
      setValidityMessage("Error calculating triangle. Please check your inputs.");
    }
  };
  
  const onAASSubmit = (values: AASFormValues) => {
    try {
      const result = calculateAAS(values);
      setTriangleResults(result);
      setCalculationMethod("AAS - two angles and a non-included side");
      setValidityMessage(null);
    } catch (error) {
      setValidityMessage("Error calculating triangle. Please check your inputs.");
    }
  };
  
  const onAAASubmit = (values: SSSSidesFormValues) => {
    try {
      const result = calculateAAA(values);
      setTriangleResults(result);
      setCalculationMethod("AAA - three angles");
    } catch (error) {
      setValidityMessage("Error calculating triangle. Please check your inputs.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/" className="flex items-center text-sm text-blue-600 hover:text-blue-800 mr-6">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to calculators
          </Link>
          <h1 className="text-3xl font-bold flex items-center">
            <TriangleIcon className="mr-2 h-8 w-8" /> Triangle Calculator
          </h1>
        </div>
        
        <Tabs defaultValue="sss" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="sss">SSS</TabsTrigger>
            <TabsTrigger value="sas">SAS</TabsTrigger>
            <TabsTrigger value="ssa">SSA</TabsTrigger>
            <TabsTrigger value="aas">AAS</TabsTrigger>
            <TabsTrigger value="aaa">AAA</TabsTrigger>
          </TabsList>
          
          {/* SSS Tab - Three Sides */}
          <TabsContent value="sss" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SSS - Three Sides</CardTitle>
                <CardDescription>
                  Calculate a triangle using three side lengths.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...sssForm}>
                  <form onSubmit={sssForm.handleSubmit(onSSSSubmit)} className="space-y-6">
                    <FormField
                      control={sssForm.control}
                      name="side1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side a</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sssForm.control}
                      name="side2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side b</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sssForm.control}
                      name="side3"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side c</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Triangle</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {/* Results Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Triangle Results</CardTitle>
                  <CardDescription>
                    Calculated triangle properties based on your inputs.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {triangleResults && activeTab === "sss" ? (
                    <div className="space-y-4">
                      {validityMessage && (
                        <div className="p-3 rounded-md bg-amber-50 text-amber-700 text-sm">
                          {validityMessage}
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-medium mb-2">Method: {calculationMethod}</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Sides</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">a = {roundToFour(triangleResults.sides.a)}</li>
                              <li className="text-sm">b = {roundToFour(triangleResults.sides.b)}</li>
                              <li className="text-sm">c = {roundToFour(triangleResults.sides.c)}</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Angles</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">A = {roundToFour(triangleResults.angles.A)}°</li>
                              <li className="text-sm">B = {roundToFour(triangleResults.angles.B)}°</li>
                              <li className="text-sm">C = {roundToFour(triangleResults.angles.C)}°</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Area and Perimeter</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Area = {roundToFour(triangleResults.area)} square units</div>
                          <div className="text-sm">Perimeter = {roundToFour(triangleResults.perimeter)} units</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Heights</h4>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-sm">hₘ = {roundToFour(triangleResults.height.ha)}</div>
                          <div className="text-sm">hₙ = {roundToFour(triangleResults.height.hb)}</div>
                          <div className="text-sm">hₑ = {roundToFour(triangleResults.height.hc)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Special Radii</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Inradius = {roundToFour(triangleResults.inRadius)}</div>
                          <div className="text-sm">Circumradius = {roundToFour(triangleResults.circumRadius)}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TriangleIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <p>Enter triangle details and click "Calculate Triangle".</p>
                      <p className="text-sm mt-2">The triangle properties will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">SSS Triangle Diagram</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="w-64 h-64 relative">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Simple triangle diagram */}
                      <polygon points="20,180 180,180 100,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      
                      {/* Labels for sides */}
                      <text x="100" y="190" textAnchor="middle" fontSize="14">a</text>
                      <text x="10" y="100" textAnchor="middle" fontSize="14">b</text>
                      <text x="190" y="100" textAnchor="middle" fontSize="14">c</text>
                      
                      {/* Labels for angles */}
                      <text x="20" y="180" textAnchor="start" fontSize="14" transform="translate(0, -10)">A</text>
                      <text x="180" y="180" textAnchor="end" fontSize="14" transform="translate(0, -10)">B</text>
                      <text x="100" y="20" textAnchor="middle" fontSize="14" transform="translate(0, 10)">C</text>
                    </svg>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* SAS Tab - Side, Angle, Side */}
          <TabsContent value="sas" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SAS - Side, Angle, Side</CardTitle>
                <CardDescription>
                  Calculate a triangle using two sides and the included angle.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...sasForm}>
                  <form onSubmit={sasForm.handleSubmit(onSASSubmit)} className="space-y-6">
                    <FormField
                      control={sasForm.control}
                      name="side1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side a</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sasForm.control}
                      name="angle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle C (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormDescription>
                            The angle between sides a and b
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sasForm.control}
                      name="side2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side b</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Triangle</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {/* Results Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Triangle Results</CardTitle>
                  <CardDescription>
                    Calculated triangle properties based on your inputs.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {triangleResults && activeTab === "sas" ? (
                    <div className="space-y-4">
                      {validityMessage && (
                        <div className="p-3 rounded-md bg-amber-50 text-amber-700 text-sm">
                          {validityMessage}
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-medium mb-2">Method: {calculationMethod}</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Sides</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">a = {roundToFour(triangleResults.sides.a)}</li>
                              <li className="text-sm">b = {roundToFour(triangleResults.sides.b)}</li>
                              <li className="text-sm">c = {roundToFour(triangleResults.sides.c)}</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Angles</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">A = {roundToFour(triangleResults.angles.A)}°</li>
                              <li className="text-sm">B = {roundToFour(triangleResults.angles.B)}°</li>
                              <li className="text-sm">C = {roundToFour(triangleResults.angles.C)}°</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Area and Perimeter</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Area = {roundToFour(triangleResults.area)} square units</div>
                          <div className="text-sm">Perimeter = {roundToFour(triangleResults.perimeter)} units</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Heights</h4>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-sm">hₘ = {roundToFour(triangleResults.height.ha)}</div>
                          <div className="text-sm">hₙ = {roundToFour(triangleResults.height.hb)}</div>
                          <div className="text-sm">hₑ = {roundToFour(triangleResults.height.hc)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Special Radii</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Inradius = {roundToFour(triangleResults.inRadius)}</div>
                          <div className="text-sm">Circumradius = {roundToFour(triangleResults.circumRadius)}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TriangleIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <p>Enter triangle details and click "Calculate Triangle".</p>
                      <p className="text-sm mt-2">The triangle properties will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">SAS Triangle Diagram</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="w-64 h-64 relative">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Simple triangle diagram */}
                      <polygon points="20,180 180,180 100,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      
                      {/* Labels for sides */}
                      <text x="50" y="100" textAnchor="middle" fontSize="14">a</text>
                      <text x="150" y="100" textAnchor="middle" fontSize="14">b</text>
                      
                      {/* Labels for the included angle */}
                      <text x="100" y="180" textAnchor="middle" fontSize="14" transform="translate(0, -10)">C</text>
                      
                      {/* Arc indicating the angle */}
                      <path d="M 110,170 A 10,10 0 0 1 90,170" fill="none" stroke="currentColor" strokeWidth="1" />
                    </svg>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* SSA Tab - Two sides and non-included angle */}
          <TabsContent value="ssa" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SSA - Two sides and non-included angle</CardTitle>
                <CardDescription>
                  Calculate a triangle using two sides and a non-included angle.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 p-3 rounded-md bg-blue-50 text-blue-700 text-sm">
                  <p>Note: The SSA case can be ambiguous and may have 0, 1, or 2 solutions depending on the inputs.</p>
                </div>
                
                <Form {...ssaForm}>
                  <form onSubmit={ssaForm.handleSubmit(onSSASubmit)} className="space-y-6">
                    <FormField
                      control={ssaForm.control}
                      name="side1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side a</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={ssaForm.control}
                      name="angle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle A (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormDescription>
                            The angle opposite side a
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={ssaForm.control}
                      name="side2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side b</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Triangle</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {/* Results Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Triangle Results</CardTitle>
                  <CardDescription>
                    Calculated triangle properties based on your inputs.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {triangleResults && activeTab === "ssa" ? (
                    <div className="space-y-4">
                      {validityMessage && (
                        <div className="p-3 rounded-md bg-amber-50 text-amber-700 text-sm">
                          {validityMessage}
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-medium mb-2">Method: {calculationMethod}</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Sides</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">a = {roundToFour(triangleResults.sides.a)}</li>
                              <li className="text-sm">b = {roundToFour(triangleResults.sides.b)}</li>
                              <li className="text-sm">c = {roundToFour(triangleResults.sides.c)}</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Angles</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">A = {roundToFour(triangleResults.angles.A)}°</li>
                              <li className="text-sm">B = {roundToFour(triangleResults.angles.B)}°</li>
                              <li className="text-sm">C = {roundToFour(triangleResults.angles.C)}°</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Area and Perimeter</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Area = {roundToFour(triangleResults.area)} square units</div>
                          <div className="text-sm">Perimeter = {roundToFour(triangleResults.perimeter)} units</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Heights</h4>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-sm">hₘ = {roundToFour(triangleResults.height.ha)}</div>
                          <div className="text-sm">hₙ = {roundToFour(triangleResults.height.hb)}</div>
                          <div className="text-sm">hₑ = {roundToFour(triangleResults.height.hc)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Special Radii</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Inradius = {roundToFour(triangleResults.inRadius)}</div>
                          <div className="text-sm">Circumradius = {roundToFour(triangleResults.circumRadius)}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TriangleIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <p>Enter triangle details and click "Calculate Triangle".</p>
                      <p className="text-sm mt-2">The triangle properties will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">SSA Triangle Diagram</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="w-64 h-64 relative">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Simple triangle diagram */}
                      <polygon points="20,180 180,180 100,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      
                      {/* Labels for sides */}
                      <text x="100" y="190" textAnchor="middle" fontSize="14">a</text>
                      <text x="50" y="100" textAnchor="middle" fontSize="14">b</text>
                      
                      {/* Labels for the angle */}
                      <text x="20" y="180" textAnchor="start" fontSize="14" transform="translate(0, -10)">A</text>
                      
                      {/* Arc indicating the angle */}
                      <path d="M 30,170 A 10,10 0 0 1 30,150" fill="none" stroke="currentColor" strokeWidth="1" />
                    </svg>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* AAS Tab - Two angles and non-included side */}
          <TabsContent value="aas" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>AAS - Two angles and non-included side</CardTitle>
                <CardDescription>
                  Calculate a triangle using two angles and a non-included side.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...aasForm}>
                  <form onSubmit={aasForm.handleSubmit(onAASSubmit)} className="space-y-6">
                    <FormField
                      control={aasForm.control}
                      name="angle1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle A (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aasForm.control}
                      name="angle2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle B (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormDescription>
                            Ensure angles A + B &lt; 180°
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aasForm.control}
                      name="side"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side a</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Triangle</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {/* Results Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Triangle Results</CardTitle>
                  <CardDescription>
                    Calculated triangle properties based on your inputs.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {triangleResults && activeTab === "aas" ? (
                    <div className="space-y-4">
                      {validityMessage && (
                        <div className="p-3 rounded-md bg-amber-50 text-amber-700 text-sm">
                          {validityMessage}
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-medium mb-2">Method: {calculationMethod}</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Sides</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">a = {roundToFour(triangleResults.sides.a)}</li>
                              <li className="text-sm">b = {roundToFour(triangleResults.sides.b)}</li>
                              <li className="text-sm">c = {roundToFour(triangleResults.sides.c)}</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Angles</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">A = {roundToFour(triangleResults.angles.A)}°</li>
                              <li className="text-sm">B = {roundToFour(triangleResults.angles.B)}°</li>
                              <li className="text-sm">C = {roundToFour(triangleResults.angles.C)}°</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Area and Perimeter</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Area = {roundToFour(triangleResults.area)} square units</div>
                          <div className="text-sm">Perimeter = {roundToFour(triangleResults.perimeter)} units</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Heights</h4>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-sm">hₘ = {roundToFour(triangleResults.height.ha)}</div>
                          <div className="text-sm">hₙ = {roundToFour(triangleResults.height.hb)}</div>
                          <div className="text-sm">hₑ = {roundToFour(triangleResults.height.hc)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Special Radii</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Inradius = {roundToFour(triangleResults.inRadius)}</div>
                          <div className="text-sm">Circumradius = {roundToFour(triangleResults.circumRadius)}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TriangleIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <p>Enter triangle details and click "Calculate Triangle".</p>
                      <p className="text-sm mt-2">The triangle properties will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">AAS Triangle Diagram</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="w-64 h-64 relative">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Simple triangle diagram */}
                      <polygon points="20,180 180,180 100,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      
                      {/* Labels for sides */}
                      <text x="50" y="100" textAnchor="middle" fontSize="14">a</text>
                      
                      {/* Labels for the angles */}
                      <text x="20" y="180" textAnchor="start" fontSize="14" transform="translate(0, -10)">A</text>
                      <text x="180" y="180" textAnchor="end" fontSize="14" transform="translate(0, -10)">B</text>
                      
                      {/* Arcs indicating the angles */}
                      <path d="M 30,170 A 10,10 0 0 1 30,150" fill="none" stroke="currentColor" strokeWidth="1" />
                      <path d="M 170,170 A 10,10 0 0 0 170,150" fill="none" stroke="currentColor" strokeWidth="1" />
                    </svg>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* AAA Tab - Three angles */}
          <TabsContent value="aaa" className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>AAA - Three angles</CardTitle>
                <CardDescription>
                  Calculate a triangle using three angles.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 p-3 rounded-md bg-blue-50 text-blue-700 text-sm">
                  <p>Note: The AAA case only determines the shape, not the size of the triangle. A default size will be applied.</p>
                </div>
                
                <Form {...sssForm}>
                  <form onSubmit={sssForm.handleSubmit(onAAASubmit)} className="space-y-6">
                    <FormField
                      control={sssForm.control}
                      name="side1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle A (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sssForm.control}
                      name="side2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle B (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={sssForm.control}
                      name="side3"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Angle C (degrees)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.1" min="0" max="180" />
                          </FormControl>
                          <FormDescription>
                            Angles must sum to 180°
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full">Calculate Triangle</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            {/* Results Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Triangle Results</CardTitle>
                  <CardDescription>
                    Calculated triangle properties based on your inputs.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {triangleResults && activeTab === "aaa" ? (
                    <div className="space-y-4">
                      {validityMessage && (
                        <div className="p-3 rounded-md bg-amber-50 text-amber-700 text-sm">
                          {validityMessage}
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-medium mb-2">Method: {calculationMethod}</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Sides</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">a = {roundToFour(triangleResults.sides.a)}</li>
                              <li className="text-sm">b = {roundToFour(triangleResults.sides.b)}</li>
                              <li className="text-sm">c = {roundToFour(triangleResults.sides.c)}</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 mb-1">Angles</h4>
                            <ul className="space-y-1">
                              <li className="text-sm">A = {roundToFour(triangleResults.angles.A)}°</li>
                              <li className="text-sm">B = {roundToFour(triangleResults.angles.B)}°</li>
                              <li className="text-sm">C = {roundToFour(triangleResults.angles.C)}°</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Area and Perimeter</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Area = {roundToFour(triangleResults.area)} square units</div>
                          <div className="text-sm">Perimeter = {roundToFour(triangleResults.perimeter)} units</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Heights</h4>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-sm">hₘ = {roundToFour(triangleResults.height.ha)}</div>
                          <div className="text-sm">hₙ = {roundToFour(triangleResults.height.hb)}</div>
                          <div className="text-sm">hₑ = {roundToFour(triangleResults.height.hc)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1">Special Radii</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-sm">Inradius = {roundToFour(triangleResults.inRadius)}</div>
                          <div className="text-sm">Circumradius = {roundToFour(triangleResults.circumRadius)}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TriangleIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                      <p>Enter triangle details and click "Calculate Triangle".</p>
                      <p className="text-sm mt-2">The triangle properties will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">AAA Triangle Diagram</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="w-64 h-64 relative">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Simple triangle diagram */}
                      <polygon points="20,180 180,180 100,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      
                      {/* Labels for the angles */}
                      <text x="20" y="180" textAnchor="start" fontSize="14" transform="translate(0, -10)">A</text>
                      <text x="180" y="180" textAnchor="end" fontSize="14" transform="translate(0, -10)">B</text>
                      <text x="100" y="20" textAnchor="middle" fontSize="14" transform="translate(0, 10)">C</text>
                      
                      {/* Arcs indicating the angles */}
                      <path d="M 30,170 A 10,10 0 0 1 30,150" fill="none" stroke="currentColor" strokeWidth="1" />
                      <path d="M 170,170 A 10,10 0 0 0 170,150" fill="none" stroke="currentColor" strokeWidth="1" />
                      <path d="M 90,30 A 10,10 0 0 1 110,30" fill="none" stroke="currentColor" strokeWidth="1" />
                    </svg>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>About Triangle Calculations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-600">
              <p>
                This triangle calculator can solve a triangle using different sets of known values. 
                The methods include:
              </p>
              
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Side-Side-Side (SSS)</h3>
                  <p className="text-sm mt-2">
                    Uses three sides to calculate all triangle properties. 
                    Utilizes the Law of Cosines to find the angles.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Side-Angle-Side (SAS)</h3>
                  <p className="text-sm mt-2">
                    Uses two sides and the included angle to find all other triangle properties.
                    Utilizes the Law of Cosines to find the third side.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Side-Side-Angle (SSA)</h3>
                  <p className="text-sm mt-2">
                    Uses two sides and a non-included angle. This case can be ambiguous 
                    and may have 0, 1, or 2 triangle solutions.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Angle-Angle-Side (AAS)</h3>
                  <p className="text-sm mt-2">
                    Uses two angles and a non-included side. The third angle is calculated 
                    using the property that angles in a triangle sum to 180°.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Angle-Side-Angle (ASA)</h3>
                  <p className="text-sm mt-2">
                    Uses two angles and the included side. Similar to AAS, this method 
                    uses the property that angles in a triangle sum to 180°.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Angle-Angle-Angle (AAA)</h3>
                  <p className="text-sm mt-2">
                    Uses three angles. This method only determines the shape of the triangle, 
                    not its size. At least one side is needed to calculate the size.
                  </p>
                </div>
              </div>
              
              <div className="mt-4">
                <h3 className="text-lg font-medium text-gray-900">Triangle Properties</h3>
                <p className="text-sm mt-2">
                  This calculator provides various triangle properties including:
                </p>
                <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
                  <li>All sides and angles</li>
                  <li>Area and perimeter</li>
                  <li>Heights (altitudes) to each side</li>
                  <li>Inradius (radius of the inscribed circle)</li>
                  <li>Circumradius (radius of the circumscribed circle)</li>
                </ul>
              </div>
              
              <Separator className="my-4" />
              
              <p className="text-sm text-gray-500">
                <strong>Note:</strong> All calculations use standard triangle formulas like the Law of Sines, 
                Law of Cosines, and Heron's formula. Angles are measured in degrees, and all calculations are 
                rounded to 4 decimal places for display.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default TriangleCalculator;
